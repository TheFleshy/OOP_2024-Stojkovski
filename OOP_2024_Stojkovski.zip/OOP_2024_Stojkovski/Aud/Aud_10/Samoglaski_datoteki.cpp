#include <iostream>
#include <cstring>
#include <fstream>
#include <cctype>

using namespace std;

bool isVowel(char c) {
    if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
        c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U'){
        return true;
    }else {
        return false;
    }
}

int main() {

    ifstream fin(R"(C:\Users\andre\CLionProjects\OOP_2024_Stojkovski\Aud\Aud_10\input.txt)");

    char c; //curent char that you are reading

    int vowelsPerLine = 0;
    int linesWithMoreThan10Vowel = 0;
    int totalCount = 0;

    while (fin.get(c)) {

        if (c == '\n') {
            cout << endl << vowelsPerLine << endl;
            if (vowelsPerLine > 10){
                linesWithMoreThan10Vowel++;
            }
            vowelsPerLine = 0;
        }

        if (isVowel(c)) {
            cout << c;
            vowelsPerLine++;
            totalCount++;
        }
    }

    cout << endl << vowelsPerLine << endl;
    if (vowelsPerLine > 10){
        linesWithMoreThan10Vowel++;
    }

    cout<<"Vkupno " << linesWithMoreThan10Vowel <<" reda imaat povekje od 10 samoglaski."<<endl;
    cout<<"Vo datotekata ima vkupno " <<totalCount<<" samoglaski."<<endl;

    return 0;
}