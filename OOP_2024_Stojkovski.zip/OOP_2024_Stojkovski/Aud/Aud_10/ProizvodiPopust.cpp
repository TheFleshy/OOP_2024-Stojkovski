#include <iostream>
#include <string>
using namespace std;

class Discount {
public:
    static float euro;
    static float dollar;
    virtual float discount_price() =0;
    virtual float price() = 0;
    virtual void print_rule() =0;
};

float Discount::euro = 61.5;
float Discount::dollar = 55;

class NegativeValueException{
private:
    string text;
public:
    NegativeValueException(string text){
        this->text = text;
    }

    void print (){
        cout<<text<<endl;
    }


};

class Product {
protected:
    string name;
    float price;
public:
    Product(string name = " ", float price = 0){
        this->name = name;
        this->price = price;
    }

    float getPrice(){
        return price;
    }

    void print (){
        cout<<"Product: "<<name<<", price: "<<price<<endl;
    }

    void changePrice(float newPirce){
        if (newPirce < 0){
            throw NegativeValueException("Vnesena e negativna vrednost za cena!");
        } else {
            this->price = newPirce;
        }
    }

};

class FoodProduct : public Product, public Discount{
private:
    float calories;
public:
    FoodProduct(string name = " ", float price = 0, float calories =0) : Product(name, price){
        this->calories = calories;
    }
    float discount_price(){
        return getPrice();
    }

    float price(){
        return getPrice();
    }

    void print_rule(){
        cout<<"FoodProduct proizvodite nemaat popust !"<<endl;
    }

};

class Drinks : public Product, public Discount{
private:
    bool alcoholic;
    string brand;
public:
    Drinks(string name = " ", float price = 0, string brand = "", bool alcoholic = false) : Product(name, price){
        this->alcoholic = alcoholic;
        this->brand = brand;
    }
    float discount_price(){
        if (alcoholic && (getPrice()/Discount::euro)>20){
            return getPrice()*1.05;
//            return getPrice() - getPrice()*0.05;  //TODO OVOA GO KOMENTIRAM DA PROVERAM DALI MOZE I TAKA DA SE STAVA ZA POPUST, OTI NEKADE NE MI USPEVAT TIA DRUGITE OSVEN OVOA SO NE MI E ODKOMENTIRANO
//            return getPrice() * 0.95;
        }
        else if (!alcoholic && (brand == "Coca-Cola")){
            return getPrice()*1.10;
//            return getPrice() * 0.9;
        }
        else {
            return getPrice();
        }
    }

    float price(){
        return getPrice();
    }

    void print_rule(){
        cout<<"A&&>20->5%,  !A&&Coca-Cola->10%"<<endl;
    }
};

class Cosmetics : public Product, public Discount{
private:
    float weight;
public:
    Cosmetics(string name = " ", float price = 0, float weight = 0) : Product(name, price){
        this->weight = weight;
    }
    float discount_price(){
        if (getPrice()/Discount::dollar>20){
            return getPrice() * 1.14;
//            return getPrice() * 0.86; // TODO NA VLATKO LOGIKATA DALI E ISTA
        }
        else if (getPrice()/Discount::euro > 5){
            return getPrice() * 1.12;
//            return getPrice() * 0.88; // TODO NA VLATKO LOGIKATA DALI E ISTA
        }
        else {
            return getPrice();
        }

        //TODO PROVERI DALI MOZE SO ELSE IF ili mora so IF
    }

    float price(){
        return getPrice();
    }

    void print_rule(){
        cout<<">5€->12%,  >20$->14%"<<endl;
    }
};

float total_discount(Discount ** d, int n){
    float discount = 0;
    for (int i=0; i<n; i++){
        discount+=d[i]->discount_price();
        cout<<"Prvicna cena: "<<d[i]->price()<<endl;
        cout<<"Cena so popust: "<<d[i]->discount_price()<<endl;
        d[i]->print_rule();
    }
    return discount;
}

int main (){

    int n;
    float newPrice;
    Discount **d = new Discount * [50];
    d[n++] = new FoodProduct("leb", 30);
    d[n++] = new Drinks("viski", 1350, "Jack Daniel's", true);
    d[n++] = new FoodProduct("sirenje", 390, 105);
    d[n++] = new Drinks("votka", 850, "Finlandia", true);
    d[n++] = new Cosmetics("krema", 720, 100);
    d[n++] = new Drinks("sok", 50, "Coca-Cola", false);
    d[n++] = new Cosmetics("parfem", 3500, 50);

    cout<<"Vkupnata cena na site proizvodi e: "<<total_discount(d,n)<<endl;

    //se menuva cenata na site Kozmeticki proizvodi

    cout << "Promena na cenata na kozmetickite proizvodi " << endl;
    for (int i=0; i<n; i++){
        Cosmetics * c = dynamic_cast<Cosmetics *>(d[i]);
        if (c != 0){
            c->print();
            cin>>newPrice;
            try {
                c->changePrice(newPrice);
            }
            catch (NegativeValueException i) {
                i.print();
            }
        }
    }

    for (int i=0; i<n; i++){
        delete d[i];
    }
    delete [] d;
    return 0;
}