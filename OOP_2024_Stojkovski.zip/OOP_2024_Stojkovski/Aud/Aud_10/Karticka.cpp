#include <iostream>
#include <string>

using namespace std;

class Exception {
public:
    virtual void message() {}
};

class OperationNotSupportedException : public Exception {
private:
    double amount;
public:
    OperationNotSupportedException(double amount = 0) {
        this->amount = amount;
    }

    void message() override {
        cout << "You're trying to withdraw " << amount << "$ more than you have" << endl;
    }
};

class Card {
protected:
    string id;
    double balance;
public:
    Card(string id = " ", double balance = 0) {
        this->id = id;
        this->balance = balance;
    }

    virtual void deposit(double amount) {
        balance += amount;
    }

    virtual void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            throw OperationNotSupportedException(amount - balance);
        }
    }

    virtual void print() {
        cout << id << " Balance: " << balance << endl;
    }
};

class Master : public Card {
private:
    double limit;
    static const double STANDARD_DISCOUNT;
    static double NBRM_DISCOUNT;
public:
    Master(string id = " ", double balance = 0, double limit = 6000) : Card(id, balance) {
        this->limit = limit;
    }

    void withdraw(double amount) override {
        if (limit > 6000) {
            Card::withdraw(amount * (1 - NBRM_DISCOUNT));
        } else {
            Card::withdraw(amount * (1 - STANDARD_DISCOUNT));
        }
    }


};

class Maestro : public Card {
private:
    static const double DISCOUNT;
public:
    Maestro(string id = " ", double balance = 0) : Card(id, balance) {}

    void withdraw(double amount) override {
        Card::withdraw(amount * (1 - DISCOUNT));
    }

};

const double Maestro::DISCOUNT = 0.05;
const double  Master::STANDARD_DISCOUNT = 0.03;
double Master::NBRM_DISCOUNT = 0.1;

class Register {
private:
    int day, month, year;
    double amountInCash;
    double amountInCard;
public:
    Register(int day = 0, int month = 0, int year = 0) {
        this->day = day;
        this->month = month;
        this->year = year;
        this->amountInCard = 0;
        this->amountInCash = 0;
    }

    void payToRegister (double amount ){
        amountInCash += amount;
    }

    void payToRegister (double amount, Card & card){
        try{
            card.withdraw(amount);
            amountInCard += amount;
        }
        catch (OperationNotSupportedException & e){
            e.message();
        }
    }

    void show (){
        cout<<"Date: "<<day<<"."<<month<<"."<<year<<endl;
        cout<<"Cash: "<<amountInCash<<endl;
        cout<<"Card: "<<amountInCard<<endl;
    }
};

int main() {

    //OVOA E OD SEKOJ SLUCAJ SO GO PROVERUVAHME U TEKO NA ZADACATA
    Card c("123456789123456", 10000);
    try {
        c.withdraw(9000);
        c.print();
    } catch (OperationNotSupportedException &e) {
        e.message();
    }

    cout << endl;
    cout << endl;
    cout << endl;

    //OVOA E OD SEKOJ SLUCAJ SO GO PROVERUVAHME U TEKO NA ZADACATA
    Card *ca = new Maestro("12345678912345", 10000);
    try {
        ca->withdraw(11500);
        ca->print();
    } catch (OperationNotSupportedException &e) {
        e.message();
    }

    cout << endl;
    cout << endl;
    cout << endl;

    //OVOA E OD SEKOJ SLUCAJ SO GO PROVERUVAHME U TEKO NA ZADACATA
    Card * c1 = new Maestro("123", 1000);
    Card * c2 = new Master("456", 15000);

    Register aRegister (18,5,2024);
    aRegister.show();

    aRegister.payToRegister(1000);
    aRegister.payToRegister(5000);
    aRegister.show();
    aRegister.payToRegister(900, *c1);
    aRegister.payToRegister(13000, *c2);
    aRegister.show();
    c1->print();
    c2->print();
    aRegister.payToRegister(145, *c1);
    aRegister.payToRegister(4000, *c2);
    aRegister.show();
    c1->print();
    return 0;
}