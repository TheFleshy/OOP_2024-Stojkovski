// TODO U OVAA VEZBA PRAVIHME ISTO KAKO U ONAA DEKA SO CITAHME BUVKA PO BUVKA, SEA SAMO CITAHME RED PO RED
// TODO ISTO TAKA NAPRAVIHME DA MOZE TOA SE DA SE ZAPISA U DRUG FILE TAKO ZVANI OUTPUT.TXT :)

#include <iostream>
#include <fstream>


using namespace std;

bool isVowel(char c) {
    if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
        c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
        return true;
    } else {
        return false;
    }
}

int main() {

    ifstream fin(R"(C:\Users\andre\CLionProjects\OOP_2024_Stojkovski\Aud\Aud_10\input.txt)");
    ofstream fout(R"(C:\Users\andre\CLionProjects\OOP_2024_Stojkovski\Aud\Aud_10\output.txt)");

    string line;

    int linesWithMoreThan10Vowel = 0;
    int totalCount = 0;

    while (getline(fin, line)) {
        fout << line << endl;

        int vowels = 0;
        for (int i = 0; i < line.length(); ++i) {
            if (isVowel(line[i])){
                vowels++;
                totalCount++;
            }
        }
        if (vowels > 10){
            linesWithMoreThan10Vowel++;
        }
    }

    fout<<endl;

    fout<<"Vkupno " << linesWithMoreThan10Vowel <<" reda imaat povekje od 10 samoglaski."<<endl;
    fout<<"Vo datotekata ima vkupno " <<totalCount<<" samoglaski."<<endl;

    return 0;
}