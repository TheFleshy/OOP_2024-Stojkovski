//Да се напише класа во која ќе се чуваат основни податоци за вработен:

//име
//плата
//работна позиција (работната позиција може да биде вработен, директор или шеф).

//Напишете главна програма во која се читаат од стандарден влез податоци за N вработени,
//потоа се пачати листа на вработените сортирани според висината на платата во опаѓачки редослед.


#include <iostream>
#include <cstring>
using namespace std;

enum Type{
    Employee,
    Manager,
    Owner
};

class Vraboten {
private:
    char name [100];
    int salary;
    Type type;
public:
    Vraboten(char _name[] = "Andrej", int _salary = 20000, Type _type = Owner){
        strcpy(name, _name);
        salary = _salary;
        type = _type;
    }
    ~Vraboten(){}

    void print (){
        cout<<"Employee: "<<name<<", "<<"Salary: "<<salary<<", "<<"Postion: ";
        if (type == 0){
            cout<<"Employee"<<endl;
        }else if (type == 1){
            cout<<"Manager"<<endl;
        }else {
            cout<<"Owner"<<endl;
        }
    }

    int getSalary(){
        return salary;
    }

    void swap(Vraboten& other) {
        Vraboten temp = other;
        strcpy(other.name, name);
        other.salary = salary;
        other.type = type;
        strcpy(name, temp.name);
        salary = temp.salary;
        type = temp.type;
    }

};

int main (){

    int n;
    cin>>n;

    Vraboten employees [50];

    char name[50];
    int salary;
    int type;

    for (int i=0; i<n; i++) {
        cin >> name >> salary >> type;
        employees[i] = Vraboten(name, salary, (Type) type);
    }

    for (int i=0; i<n; i++){
        for (int j=0; j<n-1-i; j++){
            if (employees[j].getSalary() < employees[j+1].getSalary()){
                employees[j].swap(employees[j+1]);
            }
        }
    }

    for (int i=0; i<n; i++){
        employees[i].print();
    }

    return 0;
}