// Да се напише класа за опишување на геометриско тело триаголник.
// Во класата да се напишат методи за пресметување на плоштината и периметарот на триаголникот.
//Потоа да се напише главна програма во која ќе се инстнацира еден објект од оваа класа со вредности за страните кои претходно ќе се прочитаат од стандарден влез.
// На овој објект да се повикат соодветните методи за пресметување на плоштината и периметарот.

#include <iostream>
#include <cmath>
using namespace std;

class Triagolnik {
    int a,b,c;
public:
    Triagolnik(int _a = 5, int _b = 4, int _c = 3){
        cout<<"Constructor is called "<<endl;
        a = _a;
        b = _b;
        c = _c;
    }

    ~Triagolnik() { // ovoa ne mora da se pisa , glupost teska, za vakvi zadaci de
        cout<<"Object is destroyed"<<endl;
    }

    int perimetar (){
        return a+b+c;
    }

    double plostina (){
        float s = (a+b+c)/2.0;
        return sqrt(s*(s-a)*(s-b)*(s-c));
    }

    void print (){
        cout<<"Triagolnik so strani: "<<a<<", "<<b<<", "<<c<<endl;
        cout<<"Perimetar: "<<perimetar()<<", "<<" Plostina: "<<plostina()<<endl;
    }

};

int main (){

    Triagolnik t;
    t.print();

    Triagolnik t1 (6, 6, 6);
    t1.print();

    return 0;
}