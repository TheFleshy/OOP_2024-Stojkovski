// Да се напише класа која опишува една e-mail порака.
// Во класата треба да се имплементира метод за прикажување на целокупната порака на екран.
// Потоа да се напише главна програма во која се внесуваат параметрите на пораката, се инстанцира објект од оваа класа
// и се печати на екран неговата содржина.
// За проверување на валидноста на e-mail пораката (постоење на знакот @ во адресата) да се напише соодветна функција.

#include <iostream>
#include <cstring>

using namespace std;

class EmailMessage {
private:
    char sender[50];
    char receiver[50];
    char subject[50];
    char body[300];
public:
    EmailMessage(char _sender[] = "info@finki.ukim.mk",
                 char _receiver[] = "andrej@students.finki.ukim.mk",
                 char _subject[] = "Disciplinska kazna",
                 char _body[] = "Kaznet si! Koj saka neka cestita") {
        strcpy(sender, _sender);
        strcpy(receiver, _receiver);
        strcpy(subject, _subject);
        strcpy(body, _body);
    }

    void show (){
        cout<<"From: \t"<<sender<<endl;
        cout<<"To: \t"<<receiver<<endl;
        cout<<"Subject: \t"<<subject<<endl;
        cout<<"Body: "<<endl;
        cout<<body;
    }
};

bool valid (char mailAdress[50]);

int main() {

    char sender[50];
    char receiver[50];
    char subject[50];
    char body[300];

    cin>>sender>>receiver;

    if (!valid(sender) || !valid(receiver)){
        cout<<"Ne e validen senderot ili receiverot!"<<endl;
        return 0;
    }

    cin>>subject;
    cin.get(body, 300);

    EmailMessage emailMessage (sender, receiver, subject, body);

    emailMessage.show();

    return 0;
}

bool valid (char mailAdress[50]){
    int idx = -1;
    for (int i=0; i< strlen(mailAdress); i++){
        if (mailAdress[i] == '@'){
            idx = i;
        }
    }

    if (idx == -1){   // ne e najden @
        return false;
    }else {
        for (int i=idx; i< strlen(mailAdress); i++){
            if (mailAdress[i] == '.'){
                return true;
            }
        }
        return false;
    }
}