// Да се дефинира класа Momche која содржи информации за име, презиме и години.
// За класата да се дефинираат конструктори, деструктор и метод за печатење на објектот на екран во формат:
//Momche: Ime Prezime Godini.
//Да се дефинира класа Devojche со истите атрибути и методи со разлика во форматот на печатење:
//Devojche: Ime prezime godini.
//Креирајте класа Sredba која содржи податоци за едно момче и едно девојче.
//Креирајте функција print() која ги печати податоците за момчето и девојчето во следниот формат:
//Sredba: Momche: Ime Prezime Godini Devojche: Ime Prezime Godini.
//Напишете функција daliSiOdgovaraat() која печати “Si odgovaraat” доколку разликата на нивните години е помала или еднаква на 5 или “Ne si odgovaraat” во спротивно.

#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;

class Momche {
private:
    char fullName[100];
    int godini;

public:
    // default constructor
    Momche(){
        strcpy(fullName, "Trajce");
        godini = 18;
    }

    // constructor so argumenti
    Momche(char * _fullName, int _godini){
        strcpy(fullName, _fullName);
        godini = _godini;
    }

    ~Momche(){}

    Momche (const Momche & momhce){
        strcpy(fullName, momhce.fullName);
        godini = momhce.godini;
    }

    void print(){
        // Momche: Ime Prezime Godini
        cout<<"Momche: "<<fullName<<", Godini: "<<godini<<endl;
    }

    int getGodini() {
        return godini;
    }

};

class Devojche {

private:
    char fullName[100];
    int godini;

public:
    // default constructor
    Devojche(){
        strcpy(fullName, "Trajanka");
        godini = 22;
    }

    // constructor so argumenti
    Devojche(char * _fullName, int _godini){
        strcpy(fullName, _fullName);
        godini = _godini;
    }

    ~Devojche(){}

    Devojche (const Devojche & devojche){
        strcpy(fullName, devojche.fullName);
        godini = devojche.godini;
    }

    void print(){
        // Devojche: Ime Prezime Godini
        cout<<"Devojche: "<<fullName<<", Godini: "<<godini<<endl;
    }

    int getGodini() {
        return godini;
    }

};

class Date{
private:
    Momche momche;
    Devojche devojche;

public:
    Date(){}

    Date (Momche _momche, Devojche _devojche){
        momche = _momche;
        devojche = _devojche;
    }

    Date(const Date & date){
        momche = date.momche;
        devojche = date.devojche;
    }

    void print (){
        cout<<"Date between: ";
        momche.print();
        cout<<" and ";
        devojche.print();
    }

    void isMatch (){
        int diff = abs(momche.getGodini() - devojche.getGodini());
        if (diff < 5 ){
            cout<<"Match!"<<endl;
        }else {
            cout<<"Match failed!"<<endl;
        }
    }
};


int main (){

//
//    // default constructor
    Momche b;
//    b.print();
//
    Devojche g;
//    g.print();

Date date(b, g);
date.print();
date.isMatch();

    return 0;
}