// Да се напише класа Datum во која ќе се чуваат ден, месец и година (цели броеви).
//Да се напише класа Vraboten во која се чува име на вработениот (не повеќе од 20 знаци), плата и датум на раѓање (објект од класата Datum).
//Да се напишат две функции кои како аргументи примаат низа од вработени и големина на низата.
//Едната функција го враќа вработениот со најголема плата, а другата функција го враќа најмладиот вработен во фирмата.
//Во главната програма потребно е да се испечатат на екран податоците за најмалдиот и најплатениот вработен.
//Печатењето на вработениот да биде реализирано со посебна функција print() во рамките на класата Vraboten.

#include <iostream>
#include <cstring>
using namespace std;

class Date {
private:
    int day;
    int month;
    int year;
public:
    //2in1
    Date(int _day = 1, int _month = 1, int _years  = 1990){
        day = _day;
        month = _month;
        year = _years;
    }

    Date(const Date & d){
        day = d.day;
        month = d.month;
        year = d.year;
    }
    ~Date(){}

    void print (){
        cout<<day<<"."<<month<<"."<<year<<endl;
    }

    int compare (Date & date){
        if (year > date.year){
            return 1;
        }
        else if (year < date.year){
            return -1;
        }
        else {
            if (month > date.month){
                return 1;
            }
            else if (month < date.month){
                return -1;
            }
            else {
                if (day > date.day){
                    return 1;
                }else if (day < date.day){
                    return -1;
                }
                else {
                    return 0;
                }
            }
        }
    }
};

class Employee {
private:
    char name[50];
    int salary;
    Date DOB;
public:
    Employee(){
        strcpy(name, "");
        salary = 0;
    }

    Employee(char * _name, int _salary, Date _DOB){
        strcpy(name, _name);
        salary = _salary;
        DOB = _DOB;
    }

    Employee(const Employee & e){
        strcpy(name, e.name);
        salary = e.salary;
        DOB = e.DOB;
    }

    void print (){
        cout<<"Name: "<<name<<", Salary: "<<salary<<" ";
        DOB.print();
    }

    ~Employee(){}

    friend Employee highestPaidEmployee(Employee * employees, int n);
    friend Employee youngestEmployee(Employee * employees, int n);
};

Employee highestPaidEmployee(Employee * employees, int n){
    Employee maxEmployee = employees[0];
    for (int i=1; i<n; i++){
        if (employees[i].salary > maxEmployee.salary ){
            maxEmployee = employees[i];
        }
    }
    return maxEmployee;
}

Employee youngestEmployee(Employee * employees, int n){
    Employee minEmployee = employees[0];
    for (int i=0; i<n; i++){
        if (employees[i].DOB.compare(minEmployee.DOB) > 0){
            minEmployee = employees[i];
        }
    }
    return minEmployee;
}

int main (){

    // 10 pati se povikuva default constructor
    Employee employee[100];

    int n;
    cin>>n;

    for (int i=0; i<n; i++){
        char name[100];
        int salary;
        int day,month,year;
        cin>>name>>salary>>day>>month>>year;
        Date dob (day, month, year);
        employee[i] = Employee(name, salary, dob);
    }

    cout<<"Highest paid Employee is: "<<endl;
    highestPaidEmployee(employee, n).print();

    cout<<"Youngest Employee is: "<<endl;
    youngestEmployee(employee, n).print();


    return 0;
}