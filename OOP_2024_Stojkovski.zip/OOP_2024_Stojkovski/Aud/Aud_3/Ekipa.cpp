// Да се дефинира класа Ekipa што содржи информации за име на екипата, година на формирање и градот од каде потекнува.
//Да се дефинира класа Natprevar што содржи информации за домаќин, гостин (објекти од класата Ekipa), голови кои ги постигнал домаќинот и голови кои ги постигнал гостинот.
//Да се дефинира посебна функција revans што како аргументи прима два објекта од класата Natprevar и проверува дали едниот натпревар е реванш на другиот.
//Еден натпревар е реваш на друг ако гостинот и домаќинот од првиот натпревар се истите екипи со домаќинот и гостинот од вториот натпревар, соодветно.
//Да се дефинира функцијата duel која што како аргументи прима два објекта од класата Natprevar и ако едниот натпревар е ревашн на другиот функцијата треба да ја врати екипата која е подобра во меѓусебниот дуел.
// Во спротивно да испечати порака дека натпреварите не се совпаѓаат. Во случајот кога е нерешено функцијата враќа 0.

#include <iostream>
#include <cstring>
using namespace std;

class Ekipa {
private:
    char name[50];
    int godina;
    char grad[50];

public:
    //2in1 constructor
    Ekipa(char * _name = "", int _godina = 1990, char * _grad = ""){
        strcpy(name, _name);
        strcpy(grad, _grad);
        godina = _godina;
    }

    Ekipa(const Ekipa & t){
//        cout<<"Coppy const"<<endl;
        strcpy(name, t.name);
        strcpy(grad, t.grad);
        godina = t.godina;
    }

    ~Ekipa(){}

    bool isEqual (Ekipa other){
        return strcmp(name, other.name)==0;
    }

    void print(){
        cout<<name<<endl;
    }

    void setName(const char * string){
        strcpy(name, string);
    }
};

class Natprevar {
    Ekipa homeTeam;
    Ekipa awayTeam;
    int homeGoals;
    int awayGoals;

public:
    Natprevar(Ekipa _homeTeam, Ekipa _awayTeam, int _homeGoals, int _awayGoals){
        homeTeam = _homeTeam;
        awayTeam = _awayTeam;
        homeGoals = _homeGoals;
        awayGoals = _awayGoals;
    }
    Natprevar(){homeGoals = awayGoals = 0;}

    Natprevar(const Natprevar & n){
//        cout<<"Coppy const"<<endl;
        homeTeam = n.homeTeam;
        awayTeam = n.awayTeam;
        homeGoals = n.homeGoals;
        awayGoals = n.awayGoals;
    }
    ~Natprevar(){}

    bool Revans(Natprevar & other){
        return homeTeam.isEqual(other.awayTeam) && awayTeam.isEqual(other.homeTeam);
    }

    friend Ekipa duel (Natprevar & first, Natprevar & second);
};

Ekipa duel (Natprevar & first, Natprevar & second){
    if (first.Revans(second)) {
        int goalsOfFirstTeam = first.homeGoals + second.awayGoals;
        int goalsOfSecondTeam = first.awayGoals + second.homeGoals;
        if (goalsOfFirstTeam > goalsOfSecondTeam){
            return first.homeTeam;
        }else if (goalsOfFirstTeam  < goalsOfSecondTeam){
            return first.awayTeam;
        }else {
            return nullptr;
        }
    }else {
        return nullptr;
    }

}

int main (){

    Ekipa e ("Barcelona", 1890, "Barcelona");
    Ekipa e2("RealMadrid", 1990, "Madrid");

//    Ekipa e3 (e2);
//    e3.setName("Chelsea");

    Natprevar firstGame (e, e2, 10, 5);
    Natprevar secondGame (e2, e, 5, 10);

    cout<<firstGame.Revans(secondGame)<<endl;

    duel(firstGame, secondGame).print();

    return 0;
}