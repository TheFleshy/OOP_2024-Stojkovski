// TODO Повеќекратно наследување - celta mu e stavame na klasite so se nasleduvat od osnovnata virutal ...
#include <iostream>
#include <string>
using namespace std;

class Vehicle {
protected:
    int acceleration;

public:
    Vehicle(){
        acceleration = 0;
        cout<<"Vehicle constructor called "<<endl;
    }

    virtual void acclerate (){
        cout<<"Vehicle acceleration called "<<endl;
        acceleration++;
    }

    ~Vehicle(){
        cout<<"Vehicle destructor called "<<endl;
    }

    int getAcceleration(){
        return acceleration;
    }

};

class Car : virtual public Vehicle{
public:
    Car(){
        cout<<"Car constructor called "<<endl;
    }

//    void acclerate (){
//        cout<<"Car acceleration called "<<endl;
////        acceleration+=2;
//        Vehicle::acclerate();    // moze i vaka mesto +=2
//        Vehicle::acclerate();
//    }

    virtual void drive (){
        cout<<"Car is driving "<<endl;
    }

    ~Car(){
        cout<<"Car destructor called "<<endl;
    }

};

class Jet : virtual public Vehicle{
public:
    Jet(){
        cout<<"Jet constructor called "<<endl;
    }

    void acclerate (){
        cout<<"Jet acceleration called "<<endl;
        acceleration+=50;

    }

    virtual void fly(){
        cout<<"Jet is flying "<<endl;
    }

    ~Jet(){
        cout<<"Jet destructor called "<<endl;
    }

};

class JetCar : public Car, public Jet{
public:
    JetCar(){
        cout<<"JetCar constructor called "<<endl;
    }

    void drive(){
        cout<<"JetCar is driving "<<endl;
    }

    void fly(){
        cout<<"JetCar is flying "<<endl;
    }

    ~JetCar(){
        cout<<"JetCar destructor called "<<endl;
    }
};

int main (){

    JetCar jetcar;
    jetcar.fly();
    jetcar.drive();
    jetcar.acclerate();             //todo da ne bea virtualni nemozese , oti ednas od taa klasa ednas od drugata ke go zimase
    cout<<jetcar.getAcceleration(); // da ne bea virtualni nemozese , oti ednas od taa klasa ednas od drugata ke go zimase


    return 0;
}