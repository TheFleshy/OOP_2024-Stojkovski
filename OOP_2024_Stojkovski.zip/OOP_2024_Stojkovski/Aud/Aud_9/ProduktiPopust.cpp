#include <iostream>
#include <string>

using namespace std;

class Product {
protected:
    string name;
    float cena;
public:
    Product(string name = " ", float cena = 0) {
        this->name = name;
        this->cena = cena;
    }

};

class Discountable { // todo Ovia klasi sa      interface,      dava samo pristap do nekakvi metodi
public:
    virtual float getPrice() = 0;

    virtual float getPriceWithDiscont() = 0;

    virtual void print() = 0;
};

class FoodProduct : public Product, public Discountable {
private:
    int calories;
public:
    FoodProduct(string name = " ", float cena = 0, int calories = 0) : Product(name, cena) {
        this->calories = calories;
    }

    float getPrice() {
        return cena;
    }

    float getPriceWithDiscont() {
        if (calories > 500) {
            return cena * 0.8;
        } else if (calories > 100) {
            return cena * 0.9;
        } else {
            return cena * 0.95;
        }
    }

    void print() {
        cout << "FoodProduct: " << name << " with number of calories: " << calories << " Price: " << getPrice()
             << " Price with discount: " << getPriceWithDiscont() << endl;
    }

};

class DigitalProduct : public Product, public Discountable {
private:
    float sizeInMB;
public:
    DigitalProduct(string name = " ", float cena = 0, float sizeInMB = 0) : Product(name, cena) {
        this->sizeInMB = sizeInMB;
    }

    float getPrice() {
        return cena;
    }

    float getPriceWithDiscont() {
        if (sizeInMB > 1024) {
            return cena * 0.7;
        } else if (sizeInMB > 512) {
            return cena * 0.85;
        } else {
            return cena * 0.925;
        }
    }

    void print() {
        cout << "FoodProduct: " << name << " with size in MB: " << sizeInMB << " Price: " << getPrice()
             << " Price with discount: " << getPriceWithDiscont() << endl;
    }

};

float totalDiscount (Discountable ** discountables, int n){
    float totalDiscount = 0;
    for (int i=0; i<n; i++){
        totalDiscount+=(discountables[i]->getPrice() - discountables[i]->getPriceWithDiscont());
    }
    return totalDiscount;
}

int countFoodProducts (Discountable ** discountables, int n) {  // TODO NA KOLOKVIUM IMALO DYNAMIC CAST :o
    int counter = 0;
    for (int i=0; i<n; i++){ // probuvame discountable products od i da go castiramo u foodproducts
        FoodProduct * casted = dynamic_cast <FoodProduct *>(discountables[i]);
        // FoodProduct * casted = dynamic_cast <voStoKastirame *> (StoKastirame);
        if (casted!=0){
            ++counter; // deka sme nasle discountableProduct koj sto e voedno i food
        }
    }
    return counter;
}

int main() {
    int n;
    cin >> n;


    Discountable **discountableProducts = new Discountable *[n];
    for (int i = 0; i < n; i++) {
        int type; // 1 - FoodProduct, 2 - DigitalProduct
        string name;
        float price;
        float sizeInMB;
        int calories;
        cin >> type;
        if (type == 1) { // foodProduct
            cin >> name >> price >> calories;
            discountableProducts[i] = new FoodProduct(name, price, calories);
        } else { // digitalProduct
            cin >> name >> price >> sizeInMB;
            discountableProducts[i] = new DigitalProduct(name, price, sizeInMB);
        }
    }

    for (int i=0; i<n; i++){
        discountableProducts[i]->print();
    }

    cout<<"Total discount for the product is: "<<totalDiscount(discountableProducts, n)<<endl;
    cout<<"Total number of food products " <<countFoodProducts(discountableProducts, n)<<endl;
    cout<<"Total number of digital products " <<n - countFoodProducts(discountableProducts, n)<<endl;
    return 0;
}