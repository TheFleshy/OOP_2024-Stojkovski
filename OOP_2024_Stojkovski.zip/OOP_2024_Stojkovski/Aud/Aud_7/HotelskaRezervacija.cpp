#include <iostream>
#include <string>

using namespace std;

class HotelReservation {
protected:
    int days;
    int guests;
    string contact;
public:
    HotelReservation(string contact = "", int days = 0, int guests = 0) {
        this->days = days;
        this->guests = guests;
        this->contact = contact;
    }

    virtual double price() {
        return guests * days * 25;
    }

    double price(double deposit){
        return deposit - price();
    }
};

class HalfBoardHotelReservation : public HotelReservation {
public:
    HalfBoardHotelReservation(string contact = "", int days = 0, int guests = 0) : HotelReservation(contact, days, guests){

    }

    double price (){
//        return guests * days * 30;
        return HotelReservation ::price()*1.2;
    }

};

class Hotel {
private:
    string name;
    double balance;
public:
    Hotel(string name = " ", double balance = 0){
        this->name = name;
        this->balance = balance;
    }

    double depositReservation(HotelReservation & hr, double deposit){
        double totalPrice = hr.price();
        balance+=totalPrice;
        return hr.price(deposit);
    }

    friend ostream & operator << (ostream & out, const Hotel & h){  // cisto da provereme kolku e balanceto na hotelo (kasata)
        return out<<h.name<<" "<<h.balance<<endl;
    }
};

int main() {

    Hotel hotel ("MirenSon", 1000);

    int n; // br na rezervacii
    cin>>n;

    HotelReservation ** reservations = new HotelReservation * [n];

    for (int i=0; i<n; i++){
        int type; // 1 - obicna, 2 - polupansionska
        string name;
        int days, guests;
        double deposit;
        cin>>type>>name>>days>>guests>>deposit;
        if (type == 1){
            reservations[i] = new HotelReservation(name, days, guests);
        }else {
            reservations[i] = new HalfBoardHotelReservation(name, days, guests);
        }
        cout<<name<<" Days: "<<days<<" Guests: "<<guests<<" Price: "<<reservations[i]->price();
        cout<<" Change from payment: "<<hotel.depositReservation(*reservations[i], deposit)<<endl;
    }

    cout<<"Hotel state after all the reservations were payed"<<endl;
    cout<<hotel;

    return 0;
}