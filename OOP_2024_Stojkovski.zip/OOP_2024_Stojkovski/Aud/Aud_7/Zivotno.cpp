/// Primer za polimorfizam so go nema u Aud ama Stefan pocnuva so takov za da go objasnil :)

#include <iostream>
#include <string>
using namespace std;

class Animal {
protected:
    string name;
public:
    Animal(string name = ""){
        this->name = name;
    }

    virtual void makeSound(){  //TODO u usnovnata klasa ovaa mora da bide virtual za da moze posle ovia od drugite klasi da gi koristat od nih , da ja zimat od ovaa (sustinata na polimorfizam)
        cout<<name<<" is making the sound bla bla"<<endl;
    }
};

class Dog : public Animal{
public:
    Dog(string name = " ") : Animal(name){
//        this->name = name;
    }

     void makeSound() {
        cout<<name<<" is making the sound afaf afaf"<<endl;
    }
};

class Cat : public Animal{
public:
    Cat(string name = " ") : Animal(name){
//        this->name = name;
    }

    void makeSound(){
        cout<<name<<" is making the sound maju mjau"<<endl;
    }
};

int main (){

//    Animal * a = new Animal("Stole");  // todo ovoa e eden nacin na polimofizam
//    a->makeSound();
//
//    Animal *dog = new Dog("sarko");
//    dog->makeSound();
//
//    Animal *cat = new Cat ("vesna");
//    cat->makeSound();

    Animal ** animals = new Animal * [3];   // todo ako iame polimorfizam so niza od pokazuvaci **

    animals [0] = new Animal("Stole");
    animals [1] = new Dog("sarko");
    animals [2] = new Cat ("vesna");
    for (int i=0; i<3; i++){
        animals[i] ->makeSound();
    }

    //TODO mora da se cuva pokazuvaci koj osnovnata klasa, oti obicni objekti ne ovozmozuva polimorfizmot

    return 0;
}