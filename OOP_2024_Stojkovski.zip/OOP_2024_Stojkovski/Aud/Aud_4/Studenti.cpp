// vezbanje za static

//Да се напише класа Student која треба да чува информации за името на студентот, број на индекс и просек.
//Да се дефинираат статички членови кои ќе даваат информации за бројот на студенти и вкупниот просек.
//Да се имплементираат статички функции кои ќе го враќаат вкупниот просек и бројот на студенти.
//Секогаш кога ќе се креира објект, статичките членови треба да се ажурираат.
//Во главната програма да се внесат информации за n студенти, да се испечати список со сите студенти и вредностите од статичките членови.

#include <iostream>
#include <cstring>
using namespace std;

class Student {
private:
    char name[50];
    int index;
    double average;
    static int TOTAL_STUDENTS;
    static double SUM_OF_AVERAGES;

public:
    Student(char * name, double average){
        strcpy(this->name, name);
        this->average = average;
        index = 231001 + TOTAL_STUDENTS;            // секвенцијално генереирање на id на студентот, кога тој се креира
        TOTAL_STUDENTS++;                           // so ovoa gore
        SUM_OF_AVERAGES += average;
    }

    void print (){
        cout << index<<" "<< name <<" "<<average<<endl;
    }

    static double averageOfAllStudents (){
        return SUM_OF_AVERAGES / TOTAL_STUDENTS;
    }

};

int Student :: TOTAL_STUDENTS = 0;
double Student :: SUM_OF_AVERAGES = 0.0;

int main (){

    Student andrej ("Andrej", 9.0);
    cout<<Student :: averageOfAllStudents()<<endl;         // ovoa e kako dopolnitelno baranje da se vide kako pri unasanje na nov student, ke se mene proseko

    Student petko ("Petko", 7.0);
    cout<<Student :: averageOfAllStudents()<<endl;

    Student riste ("Riste", 7.8);
    cout<<Student :: averageOfAllStudents()<<endl;

    Student mirce ("Mirce", 6.3);
    cout<<Student :: averageOfAllStudents()<<endl;


    andrej.print();
    petko.print();
    riste.print();
    mirce.print();


    return 0;
}