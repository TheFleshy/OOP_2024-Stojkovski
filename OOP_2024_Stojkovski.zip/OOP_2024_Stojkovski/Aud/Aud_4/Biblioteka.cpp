// vezbanje za friend

//Да се дефинира класа Book која соджи информации за името на книгата, името на авторот и нејзината достапност.
//За оваа класа да се дефинираат сите три конструктори и деструктор. Потоа, да се дефинира класа Library која е пријател на класата Book.
//Во оваа класа се чува името на библиотеката(иницијално поставено “Braka Miladinovci”), низа објекти од класата Book и бројот на книги(иницијално поставен на 0).
//За оваа класа да се дефинира метод addBook кој додава книга во низата книги и метод за печатење на сите информации за библиотеката.
//Да се дефинира и трета класа LibraryMember во која се чуваат информации за име и идентификациски број, за членот во библиотеката.
//Да се обезбедат соодветни конструктори, деструктори, set и get методи доколку се потребни.
//Да се дефинира функција checkOutBook која е пријател на сите три класи и како аргументи прима еден член, библиотека и индекс на една книга.
//Со оваа функција треба да се ажурира достапноста кога некој ќе побара книга и да се печати соодветна порака ако книгата не е достапна.
//Во главната програма да се направи еден објект од класата Library, да се внесат информации за најмногу 30 книги и истите да се додадат во библиотеката.
//Потоа да се испечатат информациите за библиотеката. Да се креира и еден член на библиотеката и дополнително да се внесе редниот број на книгата што сака да ја позајми. Да се провери дали таа книга е достапна.

// resavana so Stefan Andonov, i ima plus dopolnitelni raboti da bide po oteznana :) , odnosno da se renta kniga

#include <iostream>
#include <cstring>
using namespace std;

class Library;

class LibraryMember {
private:
    int id;
    char name[50];
public:
    LibraryMember(int id = 0, char *name = "Andrej"){
        this->id = id;
        strcpy(this->name, name);
    }

    friend void checkOutBook (LibraryMember member, Library & library, char * title, char * author);
    friend class Book;
};

class Book {
private:
    char title[50];
    char author[30];
    bool isAvailable;
    LibraryMember rentedBy;
public:
    // constructor
    Book(char *title = "no title", char *author = "no author", bool isAvailable = true){
        strcpy(this->title, title);
        strcpy(this->author, author);
        this->isAvailable = isAvailable;
    }
    // copy-constructor
    Book (const Book & other){
        strcpy(this->title, other.title);
        strcpy(this->author, other.author);
        this->isAvailable = other.isAvailable;
    }

    ~Book(){};

    void print () {
        cout << title << " (" << author << ") " << (isAvailable ? "Yes" : "No") <<" "<< (!isAvailable ? rentedBy.name : "") << endl;
    }


    void setIsAvailable (bool isAvailable){
        this->isAvailable = isAvailable;
    }

    void setRentedBy (LibraryMember & member){
        this->rentedBy = member;
    }

    friend class Library;
    friend void checkOutBook (LibraryMember member, Library & library, char * title, char * author);

};

class Library {
private:
    char name[50];
    Book books[1000];  // default constr 1000 pati na klasata Book
    int n;
public:
    Library(char * name = "Braka Miladinovci"){
        strcpy(this->name, name);
        n = 0;
    }

    void addBook (Book & book){
        if (n == 1000){
            cout<<"No capacity"<<endl;
        }
        else {
            books[n] = book;
            n++;
        }
    }

    void print (){
        cout<<name<<endl;
        for (int i=0; i<n; i++){
            books[i].print();
        }
    }

    friend void checkOutBook (LibraryMember member, Library & library, char * title, char * author);
};

void checkOutBook (LibraryMember member, Library & library, char * title, char * author){
    for (int i=0; i<library.n; i++){
        if (strcmp(library.books[i].title, title) == 0 && strcmp(library.books[i].author, author)==0 && library.books[i].isAvailable){
            library.books[i].setRentedBy(member);
            library.books[i].setIsAvailable(false);
        }
    }
}

int main (){

    Book b ("Angels and demons", "Dan Brown", true);
    Book b1 ("DaVinci Code", "Dan Brown", true);
    Book b2 ("Lost symbol", "Dan Brown", true);
    Book b3 ("Inferno", "Dan Brown", true);

    Library library ("Andrej's Library");

    LibraryMember member; // id 0, name = Andrej


    library.addBook(b);
    library.addBook(b1);
    library.addBook(b2);
    library.addBook(b3);

    library.print();

    checkOutBook(member, library, "Lost symbol", "Dan Brown");

    library.print();

    return 0;
}