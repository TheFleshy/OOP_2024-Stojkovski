//Да се дефинира класа Ekipa што содржи информации за име на екипата, година на формирање и градот од каде потекнува.
//Да се дефинира класа Natprevar што содржи информации за домаќин, гостин (објекти од класата Ekipa), голови кои ги постигнал домаќинот и голови кои ги постигнал гостинот.
//Да се дефинира посебна функција revans што како аргументи прима два објекта од класата Natprevar и проверува дали едниот натпревар е реванш на другиот.
//Еден натпревар е реваш на друг ако гостинот и домаќинот од првиот натпревар се истите екипи со домаќинот и гостинот од вториот натпревар, соодветно.
//Да се дефинира функцијата duel која што како аргументи прима два објекта од класата Natprevar и ако едниот натпревар е ревашн на другиот функцијата треба да ја врати екипата која е подобра во меѓусебниот дуел.
//Во спротивно да испечати порака дека натпреварите не се совпаѓаат. Во случајот кога е нерешено функцијата враќа 0.

// funkcijata Duel e napraena u samata rematch funkcija 2in1 e taka da ne vi treba taa :)

#include <iostream>
#include <cstring>
using namespace std;

class Team {
private:
    char name[50];
    int godina;
    char city[50];
public:
    //2in1
    Team(char *name = "noname", int godina = 2000, char * city = "nocity"){
        strcpy(this->name, name);
        strcpy(this->city, city);
        this->godina = godina;
    }

    Team(const Team & other){
        strcpy(this->name, other.name);
        strcpy(this->city, other.city);
        this->godina = other.godina;
    }

    void print(){
        cout<<name<<" - "<<city<<"("<<godina<<")"<<endl;
    }

    const char *getName() const {
        return name;
    }

    int getGodina() const {
        return godina;
    }

    const char *getCity() const {
        return city;
    }

};

class Game {
private:
    Team home;
    Team away;
    int homeGoals;
    int awayGoals;
public:
    Game(Team & home,  Team & away, int homeGoals, int awayGoals){
        this -> home = home;
        this -> away = away;
        this -> homeGoals = homeGoals;
        this -> awayGoals = awayGoals;
    }

    void print (){
        cout<<"Home team: ";
        home.print();
        cout<<"Away team: ";
        away.print();
        cout<<"Result ---> "<<homeGoals<<":"<<awayGoals;
    }

    friend void rematch (Game & firstGame, Game & secondGame);
};

void rematch (Game & firstGame, Game & secondGame){
    if (strcmp(firstGame.home.getName() , secondGame.away.getName()) == 0 && strcmp(firstGame.away.getName() , secondGame.home.getName()) == 0){
        cout<<" Rematch! "<<endl;
        int team1Goals = firstGame.homeGoals + secondGame.awayGoals;
        int team2Goals = firstGame.awayGoals + secondGame.homeGoals;
        if (team1Goals > team2Goals){
            cout<<"WINNER"<<endl;
            firstGame.home.print();
            cout<<team1Goals<<" total goals"<<endl;
        }else if (team1Goals < team2Goals) {
            cout<<"WINNER"<<endl;
            firstGame.away.print();
            cout<<team2Goals<<" total goals"<<endl;
        }else {
            cout<<"DRAW"<<endl;
        }
    }else {
        cout<<" Not Rematch! "<<endl;
    }
}

int main (){

    Team team4("Barca", 1890, "Barcelona");
    Team rm ("Real Madrid", 1902, "Madrid");

    Game game(team4, rm, 2, 4);
    Game game2(rm, team4, 3, 1);

    rematch(game, game2);

    return 0;
}