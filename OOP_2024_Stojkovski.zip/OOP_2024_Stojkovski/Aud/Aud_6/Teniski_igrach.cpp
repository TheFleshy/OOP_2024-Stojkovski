#include <iostream>
#include <string>
using namespace std;

class TennisPlayer {
protected:
    string name;
    bool playsInLeague;
public:
    TennisPlayer(string name = " ", bool playsInLeague = false){
        cout<<"TennisPlayer constructor"<<endl;
        this->name = name;
        this->playsInLeague = playsInLeague;
    }

    TennisPlayer(const TennisPlayer & other){
        cout<<"TennisPlayer cpy-constructor"<<endl;
        this->name = other.name;
        this->playsInLeague = other.playsInLeague;
    }

    void print (){
        cout<<"TennisPlayer: "<<name<<" "<< (playsInLeague ? "plays in league" : "doesn't play in league")<<endl;
    }

    friend ostream &operator<<(ostream &os, const TennisPlayer &player) {
        os<<"TennisPlayer: "<<player.name<<" "<< (player.playsInLeague ? "plays in league" : "doesn't play in league");
        return os;
    }

    ~TennisPlayer(){
        cout<<"TennisPlayer desctructor"<<endl;
    }
};

class RankedTennisPlayer : public TennisPlayer{
private:
    int rank;
public:
    RankedTennisPlayer(string name = " ", bool playsInLeague = false, int rank = 0) : TennisPlayer(name, playsInLeague){
        cout<<"RankedTennisPlayer constructor"<<endl;
        this->rank = rank;
    }

    RankedTennisPlayer(const TennisPlayer & tp, int rank) : TennisPlayer(tp){
        this->rank = rank;
    }

    RankedTennisPlayer(const RankedTennisPlayer & other) : TennisPlayer(other){
        this->rank = other.rank;
    }

    friend ostream &operator<<(ostream &os, const RankedTennisPlayer &player) {
        os<<"Ranked";
        TennisPlayer tmp(player);
        os<<tmp<<", is ranked "<<player.rank;
        return os;
    }

    ~RankedTennisPlayer(){
        cout<<"RankedTennisPlayer desctructor"<<endl;
    }
};

int main (){

//    TennisPlayer tp ("Novak Djokovic", true);
//    cout<<tp<<endl;
//
//    RankedTennisPlayer rtp (tp, 1);
//    cout<<rtp<<endl;

    RankedTennisPlayer rtp("Novak Djokovic", true, 1);
//    cout<<rtp<<endl;

    TennisPlayer tp = rtp;
    cout<<tp;
return 0;
}