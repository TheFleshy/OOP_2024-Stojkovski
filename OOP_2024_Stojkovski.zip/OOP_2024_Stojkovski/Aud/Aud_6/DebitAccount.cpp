#include <iostream>
#include <string>
using namespace std;

class DebitAccount {
protected:
    string nameSurname;
    string number;
    double balance;
public:
    DebitAccount(string nameSurname = " ", string number = "111111111111111", double balance = 0){
        this->nameSurname = nameSurname;
        this->number = number;
        this->balance = balance;
    }

    DebitAccount(const DebitAccount & other){
        this->nameSurname = other.nameSurname;
        this->number = other.number;
        this->balance = other.balance;
    }

    void printReport(){ //operator <<
        cout<<"Owner: "<<nameSurname<<endl;
        cout<<"Account number: "<<number<<endl;
        cout<<"Balance: "<<balance<<endl;
    }

    void deposit (double amount){
        balance+=amount;
    }

    void widhdraw (double amount){
        if (amount <= balance){
            balance-=amount;
        }else {
            cout<<"You don't have sufficient funds. Withdrawing "<<balance<<endl;
            balance=0;
        }
    }
};

class CreditAccount : public DebitAccount{
private:
    double limit;
    const double interest = 0.05;
    double debt;
public:
    CreditAccount(string nameSurname = " ", string number = "111111111111111", double balance = 0, double limit = 0) : DebitAccount(nameSurname, number, balance){
        this->limit = limit;
        this->debt = 0;
    }

    CreditAccount(const DebitAccount & da, double limit = 10000) : DebitAccount(da){
        this->limit = limit;
        this->debt = 0;
    }

    // overriding of the methods
    void printReport (){
        DebitAccount :: printReport();
        cout<<"Debit: "<<debt<<endl;
        cout<<"Limit: "<<limit<<endl;
    }

    void deposit (double amount){ // balance: 0 debt: 0 amount: 1000
        if (amount <= debt){
            debt-=amount;
        }else {
            balance+=(amount-debt);
            debt = 0;
        }
    }

    void widthdraw (double amount){ // balance: 1000 debt: 0 amount: 2000 limit: 2000 -> balance: 0 debt: 1000+kamata=1050
        if (balance >= amount){
            DebitAccount ::widhdraw(amount);
        }
        else { //balance<amount 1000, 2000
            double diff = amount - balance;
            if ((diff + debt) < limit){
                balance = 0;
                debt += (diff*(1+interest));
            }else {
                cout<<"You have exceeded your credit card limit!"<<endl;
            }
        }
    }
};

int main (){

    DebitAccount db("Andrej");
//    db.printReport();
    DebitAccount db1 ("Andrej", "123451234512345");
//    db1.printReport();
    DebitAccount db2 ("Andrej", "123451234512345", 1005.45);
//    db2.printReport();
//    db2.widhdraw(2000);

    CreditAccount ca(db2, 1000);
    ca.printReport();

    ca.widthdraw(900);
    ca.printReport();

    ca.widthdraw(300);
    ca.printReport();

    ca.widthdraw(300);
    ca.printReport();

    ca.widthdraw(300);
    ca.printReport();

    ca.widthdraw(300); //debt = 834.277
    ca.printReport();

    ca.deposit(5000);
    ca.printReport();

    return 0;
}