/// Primer za abstraktna klasa so go nema u Aud ama Stefan pocnuva so takov za da go objasnil :)
//za da e klasata abstraktna samo eden metod e dovolno da bide celosno apstrakten
// ne moze da se deklarira objekt od abstraktna klasa !

#include <iostream>
#include <string>
using namespace std;

class Animal {  // abstraktna klasa
protected:
    string name;
public:
    Animal(string name = ""){
        this->name = name;
    }

    virtual void makeSound() = 0;
};

class Dog : public Animal{
public:
    Dog(string name = " ") : Animal(name){
//        this->name = name;
    }

     void makeSound() {
        cout<<name<<" is making the sound afaf afaf"<<endl;
    }
};

class Cat : public Animal{
public:
    Cat(string name = " ") : Animal(name){
//        this->name = name;
    }

    void makeSound(){
        cout<<name<<" is making the sound maju mjau"<<endl;
    }
};

int main (){

//    Animal * a = new Animal("Stole");  // todo ovoa e eden nacin na polimofizam
//    a->makeSound();
//
//    Animal *dog = new Dog("sarko");
//    dog->makeSound();
//
//    Animal *cat = new Cat ("vesna");
//    cat->makeSound();

    Animal ** animals = new Animal * [3];   // todo ako iame polimorfizam so niza od pokazuvaci **

//    animals [0] = new Animal("Stole");
    animals [1] = new Dog("sarko");
    animals [2] = new Cat ("vesna");
    for (int i=0; i<3; i++){
        animals[i] ->makeSound();
    }

    //TODO mora da se cuva pokazuvaci koj osnovnata klasa, oti obicni objekti ne ovozmozuva polimorfizmot

    return 0;
}