//TODO dynamic cast - nacin kako moze da utvrdime dali pokazuvac kon osnovnata klasa e nekakva konkretna implementacija od izvedenata klasa, odnosno primer da daden shape moze da utvrdime dali e cuboid,cylnder,cone

#include <iostream>
#include <string>

using namespace std;

class Shape {
protected:
    double height;
    double base;
public:
    Shape(double height = 0, double base = 0) {
        this->height = height;
        this->base = base;
    }

    virtual void print() = 0;  // cisto virutelen oti uste ne se znae formata za pecatenje
    virtual double area() = 0;

    virtual double volume() = 0;

    double getHeight() {
        return height;
    }
};

class Cylinder : public Shape {
public:
    Cylinder(double height = 0, double base = 0) : Shape(height, base) {}

    double volume() {
        return base * base * 3.14 * height;
    }
    //TODO DODEKA NE GO IMPLEMENTIRAME PRINT, I OVIA KLASI ZA APSTRAKTNI

    void print(){
        cout<<"Cylinder with volume: "<<volume()<<endl;
    }

    double area(){}
};

class Cone : public Shape {
public:
    Cone(double height = 0, double base = 0) : Shape(height, base) {}

    double volume() {
        return 1.0 / 3 * base * base * height * 3.14;
    }
    //TODO DODEKA NE GO IMPLEMENTIRAME PRINT, I OVIA KLASI ZA APSTRAKTNI

    void print(){
        cout<<"Cone with volume: "<<volume()<<endl;
    }

    double area(){}
};

class Cuboid : public Shape {
private:
    double secondBase;
public:
    Cuboid(double height = 0, double base = 0, double secondBase = 0) : Shape(height, base) {
        this->secondBase = secondBase;
    }

    double volume() {
        return base * secondBase * height;
    }
    //TODO DODEKA NE GO IMPLEMENTIRAME PRINT, I OVIA KLASI ZA APSTRAKTNI

    void print(){
        cout<<"Cuboid with volume: "<<volume()<<endl;
    }

    double area(){}
};

void ShapeWithLargestVolume(Shape **shapes, int n){
    Shape * max = shapes[0];
    for (int i=0; i<n; i++){
        if (shapes[i]->volume() > max->volume()){
            max = shapes[i];
        }
    }
    max->print();
}

int countShapesWithCircleBase (Shape **shapes, int n){  // ke probame sekoja forma da ja napraeme so dynamic cast u cuboid znaci deka nema kruzna osnova
    int counter = 0;
    for (int i=0; i<n; i++){
        Cuboid * castedCuboid = dynamic_cast<Cuboid*>(shapes[i]); // sto kastirame e u zagradite, ako pokazuvaco e null kastiranjeto ne bilo uspesno
        if (castedCuboid == nullptr){
            ++counter;
        }
    }
    return counter;
} // realno mozese primer ako e type Cuboid da zgoleme countero, ama Stefan vika deka se gubila smislata na ovoa :)

int main() {

    int n;
    cin>>n;

    Shape **shapes = new Shape * [n];

    for (int i=0; i<n; i++){
        int type; // 1-Cylinder, 2-Cone, 3-Cuboid
        double height, base , secondBase;
        cin>>type>>height>>base;

        if (type == 1){
            shapes[i] = new Cylinder(height, base);
        }

        else if (type==2){
            shapes[i] = new Cone(height, base);
        }
        else{
            cin>>secondBase;
            shapes[i] = new Cuboid(height, base, secondBase);
        }
        shapes[i]->print(); //TODO da se iskomentira posle, a sekako nema :)
    }

    ShapeWithLargestVolume(shapes, n);
    cout<<"Number of shapes without a circle base is: "<<countShapesWithCircleBase(shapes, n);

    return 0;
}