// Потсетување за референци
//  Илустација од реален свет - ima nekoj meme, pojma neam

#include <iostream>
#include <cstring>
using namespace std;

struct Vraboten {
    char name[100];
    char position [100];
    double salary ;

    void read (){
        cin>>name>>position>>salary;
    }

    void print (){
        cout<<"Name: "<<name<<","<<" Position: "<<position<<","<<" Salary: "<<calculateSalary()<<endl;
    }

    double calculateSalary (){
        if (strcmp(position, "TA") == 0){
            return 1.10 * salary;
        }else if (strcmp(position, "Assistant Professor")== 0){
            return 1.50 * salary;
        }else if (strcmp(position, "Associate Professor")== 0){
            return 1.90 * salary;
        }else {
            return 2.4 * salary;
        }

    }

};

int main (){

    Vraboten vraboten;
    vraboten.read();
    vraboten.print();

    return 0;
}