// Од стандарден влез се читаат податоци за непознат број студенти (не повеќе од 100). Податоците се внесуваат така што во секој ред се состои од:

//името
//презимето
//бројот на индекс (формат xxyzzzz)
//четири броја (поени од секоја задача)
//со произволен број празни места или табулатори меѓу нив.

//Да се напише програма која ќе испечати список на студенти, каде во секој ред ќе има: презиме, име, број на индекс, вкупен број на бодови сортиран според бројот на бодови. При тоа имињата и презимињата да се напишат со голема почетна буква.

#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

void normalizeName (char name[]){
    name[0] = toupper(name[0]);
    for (int i=1; i< strlen(name); i++){
        name[i] = tolower(name[i]);
    }
}

struct Student {
    char firstName [100];
    char lastName [100];
    char index [10];
    int grades [40];
    int countGrades;

    void readStudent (){
        cin>>firstName>>lastName>>index>>countGrades;
        for (int i=0; i<countGrades; i++){
            cin>>grades[i];
        }
    }

    float average(){
        float suma = 0;
        for (int i=0; i<countGrades; i++){
            suma+=grades[i];
        }
        return suma / countGrades;
    }

    void printStudent (){
        normalizeName(firstName);
        normalizeName(lastName);
        cout<<firstName<<" "<<lastName<<" "<<index<<" "<<average()<<endl;
    }
};

void sort (Student *students, int n){
    Student tmp;
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            if (students[j].average() < students[j+1].average()){
                tmp = students[j];
                students[j] = students[j+1];
                students[j+1] = tmp;
            }
        }
    }
}


int main (){

    int n;
    cin>>n;

    Student students[100];

    for (int i=0; i<n; i++){
        students[i].readStudent();
    }

    sort(students, n);

    for (int i=0; i<n; i++){
        students[i].printStudent();
    }

    return 0;
}


