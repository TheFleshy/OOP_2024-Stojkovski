#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

class Transport {
protected:
    string destinacija;
    int osnovnaCena;
    int rastojanie;
public:
    Transport(string destinacija = "", int osnovnaCena = 0, int rastojanie = 0) {
        this->destinacija = destinacija;
        this->osnovnaCena = osnovnaCena;
        this->rastojanie = rastojanie;
    }
    ~Transport(){}
    Transport(const Transport & other){
        this->destinacija = other.destinacija;
        this->osnovnaCena = other.osnovnaCena;
        this->rastojanie = other.rastojanie;
    }

    bool operator<(const Transport &rhs) const {
        return rastojanie < rhs.rastojanie;
    }

    const string &getDestinacija() const {
        return destinacija;
    }

    int getOsnovnaCena() const {
        return osnovnaCena;
    }

    int getRastojanie() const {
        return rastojanie;
    }

    virtual double cenaTransport () = 0;

};

class AvtomobilTransport : public Transport {
private:
    bool sofer;
public:
    AvtomobilTransport(string destinacija = "", int osnovnaCena = 0, int rastojanie = 0, bool sofer = false) : Transport(destinacija, osnovnaCena, rastojanie){
        this->sofer = sofer;
    }
    ~AvtomobilTransport(){}
    AvtomobilTransport(const Transport & o, bool sofer) : Transport(o){
        this->sofer = sofer;
    }

    bool isSofer() const {
        return sofer;
    }

    void setSofer(bool sofer) {
        AvtomobilTransport::sofer = sofer;
    }

    double cenaTransport () override{
        if (sofer){
            return osnovnaCena * 1.20;
        }
        return osnovnaCena;
    }


};

class KombeTransport : public Transport{
private:
    int brLugje;
public:
    KombeTransport(string destinacija = "", int osnovnaCena = 0, int rastojanie = 0, int brLugje = 0) : Transport(destinacija, osnovnaCena, rastojanie){
        this->brLugje = brLugje;
    }
    ~KombeTransport(){}
    KombeTransport(const Transport & o, int brLugje) : Transport(o){
        this->brLugje = brLugje;
    }

    int getBrLugje() const {
        return brLugje;
    }

    void setBrLugje(int brLugje) {
        KombeTransport::brLugje = brLugje;
    }

    double cenaTransport () override{
        int brojacLugje = 0;
        for (int i=0; i<brLugje; i++){
            brojacLugje++;
        }
        return osnovnaCena - (brojacLugje * 200);
    }

};

//TODO OVAA FUNKCIJA NEZNAM DO NEKADE DA JA PRAAM, OTI TE ILI SO BUBBLE SORT E ILI SO VECTOR OTI IMA SORT... :(
void pecatiPoloshiPonudi(Transport **niza, int n, AvtomobilTransport T) {
//    vector<Transport*> filteredOffers;
//    double T_cena = T.cenaTransport();
//
//    for (int i = 0; i < n; ++i) {
//        if (niza[i]->cenaTransport() > T_cena) {
//            filteredOffers.push_back(niza[i]);
//        }
//    }
//
//    sort(filteredOffers.begin(), filteredOffers.end(), [](Transport* a, Transport* b) {
//        return a->getRastojanie() < b->getRastojanie();
//    });
//
//    for (Transport* offer : filteredOffers) {
//        cout << offer->getDestinacija() << " " << offer->getRastojanie() << " " << offer->cenaTransport() << endl;
//    }
    double T_cena = T.cenaTransport();
    Transport** filteredOffers = new Transport*[n];
    int filteredCount = 0;

    for (int i = 0; i < n; ++i) {
        if (niza[i]->cenaTransport() > T_cena) {
            filteredOffers[filteredCount++] = niza[i];
        }
    }

    // Bubble sort
    for (int i = 0; i < filteredCount - 1; ++i) {
        for (int j = 0; j < filteredCount - i - 1; ++j) {
            if (filteredOffers[j]->getRastojanie() > filteredOffers[j + 1]->getRastojanie()) {
                Transport* temp = filteredOffers[j];
                filteredOffers[j] = filteredOffers[j + 1];
                filteredOffers[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < filteredCount; ++i) {
        cout << filteredOffers[i]->getDestinacija() << " " << filteredOffers[i]->getRastojanie() << " " << filteredOffers[i]->cenaTransport() << endl;
    }

    delete[] filteredOffers;
}

int main(){

    char destinacija[20];
    int tip,cena,rastojanie,lugje;
    bool shofer;
    int n;
    cin>>n;
    Transport  **ponudi;
    ponudi=new Transport *[n];

    for (int i=0;i<n;i++){

        cin>>tip>>destinacija>>cena>>rastojanie;
        if (tip==1) {
            cin>>shofer;
            ponudi[i]=new AvtomobilTransport(destinacija,cena,rastojanie,shofer);

        }
        else {
            cin>>lugje;
            ponudi[i]=new KombeTransport(destinacija,cena,rastojanie,lugje);
        }


    }

    AvtomobilTransport nov("Ohrid",2000,600,false);
    pecatiPoloshiPonudi(ponudi,n,nov);

    for (int i=0;i<n;i++) delete ponudi[i];
    delete [] ponudi;
    return 0;
}
