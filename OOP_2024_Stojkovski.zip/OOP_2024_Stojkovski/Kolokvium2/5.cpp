#include <iostream>
#include <string>

using namespace std;

class UserExistsException {
    string text;
public:
    UserExistsException(string text) {
        this->text = text;
    }

    void print() {
        cout << text << endl;
    }
};

enum typeC {
    standard, loyal, vip
};

class Customer {
protected:
    string name;
    typeC t;
    static int popust; // static member
    static const int dopolnitelenPopust; // static const member
    int brKupeniProizvodi;
    string eAdresa;
public:
    Customer(string name = " ", string eAdresa = " ", typeC t = standard, int brKupeniProizvodi = 0) {
        this->name = name;
        this->eAdresa = eAdresa;
        this->t = t;
        this->brKupeniProizvodi = brKupeniProizvodi;
    }

    Customer(const Customer &other) {
        this->name = other.name;
        this->eAdresa = other.eAdresa;
        this->t = other.t;
        this->brKupeniProizvodi = other.brKupeniProizvodi;
    }

    Customer &operator=(const Customer &c) {
        if (this != &c) {
            this->name = c.name;
            this->eAdresa = c.eAdresa;
            this->t = c.t;
            this->brKupeniProizvodi = c.brKupeniProizvodi;
        }
        return *this;
    }

    typeC getT() const;

    void setT(typeC t);

    int getBrKupeniProizvodi() const;

    const string &getEAdresa() const {
        return eAdresa;
    }

    static int getPopust() {
        return popust;
    }

    static void setPopust(int newPopust) {
        popust = newPopust;
    }

    static int getDopolnitelenPopust() {
        return dopolnitelenPopust;
    }

    friend ostream &operator<<(ostream &os, const Customer &customer) {
        os << customer.name << endl;
        os << customer.eAdresa << endl;
        os << customer.brKupeniProizvodi << endl;
        if (customer.t == standard) {
            os << "standard ";
        } else if (customer.t == loyal) {
            os << "loyal ";
        } else {
            os << "vip ";
        }

        if (customer.t == standard) {
            os << Customer::popust * 0;
        } else if (customer.t == loyal) {
            os << Customer::getPopust();
        } else {
            os << Customer::getPopust() + Customer::getDopolnitelenPopust();
        }
        return os;
    }

    void setDiscount1(int i) { // todo ovoa ne neznam za koj kur e
        setPopust(i);
    }
};

int Customer::popust = 10;
const int Customer::dopolnitelenPopust = 20;

int Customer::getBrKupeniProizvodi() const {
    return brKupeniProizvodi;
}

typeC Customer::getT() const {
    return t;
}

void Customer::setT(typeC t) {
    Customer::t = t;
}

class FINKI_bookstore {
private:
    Customer *customers;
    int brKupuvaci;
public:
    FINKI_bookstore() {
        this->customers = nullptr;
        this->brKupuvaci = 0;
    }

    FINKI_bookstore(const FINKI_bookstore &other) {
        this->brKupuvaci = other.brKupuvaci;
        this->customers = new Customer[this->brKupuvaci];
        for (int i = 0; i < this->brKupuvaci; i++) {
            this->customers[i] = other.customers[i];
        }
    }

    ~FINKI_bookstore() {
        delete[] customers;
    }

    FINKI_bookstore &operator+=(const Customer &other) {
        for (int i = 0; i < brKupuvaci; i++) {
            if (customers[i].getEAdresa() == other.getEAdresa()) {
                throw UserExistsException("The user already exists in the list!");
            }
        }
        Customer *tmp = new Customer[brKupuvaci + 1];
        for (int i = 0; i < brKupuvaci; i++) {
            tmp[i] = customers[i];
        }
        tmp[brKupuvaci] = other;
        brKupuvaci++;
        delete[] customers;
        customers = tmp;
        return *this;
    }

    friend ostream &operator<<(ostream &os, const FINKI_bookstore &bookstore) {
        for (int i = 0; i < bookstore.brKupuvaci; i++) {
            os << bookstore.customers[i] << endl;
        }
        return os;
    }

    void setCustomers(Customer *customers, int n) {
        delete[] this->customers;
        this->customers = new Customer[n];
        for (int i = 0; i < n; i++) {
            this->customers[i] = customers[i];
        }
        this->brKupuvaci = n;
    }

//    void update() {
//        for (int i = 0; i < brKupuvaci; i++) {
//            int counter = 0;
//            if (customers[i].getBrKupeniProizvodi() > 5){
//                if (customers[i].getT() == standard){
//                    customers[i].setT(loyal);
//                }
//            }else if (customers[i].getBrKupeniProizvodi() > 10){
//                if (customers[i].getT() == loyal){
//                    customers[i].setT(vip);
//                }
//            }
//        }
//    }

    void update() {
        for (int i = 0; i < brKupuvaci; i++) {
            if (customers[i].getT() == standard && customers[i].getBrKupeniProizvodi() > 5) {
                customers[i].setT(loyal);
            } else if (customers[i].getT() == loyal && customers[i].getBrKupeniProizvodi() > 10) {
                customers[i].setT(vip);
            }
        }
    }
};

int main() {
    int testCase;
    cin >> testCase;

    char name[50];
    char email[50];
    int tC;
    int discount;
    int numProducts;


    if (testCase == 1) {
        cout << "===== Test Case - Customer Class ======" << endl;
        cin.get();
        cin.getline(name, 50);
        cin.getline(email, 50);
        cin >> tC;
        cin >> numProducts;
        cout << "===== CONSTRUCTOR ======" << endl;
        Customer c(name, email, (typeC) tC, numProducts);
        cout << c;

    }

    if (testCase == 2) {
        cout << "===== Test Case - Static Members ======" << endl;
        cin.get();
        cin.getline(name, 50);
        cin.getline(email, 50);
        cin >> tC;
        cin >> numProducts;
        cout << "===== CONSTRUCTOR ======" << endl;
        Customer c(name, email, (typeC) tC, numProducts);
        cout << c;
        cout << endl;
        c.setDiscount1(5);
        cout << c;
    }

    if (testCase == 3) {
        cout << "===== Test Case - FINKI-bookstore ======" << endl;
        FINKI_bookstore fc;
        int n;
        cin >> n;
        Customer customers[50];
        for (int i = 0; i < n; ++i) {
            cin.get();
            cin.getline(name, 50);
            cin.getline(email, 50);
            cin >> tC;
            cin >> numProducts;
            Customer c(name, email, (typeC) tC, numProducts);
            customers[i] = c;
        }

        fc.setCustomers(customers, n);

        cout << fc << endl;
    }

    if (testCase == 4) {
        cout << "===== Test Case - operator+= ======" << endl;
        FINKI_bookstore fc;
        int n;
        cin >> n;
        Customer customers[50];
        for (int i = 0; i < n; ++i) {
            cin.get();
            cin.getline(name, 50);
            cin.getline(email, 50);
            cin >> tC;
            cin >> numProducts;
            Customer c(name, email, (typeC) tC, numProducts);
            customers[i] = c;
        }

        fc.setCustomers(customers, n);
        cout << "OPERATOR +=" << endl;
        cin.get();
        cin.getline(name, 50);
        cin.getline(email, 50);
        cin >> tC;
        cin >> numProducts;
        Customer c(name, email, (typeC) tC, numProducts);
        try {
            fc += c;
        }
        catch (UserExistsException &e) {
            e.print();
        }
        cout << fc;
    }

    if (testCase == 5) {
        cout << "===== Test Case - operator+= (exception) ======" << endl;
        FINKI_bookstore fc;
        int n;
        cin >> n;
        Customer customers[50];
        for (int i = 0; i < n; ++i) {
            cin.get();
            cin.getline(name, 50);
            cin.getline(email, 50);
            cin >> tC;
            cin >> numProducts;
            Customer c(name, email, (typeC) tC, numProducts);
            customers[i] = c;
        }

        fc.setCustomers(customers, n);
        cout << "OPERATOR +=" << endl;
        cin.get();
        cin.getline(name, 50);
        cin.getline(email, 50);
        cin >> tC;
        cin >> numProducts;
        Customer c(name, email, (typeC) tC, numProducts);
        try {
            fc += c;
        }
        catch (UserExistsException &e) {
            e.print();
        }
        cout << fc;
    }

    if (testCase == 6) {
        cout << "===== Test Case - update method  ======" << endl << endl;
        FINKI_bookstore fc;
        int n;
        cin >> n;
        Customer customers[50];
        for (int i = 0; i < n; ++i) {
            cin.get();
            cin.getline(name, 50);
            cin.getline(email, 50);
            cin >> tC;
            cin >> numProducts;
            Customer c(name, email, (typeC) tC, numProducts);
            customers[i] = c;
        }

        fc.setCustomers(customers, n);

        cout << "Update:" << endl;
        fc.update();
        cout << fc;
    }
    return 0;

}
