#include <iostream>
#include <string>
using namespace std;

class Vozac {
protected:
    string name;
    int vozrast;
    int brTrki;
    bool veteran;
public:
    Vozac(string name = " ", int vozrast = 0, int brTrki = 0, bool veteran = false){
        this->name = name;
        this->vozrast = vozrast;
        this->brTrki = brTrki;
        this->veteran = veteran;
    }

    Vozac(const Vozac & other){
        this->name = other.name;
        this->vozrast = other.vozrast;
        this->brTrki = other.brTrki;
        this->veteran = other.veteran;
    }

    friend ostream &operator<<(ostream &os, const Vozac &vozac) {
        os<<vozac.name<<endl;
        os<<vozac.vozrast<<endl;
        os<<vozac.brTrki<<endl;
        if (vozac.veteran == 1){
            cout<<"VETERAN"<<endl;
        }
        return os;
    }


    //TODO ovoa ne e tesko ako imas tocno napraeno so virutal
    bool operator==(const Vozac &rhs) const {
        return this-> zarabotuvacka() == rhs.zarabotuvacka();
    }

    virtual int zarabotuvacka() const = 0;   //TODO zapomoni deka mozes i vaka samo da gi praes virtual oni sa bitni za da moze od drugite klasi spored toa za koe se odnasa da zgolemuva inace dava osnovna vrednost
    virtual double danok() const = 0;        //TODO zapomoni deka mozes i vaka samo da gi praes virtual oni sa bitni za da moze od drugite klasi spored toa za koe se odnasa da zgolemuva inace dava osnovna vrednost

    ~Vozac(){}
};

class Avtomobilist : public Vozac {
private:
    float cenaAvtomobil;
public:
    Avtomobilist(string name = " ", int vozrast = 0, int brTrki = 0, bool veteran = false, float cenaAvtomobil = 0) : Vozac(name, vozrast, brTrki, veteran){
        this->cenaAvtomobil = cenaAvtomobil;
    }

    Avtomobilist(const Vozac & a, float cenaAvtomobil = 1000) : Vozac(a){
        this->cenaAvtomobil = cenaAvtomobil;
    }

    virtual int zarabotuvacka() const override {
        return cenaAvtomobil / 5;
    }

    virtual double danok() const override{
        double newPrice = zarabotuvacka();
        if (brTrki > 10){
            return newPrice * 0.15;
        }else {
           return newPrice * 0.10;
        }

    }
};

class Motociklist : public Vozac {
private:
    int moknost;
public:
    Motociklist(string name = " ", int vozrast = 0, int brTrki = 0, bool veteran = false, int moknost = 0) : Vozac(name, vozrast, brTrki, veteran){
        this->moknost = moknost;
    }

    Motociklist(const Vozac & v, int moknost = 1000) : Vozac(v){
        this->moknost = moknost;
    }

    virtual int zarabotuvacka() const override{
        return moknost * 20;
    }

    virtual double danok() const override{
        double newPrice = zarabotuvacka();
        if (veteran == 1){
            return newPrice * 0.25;
        }
        else {
           return newPrice * 0.20;
        }

    }

};

int soIstaZarabotuvachka(Vozac **drivers, int n, const Vozac *vozacX){   // TODO OVOA NE MI E JASNO..
    int brIsti = 0;
    for (int i=0; i<n; i++){
        int zarabotuvackaVozac = drivers[i]->zarabotuvacka();
        if (zarabotuvackaVozac == vozacX->zarabotuvacka()){
            brIsti++;
        }
    }
    return brIsti;
}


int main() {
    int n, x;
    cin >> n >> x;
    Vozac **v = new Vozac*[n];
    char ime[100];
    int vozrast;
    int trki;
    bool vet;
    for(int i = 0; i < n; ++i) {
        cin >> ime >> vozrast >> trki >> vet;
        if(i < x) {
            float cena_avto;
            cin >> cena_avto;
            v[i] = new Avtomobilist(ime, vozrast, trki, vet, cena_avto);
        } else {
            int mokjnost;
            cin >> mokjnost;
            v[i] = new Motociklist(ime, vozrast, trki, vet, mokjnost);
        }
    }
    cout << "=== DANOK ===" << endl;
    for(int i = 0; i < n; ++i) {
        cout << *v[i];
        cout << v[i]->danok() << endl;
    }
    cin >> ime >> vozrast >> trki >> vet;
    int mokjnost;
    cin >> mokjnost;
    Vozac *vx = new Motociklist(ime, vozrast, trki, vet, mokjnost);
    cout << "=== VOZAC X ===" << endl;
    cout << *vx;
    cout << "=== SO ISTA ZARABOTUVACKA KAKO VOZAC X ===" << endl;
    cout << soIstaZarabotuvachka(v, n, vx);
    for(int i = 0; i < n; ++i) {
        delete v[i];
    }
    delete [] v;
    delete vx;
    return 0;
}