#include <iostream>
#include <string>
using namespace std;

class Kvadrat {
protected:
    double dolzina;
public:
    Kvadrat(double dolzina = 0){
        this->dolzina = dolzina;
    }
    ~Kvadrat(){}

    Kvadrat(const Kvadrat & other){
        this->dolzina = other.dolzina;
    }

//    Kvadrat operator = (const Kvadrat & k){ // ovoa si go vezbam mislam deka ne treba
//        if (this!=&k){
//            this->dolzina = k.dolzina;
//        }
//        return *this;
//    }

    double perimetar(){
        return 4*dolzina;
    }

    double plostina(){
        return dolzina*dolzina;
    }

    void pecati(){ // neam go maino za da vidam kako e tocno, a pisa da se vide .. (prepotsavka)
        cout<<"Kvadrat so dolzina a="<<dolzina<<" ima plostina P="<<plostina()<<" i perimetar L="<<perimetar()<<endl;
    }
};

class Pravoagolnik : public Kvadrat {
private:
    double x;
    double y;
public:
    Pravoagolnik(double dolzina = 0, double x = 0, double y = 0) : Kvadrat(dolzina){
        this->x = x;
        this->y = y;
    }

    Pravoagolnik(const Kvadrat &k, double x, double y) : Kvadrat(k){
        this->x = x;
        this->y = y;
    }
    ~Pravoagolnik(){}

    Pravoagolnik(const Pravoagolnik & other){
        this->dolzina = other.dolzina;
        this->x = other.x;
        this->y = other.y;
    }

    double perimetar(){
        return Kvadrat::perimetar() + 2*x + 2*y;
    }

    double plostina(){
        return Kvadrat::plostina() + dolzina*y + dolzina*x + x*y;
    }

    void pecati(){ // neam main taka da odeme pa so pretposavka
        if (x == y){
            dolzina+=x;
            Kvadrat::pecati();
            return;
        }
        cout<<"Pravoagolnik so strani: "<<dolzina+x<<" i "<<dolzina+y<<" ima plostina P="<<plostina()<<" i perimetar L="<<perimetar()<<endl;
    }

};

int main() {
    int n;
    double a,x,y;
    Kvadrat * kvadrati;
    Pravoagolnik * pravoagolnici;

    cin>>n;

    kvadrati = new Kvadrat [n];
    pravoagolnici = new Pravoagolnik [n];

    for (int i=0;i<n;i++){
        cin>>a;

        kvadrati[i] = Kvadrat(a);
    }

    for (int i=0;i<n;i++){
        cin>>x>>y;

        pravoagolnici[i]=Pravoagolnik(kvadrati[i],x,y);
    }

    int testCase;
    cin>>testCase;

    if (testCase==1){
        cout<<"===Testiranje na klasata Kvadrat==="<<endl;
        for (int i=0;i<n;i++)
            kvadrati[i].pecati();
    }
    else {
        cout<<"===Testiranje na klasata Pravoagolnik==="<<endl;
        for (int i=0;i<n;i++)
            pravoagolnici[i].pecati();
    }
}