#include <iostream>
#include <string>

using namespace std;

class Athlete{
protected:
    string name;
    int age;
public:
    Athlete(string name = " ", int age= 0){
        this->name = name;
        this->age = age;
    }

    Athlete(const Athlete & o){
        this->name = o.name;
        this->age = o.age;
    }

    virtual ~Athlete(){}

    virtual void displayInfo() = 0;
};

class Runner : virtual public Athlete{
public:
    double speed;
    Runner(string name = " ", int age= 0, double speed = 0) : Athlete(name, age){
        this->speed = speed;
    }

    Runner(const Athlete & o, double speed) : Athlete(o){
        this->speed = speed;
    }

    void displayInfo() override {
        cout << "Athlete: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Speed: " << speed << " mph";
    }
};

class Jumper : virtual public Athlete{
public:
    double height;
    Jumper(string name = " ", int age= 0, double height = 0) : Athlete(name, age){
        this->height = height;
    }

    Jumper(const Athlete & a, double height): Athlete(a){
        this->height = height;
    }

    void displayInfo() override{
        cout << "Athlete: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Height: " << height << "m";
    }
};

class AllRoundAthlete : public Runner, public Jumper{
public:
    int stamina;
    AllRoundAthlete(string name = " ", int age= 0, double speed = 0, double height = 0, int stamina = 0){
        this->name = name;
        this->age = age;
        this->speed = speed;
        this->height = height;
        this->stamina = stamina;
    }

    void displayInfo() override{
        cout << "Athlete: " << name << endl;
        cout << "Age: " << age << endl;
        cout<<"Speed: "<<speed<<" mph"<<endl;
        cout<<"Height: "<<height<<"m"<<endl;
        cout << "Stamina: " << stamina;
    }
};

Athlete* findAthleteWithMaxValue(Athlete** athletes, int n){
    double highest = 0;
    Athlete *max = nullptr;
    for(int i=0; i<n; i++){
        Runner *r = dynamic_cast<Runner *>(athletes[i]);
        Jumper *j = dynamic_cast<Jumper *>(athletes[i]);
        if(r){
            if(r->speed>highest){
                highest=r->speed;
                max = athletes[i];
            }
        } else{
            if(j->height>highest){
                highest=j->height;
                max = athletes[i];
            }
        }
    }
    return max;
}

int main() {
    char name[50];
    int age;
    double speed;
    double height;
    int n;
    int choice;

    cin>>choice;
    if(choice==1)
    {
        cin>>name;
        cin>>age;
        AllRoundAthlete allRoundAthlete(name, age, 13.6, 1.80, 6);
        allRoundAthlete.displayInfo();
    }
    else {

        cin >> n;

        Athlete **athletes = new Athlete *[n];
        for (int i = 0; i < n; i++) {
            cin >> choice;
            if (choice == 1) {
                cin >> name >> age >> speed;

                athletes[i] = new Runner(name, age, speed);
            } else {
                cin >> name >> age >> height;

                athletes[i] = new Jumper(name, age, height);
            }

        }

        findAthleteWithMaxValue(athletes, n)->displayInfo();

    }


    return 0;
}