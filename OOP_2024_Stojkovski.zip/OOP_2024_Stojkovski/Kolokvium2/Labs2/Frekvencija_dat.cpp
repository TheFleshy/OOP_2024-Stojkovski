#include <iostream>
#include <fstream>
#include <cctype>
#include <iomanip>

using namespace std;

void writeToFile() {
    std::ofstream outFile("text.txt");
    char c;
    while ((c = std::cin.get()) != '#') {
        outFile.put(c);
    }
    outFile.close();
}

int main() {
    writeToFile();

    ifstream inFile("text.txt");

    double vkupnoKarakteri = 0;
    double golemiBukvi = 0;
    double maliBukvi = 0;

    char c;
    while (inFile.get(c)) {
        if (isalpha(c)) {
            vkupnoKarakteri++;
            if (islower(c)) {
                maliBukvi++;
            } else if (isupper(c)) {
                golemiBukvi++;
            }
        }
    }

    double relMaliBukvi = maliBukvi / vkupnoKarakteri;
    double relGolemiBukvi = golemiBukvi / vkupnoKarakteri;

    cout <<fixed<<setprecision(4)<<relGolemiBukvi<<endl;
    cout <<fixed<<setprecision(4)<<relMaliBukvi<<endl;

    return 0;
}