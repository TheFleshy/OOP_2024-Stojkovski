#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class TextTransformer {
private:
    static void replaceAll(string& s, const string& search, const string& replace) {
        size_t pos = 0;
        while ((pos = s.find(search, pos)) != string::npos) {
            s.replace(pos, search.length(), replace);
            pos += replace.length();
        }
    }

public:
    static string& periodsToQuestionMarks(string& s) {
        replaceAll(s, ".", "?");
        return s;
    }

    static string& fixCommonPunctuationErrors(string& s) {
        replaceAll(s, " but ", ", but ");
        replaceAll(s, " however ", ", however ");
        replaceAll(s, " although ", ", although ");
        return s;
    }

    static int sumNumbersOccurringInString(string& s) {
        stringstream ss(s);
        int sum = 0;
        string word;
        while (ss >> word) {
            try {
                sum += stoi(word);
            } catch (...) {
                // Ignore if word is not a number
            }
        }
        return sum;
    }

    // DON'T CHANGE ANY OF THE CODE BELOW!
public:
    static string& transformString(string& s) {
        periodsToQuestionMarks(s);
        fixCommonPunctuationErrors(s);
        string numbers = to_string(sumNumbersOccurringInString(s));
        return s.append(" SUM: ").append(numbers);
    }
};

int main() {
    string s;
    do {
        getline(cin, s);
        cout << TextTransformer::transformString(s) << endl;
    } while (s.find("END") == string::npos);
    return 0;
}
