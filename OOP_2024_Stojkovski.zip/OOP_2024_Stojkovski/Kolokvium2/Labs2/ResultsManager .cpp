//TODO VAKVA ZADACA NA VAKOV NACIN NE SME RESAVALE NEZNAM OD DEKA IM E TEKNALO DA JA STAVAT ...

#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class ResultsManager {
public:
    static string simplifyFormat(const string& line) {
        string simplifiedLine = line;
        size_t pos = simplifiedLine.find('X');
        while (pos != string::npos) {
            simplifiedLine.replace(pos, 1, "50");
            pos = simplifiedLine.find('X', pos + 2); // Move past replaced 'X'
        }
        return simplifiedLine;
    }

    static int calculateResult(const string& line) {
        stringstream ss(line);
        int totalPoints = 0;
        int points;
        while (ss >> points) {
            totalPoints += points;
        }
        return totalPoints;
    }
};

int main() {
    string lines[2];
    getline(cin, lines[0]);
    getline(cin, lines[1]);
    int score1 = ResultsManager::calculateResult(ResultsManager::simplifyFormat(lines[0]));
    int score2 = ResultsManager::calculateResult(ResultsManager::simplifyFormat(lines[1]));
    cout << "Player " << ((score1 > score2) ? "1 " : "2 ") << "wins with " << abs(score1 - score2) << " additional points.";
    return 0;
}