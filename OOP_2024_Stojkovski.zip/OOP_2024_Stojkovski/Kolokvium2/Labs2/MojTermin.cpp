//TODO TOCNO E SAMO MORA DA JA PROVERAM DEKA GRESAM OTI NE PECATE NESTO PRAVE PROBLEM NEKOJ ...
#include <iostream>
#include <string>
using namespace std;

class Lekar{
protected:
    int faksimal;
    string name;
    string surname;
    double salary;
public:
    Lekar(int faksimal = 0, string name = "", string surname = " ", double salary = 0){
        this->faksimal = faksimal;
        this->name = name;
        this->surname = surname;
        this->salary = salary;
    }

    Lekar(const Lekar & other){
        this->faksimal = other.faksimal;
        this->name = other.name;
        this->surname = other.surname;
        this->salary = other.salary;
    }

    ~Lekar(){}

    Lekar &operator = (const Lekar & l){
        if (this!=&l){
            this->faksimal = l.faksimal;
            this->name = l.name;
            this->surname = l.surname;
            this->salary = l.salary;
        }
        return * this;
    }

    void pecati(){
        cout<<faksimal<<": "<<name<<" "<<surname<<endl;
    }

    double plata(){ // taka ja razbrah za sa sa
        return salary;
    }

};

class MaticenLekar : public Lekar{
private:
    int brPacienti;
    double * kotizacii;
public:
    MaticenLekar(int faksimal = 0, string name = "", string surname = " ", double salary = 0, int brPacienti = 0) : Lekar(faksimal, name, surname, salary){
        this->brPacienti = brPacienti;
        this->kotizacii = new double [0];
    }

    MaticenLekar(const Lekar & l, int brPacienti, double * kotizacii) : Lekar(l){
        this->brPacienti = brPacienti;
        for(int i=0; i<brPacienti; i++){
            this->kotizacii[i] = kotizacii[i];
        }
    }

    ~MaticenLekar(){}

    MaticenLekar &operator = (const MaticenLekar & ml){ // neznam dali treba ovoa da go ima ama mislam ne :)
        if (this!=&ml){
            delete [] kotizacii;
            this->brPacienti = ml.brPacienti;
            this->kotizacii = ml.kotizacii;
        }
        return *this;
    }

    double average() {
        double sum = 0.0;
        for (int i=0;i<brPacienti;i++)
            sum+=kotizacii[i];
        return sum/brPacienti*1.0;
    }

    void pecati(){
        Lekar ::pecati();
        cout<<"Prosek na kotizacii: "<<average()<<endl;
    }

    double plata(){ // nogu losho objasneno ovoa
        return Lekar::plata() + 0.3 * average();
    }

};


int main() {
    int n;
    cin>>n;
    int pacienti;
    double kotizacii[100];
    int faksimil;
    char ime [20];
    char prezime [20];
    double osnovnaPlata;

    Lekar * lekari = new Lekar [n];
    MaticenLekar * maticni = new MaticenLekar [n];

    for (int i=0;i<n;i++){
        cin >> faksimil >> ime >> prezime >> osnovnaPlata;
        lekari[i] = Lekar(faksimil,ime,prezime,osnovnaPlata);
    }

    for (int i=0;i<n;i++){
        cin >> pacienti;
        for (int j=0;j<pacienti;j++){
            cin >> kotizacii[j];
        }
        maticni[i]=MaticenLekar(lekari[i],pacienti,kotizacii);
    }

    int testCase;
    cin>>testCase;

    if (testCase==1){
        cout<<"===TESTIRANJE NA KLASATA LEKAR==="<<endl;
        for (int i=0;i<n;i++){
            lekari[i].pecati();
            cout<<"Osnovnata plata na gorenavedeniot lekar e: "<<lekari[i].plata()<<endl;
        }
    }
    else {
        cout<<"===TESTIRANJE NA KLASATA MATICENLEKAR==="<<endl;
        for (int i=0;i<n;i++){
            maticni[i].pecati();
            cout<<"Platata na gorenavedeniot maticen lekar e: "<<maticni[i].plata()<<endl;
        }
    }

    delete [] lekari;
    delete [] maticni;

    return 0;
}


//#include<iostream>
//#include <string>
//using namespace std;
//
//class Lekar {
//protected:
//    int faksimil;
//    string ime;
//    string prezime ;
//    double osnovnaPlata;
//
//public:
//    Lekar(int faksimil=0, char * ime="", char * prezime="", double osnovnaPlata=0.0) {
//        this->faksimil=faksimil;
//        this->ime = ime;
//        this->prezime = prezime;
//        this->osnovnaPlata=osnovnaPlata;
//    }
//
//    Lekar (const Lekar &l){
//        this->faksimil=l.faksimil;
//        this->ime = l.ime;
//        this->prezime = l.prezime;
//        this->osnovnaPlata=l.osnovnaPlata;
//    }
//
//    Lekar &operator = (const Lekar &l){
//        if (this!=&l){
//            this->faksimil=l.faksimil;
//            this->ime = l.ime;
//            this->prezime = l.prezime;
//            this->osnovnaPlata=l.osnovnaPlata;
//        }
//        return *this;
//    }
//
//    void pecati() {
//        cout<<faksimil<<": "<<ime<<" "<<prezime<<endl;
//    }
//
//    double plata() {
//        return osnovnaPlata;
//    }
//};
//
//class MaticenLekar : public Lekar {
//    int pacienti;
//    double * kotizacii;
//public:
//
//    MaticenLekar () : Lekar() {
//        this->pacienti = 0;
//        this->kotizacii = new double[0];
//    }
//    MaticenLekar (Lekar l, int pacienti = 0, double * kotizacii = 0) : Lekar(l){
//        this -> pacienti = pacienti;
//
//        this->kotizacii = new double [pacienti];
//        for (int i=0;i<pacienti;i++)
//            this->kotizacii[i]=kotizacii[i];
//    }
//
//    MaticenLekar (const MaticenLekar &ml){
//        this->faksimil = ml.faksimil;
//        this->ime = ml.ime;
//        this->prezime = ml.prezime;
//        this->osnovnaPlata=ml.osnovnaPlata;
//        this->pacienti = ml.pacienti;
//        this->kotizacii = new double [this->pacienti];
//        for (int i=0;i<pacienti;i++)
//            this->kotizacii[i]=ml.kotizacii[i];
//    }
//
//    MaticenLekar &operator = (const MaticenLekar &ml){
//        if (this!=&ml){
//            delete [] kotizacii;
//            this->faksimil = ml.faksimil;
//            this->ime = ml.ime;
//            this->prezime = ml.prezime;
//            this->osnovnaPlata=ml.osnovnaPlata;
//            this->pacienti = ml.pacienti;
//            this->kotizacii = new double [this->pacienti];
//            for (int i=0;i<pacienti;i++)
//                this->kotizacii[i]=ml.kotizacii[i];
//        }
//
//        return *this;
//    }
//
//    double average() {
//        double sum = 0.0;
//        for (int i=0;i<pacienti;i++)
//            sum+=kotizacii[i];
//        return sum/pacienti*1.0;
//    }
//
//    void pecati() {
//        Lekar::pecati();
//        cout<<"Prosek na kotizacii: "<<average()<<endl;
//    }
//
//    double plata() {
//        return Lekar::plata() + 0.3 * average();
//    }
//
//    ~MaticenLekar() {
//        delete [] kotizacii;
//    }
//
//
//};
//
//int main() {
//    int n;
//    cin>>n;
//    int pacienti;
//    double kotizacii[100];
//    int faksimil;
//    char ime [20];
//    char prezime [20];
//    double osnovnaPlata;
//
//    Lekar * lekari = new Lekar [n];
//    MaticenLekar * maticni = new MaticenLekar [n];
//
//    for (int i=0;i<n;i++){
//        cin >> faksimil >> ime >> prezime >> osnovnaPlata;
//        lekari[i] = Lekar(faksimil,ime,prezime,osnovnaPlata);
//    }
//
//    for (int i=0;i<n;i++){
//        cin >> pacienti;
//        for (int j=0;j<pacienti;j++){
//            cin >> kotizacii[j];
//            //cout << kotizacii[j]<<endl;
//        }
//        maticni[i]=MaticenLekar(lekari[i],pacienti,kotizacii);
//        //cout << pacienti << endl;
//    }
//
//    int testCase;
//    cin>>testCase;
//    //cout<<testCase;
//
//    if (testCase==1){
//        cout<<"===TESTIRANJE NA KLASATA LEKAR==="<<endl;
//        for (int i=0;i<n;i++){
//            lekari[i].pecati();
//            cout<<"Osnovnata plata na gorenavedeniot lekar e: "<<lekari[i].plata()<<endl;
//        }
//    }
//    else {
//        cout<<"===TESTIRANJE NA KLASATA MATICENLEKAR==="<<endl;
//        for (int i=0;i<n;i++){
//            maticni[i].pecati();
//            cout<<"Platata na gorenavedeniot maticen lekar e: "<<maticni[i].plata()<<endl;
//        }
//    }
//
//    delete [] lekari;
//    delete [] maticni;
//
//    return 0;
//}