#include <iostream>
#include <string>

using namespace std;

class Hero{
protected:
    string name;
    float attackDamage;
    float attackSpeed;
    float abilityPower;
public:
    Hero(string name = " ", float attackDamage = 0, float attackSpeed = 0, float abilityPower = 0){
        this->name = name;
        this->attackDamage = attackDamage;
        this->attackSpeed = attackSpeed;
        this->abilityPower = abilityPower;
    }

    virtual ~Hero(){}

    Hero (const Hero & other){
        this->name = other.name;
        this->attackDamage = other.attackDamage;
        this->attackSpeed = other.attackSpeed;
        this->abilityPower = other.abilityPower;
    }
    virtual void displayInfo() = 0;
    virtual float power() = 0;
};

class LegendaryHero : virtual public Hero {
public:
    int hiddenPowers;
    LegendaryHero (string name = " ", float attackDamage = 0, float attackSpeed = 0, float abilityPower = 0, int hiddenPowers = 0) : Hero(name, attackDamage, attackSpeed, abilityPower){
        this->hiddenPowers = hiddenPowers;
    }

    LegendaryHero(const Hero & o, int hiddenPowers) : Hero(o){
        this->hiddenPowers = hiddenPowers;
    }

    float power() override{
        return (0.4*attackDamage*hiddenPowers)+(0.25*attackSpeed*hiddenPowers)+(0.35*abilityPower*hiddenPowers);
    }

    void displayInfo() override{
        cout<<"LegendaryHero: "<<name<<endl;
        cout<<"Number of hidden powers: "<<hiddenPowers<<endl;
        cout<<"Attack damage: "<<attackDamage<<endl;
        cout<<"Attack speed: "<<attackSpeed<<endl;
        cout<<"Ability power: "<<abilityPower<<endl;
        cout<<"Power: "<<power();
    }
};

class SuperHero : virtual public Hero{
public:
    bool isShapeshifter;
    SuperHero(string name = " ", float attackDamage = 0, float attackSpeed = 0, float abilityPower = 0, bool isShapeshifter = false) : Hero(name, attackDamage, attackSpeed, abilityPower){
        this->isShapeshifter = isShapeshifter;
    }

    SuperHero(const Hero & o, bool isShapeshifter){
        this->isShapeshifter = isShapeshifter;
    }

    float power() override{
        if (isShapeshifter){
           return 2*(attackDamage+attackSpeed+abilityPower);
        }else {
            return attackDamage+attackSpeed+abilityPower;
        }
    }

    void displayInfo() override{
        cout<<"SuperHero: "<<name<<endl;
        (isShapeshifter) ? cout << "Yes"<<endl : cout << "No" << endl;
        cout<<"Attack damage: "<<attackDamage<<endl;
        cout<<"Attack speed: "<<attackSpeed<<endl;
        cout<<"Ability power: "<<abilityPower<<endl;
        cout<<"Power: "<<power();
    }
};

class LegendarySuperHero : public LegendaryHero, public SuperHero{
public:
    LegendarySuperHero(string name = " ", float attackDamage = 0, float attackSpeed = 0, float abilityPower = 0, int hiddenPowers = 0,bool isShapeshifter = false ){
        this->name = name;
        this->attackDamage = attackDamage;
        this->attackSpeed = attackSpeed;
        this->abilityPower = abilityPower;
        this->hiddenPowers = hiddenPowers;
        this->isShapeshifter = isShapeshifter;
    }

    float power() override{
        return (LegendaryHero::power() + SuperHero::power())/2;
    }

    void displayInfo() override{
        cout<<"LegendarySuperHero: "<<name<<endl;
        cout<<"Attack damage: "<<attackDamage<<endl;
        cout<<"Attack speed: "<<attackSpeed<<endl;
        cout<<"Ability power: "<<abilityPower<<endl;
        cout<<"Power: "<<power();
    }
};

Hero *mostPowerfulLegendaryHero(Hero **heroes, int n) {  // TODO OVAA ZADACA JA POGLEDNI
    Hero * powerful = nullptr;

    for (int i=0; i<n; i++){
        if (dynamic_cast<LegendaryHero*>(heroes[i])) {
            if (!powerful || heroes[i]->power() > powerful->power()){
                powerful = heroes[i];
            }
        }
    }
    return  powerful;
}

int main() {
    char name[50];
    double attackDamage;
    double attackSpeed;
    double abilityPower;
    int hiddenPowers;
    bool isShapeshifter;
    int n;
    int choice;

    cin>>choice;
    if(choice==1)
    {
        cin>>name;
        LegendarySuperHero legendarySuperHero(name, 55, 43, 70, 2, true);
        legendarySuperHero.displayInfo();
    }
    else {

        cin >> n;

        Hero **h = new Hero *[n];
        for (int i = 0; i < n; i++) {
            cin >> choice;
            if (choice == 1) {
                cin >> name >> attackDamage >> attackSpeed >> abilityPower >> hiddenPowers;

                h[i] = new LegendaryHero(name, attackDamage, attackSpeed, abilityPower, hiddenPowers);
            } else {
                cin >> name >> attackDamage >> attackSpeed >> abilityPower >> isShapeshifter;

                h[i] = new SuperHero(name, attackDamage, attackSpeed, abilityPower, isShapeshifter);
            }

        }

        mostPowerfulLegendaryHero(h,n)->displayInfo();

    }


    return 0;
}