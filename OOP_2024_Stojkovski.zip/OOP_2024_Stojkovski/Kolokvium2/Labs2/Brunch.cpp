#include <iostream>
#include <string>
using namespace std;

enum Type {
    APPETIZER, MAINCOURSE, DESSERT
};

class Brunch {
private:
    int id;
    string name;
    float cena;
    Type tip;
public:
    Brunch(){

    }

    Brunch (string name, int id , float cena, int tip){
        this->name = name;
        this->id = id;
        this->cena = cena;
        this->tip = (Type)tip;
    }

    friend ostream &operator<<(ostream &os, const Brunch &brunch) {
        os<<brunch.name<<" "<<brunch.cena<<" "<<brunch.tip;
        return os;
    }

    bool operator==(const Brunch &rhs) const {
        return id == rhs.id;
    }

    Brunch & operator -= (float procent){
        this->cena -= procent;
        return * this;
    }

    ~Brunch(){}

};

class Restaurant {
private:
    string name;
    Brunch * obroci;
    int n;
    static int LOYAL_DISCOUNT;
public:
     Restaurant(string name = ""){
        this->name = name;
        this->obroci = new Brunch[0];
        this->n = 0;
    }

    ~Restaurant(){
         delete [] obroci;
     }

    static void setLOYAL_DISCOUNT(int discount) {
        LOYAL_DISCOUNT = discount;
    }

    static int getLOYAL_DISCOUNT() {
        return LOYAL_DISCOUNT;
    }

    Restaurant &operator += (const Brunch & other){
         Brunch * tmp = new Brunch [n+1];
         for (int i=0; i<n; i++){
             tmp[i] = obroci[i];
         }
         tmp[n++] = other;
         delete [] obroci;
         obroci = tmp;
        return * this;
     }

    bool operator>(const Restaurant &rhs) const {
        return n > rhs.n;
    }

    friend ostream &operator<<(ostream &os, const Restaurant &restaurant) {
        os<<restaurant.name<<endl;
        for (int i=0; i<restaurant.n; i++){
            os<<restaurant.obroci<<endl;
            os<<LOYAL_DISCOUNT<<endl;
        }
        return os;
    }



};

int Restaurant::LOYAL_DISCOUNT = 0.0f;

int main() {
    int test_case;
    cin >> test_case;
    switch (test_case) {
        case 0: {
            cout << "TESTING BRUNCH CONSTRUCTOR" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);

            cout << "TEST PASSED" << endl;
            break;
        }
        case 1: {
            cout << "TESTING BRUNCH OPERATOR <<" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);

            cout << appetizer;
            cout << mainCourse;
            cout << dessert;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 2: {
            cout << "TESTING BRUNCH OPERATOR -=" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);

            cout << appetizer;
            cout << mainCourse;
            cout << dessert;

            appetizer -= 10;
            mainCourse -= 20.2;
            mainCourse -= 25;

            cout << appetizer;
            cout << mainCourse;
            cout << dessert;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 3: {
            cout << "TESTING RESTAURANT CONSTRUCTOR and <<" << endl;

            Restaurant restaurant("Little Italy");
            cout << restaurant;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 4: {
            cout << "TESTING RESTAURANT OPERATOR += and <<" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);

            Restaurant restaurant("Little Italy");
            restaurant += appetizer;
            restaurant += mainCourse;
            restaurant += dessert;

            Restaurant::setLOYAL_DISCOUNT(15.5);
            cout << restaurant;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 5: {
            cout << "TESTING RESTAURANT OPERATOR += and <<" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);

            Restaurant restaurant("Little Italy");
            restaurant += appetizer;
            restaurant += mainCourse;
            restaurant += dessert;
            restaurant += dessert;

            Restaurant::setLOYAL_DISCOUNT(20);
            cout << restaurant;

            cout << "TEST PASSED" << endl;
            break;

        }
        case 6: {
            cout << "TESTING RESTAURANT COPY-CONSTRUCTOR and OPERATOR =" << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);
            Brunch appetizer1("Caprese", 4, 150, Type::APPETIZER);
            Brunch dessert1("Mousse", 5, 350, Type::DESSERT);

            Restaurant restaurant("Little Italy");
            restaurant += appetizer;
            restaurant += mainCourse;
            restaurant += dessert;

            Restaurant restaurant2(restaurant);
            Restaurant restaurant4;
            {
                Restaurant restaurant3("Galaxy");
                restaurant3 += appetizer1;
                restaurant3 += dessert1;
                restaurant4 = restaurant3;
            }

            cout << restaurant2;
            cout << restaurant4;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 7: {
            cout << "TESTING RESTAURANT OPERATOR > " << endl;

            Brunch appetizer("Salad", 1, 200, Type::APPETIZER);
            Brunch appetizer1("Caprese", 1, 150, Type::APPETIZER);
            Brunch mainCourse("Salmon", 2, 400, Type::MAINCOURSE);
            Brunch mainCourse1("Seafood", 2, 500, Type::MAINCOURSE);
            Brunch dessert("Cheesecake", 3, 300, Type::DESSERT);
            Brunch dessert1("Mousse", 4, 300, Type::DESSERT);


            Restaurant restaurant1("Little Italy");
            restaurant1 += appetizer;
            restaurant1 += mainCourse;
            restaurant1 += dessert;


            Restaurant restaurant2("Ember");
            restaurant2 += appetizer1;
            restaurant2 += mainCourse1;
            restaurant2 += dessert;
            restaurant2 += dessert1;


            if (restaurant2 > restaurant1) {
                cout << "TEST PASSED" << endl;
            }

            break;
        }
        case 8: {
            cout << "TESTING METHOD decrease" << endl;

            char rName[40];
            cin.ignore();
            cin.getline(rName, 40);
            Restaurant restaurant(rName);

            int n;
            cin >> n;

            char name[30];
            int id;
            float cost;
            int type;

            for (int i=0; i<n; i++) {
                cin.ignore();
                cin.getline(name,30);
                cin >> id;
                cin >> cost;
                cin >> type;

                Brunch brunch(name, id, cost, (Type)type);
                restaurant+=brunch;
                restaurant+=brunch;
            }

            float perc;
            cin >> perc;
            cin >> type;

            cout << restaurant;
//            restaurant.decrease((Type)type, perc);
            cout << restaurant;

            cout << "TEST PASSED" << endl;
            break;
        }
        case 9: {
            cout << "TESTING METHOD biggestMenuRestaurant" << endl;

            int n;
            cin >> n;
            Restaurant restaurants[n];

            char rName[40];

            for (int i=0; i<n; i++) {
                cin.ignore();
                cin.getline(rName, 40);
                Restaurant restaurant(rName);

                int m;
                cin >> m;

                char name[30];
                int id;
                float cost;
                int type;

                for (int j=0; j<m; j++) {
                    cin.ignore();
                    cin.getline(name,30);
                    cin >> id;
                    cin >> cost;
                    cin >> type;

                    Brunch brunch(name, id, cost, (Type)type);
                    restaurant+=brunch;
                }

                restaurants[i]=restaurant;

            }

//            Restaurant biggestMenuRestaurant = biggestMenu(restaurants, 2);
//            cout << biggestMenuRestaurant;

            cout << "TEST PASSED" << endl;

            break;
        }
    }

    return 0;
}