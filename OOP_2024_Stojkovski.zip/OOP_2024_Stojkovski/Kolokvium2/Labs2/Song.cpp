#include <iostream>
#include <string>
using namespace std;

class Song {
private:
    string artist;
    string title;
    string verses[20];
public:
    Song(string artist = " ", string title = " ", string verses = " "){
        this->artist = artist;
        this->title = title;
    }

    Song(const Song & other){
        this->artist = other.artist;
        this->title = other.title;
    }

    ~Song(){}

    int getNumVerses() const{
        int num = 0;
        for (int i = 0; !verses[i].empty(); ++i) {
            num++;
        }
        return num;
    }

    void addVerse(const string &verse){
        verses[getNumVerses()] = verse;
    }

    string completeSong() const{ // od deka gi kopat ovia raboti ??????
        string complete;
        for (int i = 0; i < getNumVerses(); ++i) {
            complete += verses[i] + "\n";
        }
        return complete;
    }

    bool rhymingVerses(const int &verse1Index, const int &verse2Index) const{ // od deka gi kopat ovia raboti ??????
        string verse1 = verses[verse1Index], verse2 = verses[verse2Index];
        unsigned int len1 = verse1.length(), len2 = verse2.length();

        for (int i = 0; i < 3; ++i) {
            if (verse1[len1 - i] != verse2[len2 - i]) return false;
        }
        return true;
    }

    int occurrences(const string &word) const{  // od deka gi kopat ovia raboti ??????
        string song = completeSong();
        int counter = 0, previous = song.find(word);
        if (previous == string::npos) return 0;

        for (int i = 0; previous != -1; ++i) {
            previous = song.find(word, previous + 1);
            counter++;
        }
        return counter;
    }

    friend ostream &operator<<(ostream &os, const Song &song) {
        os<<song.artist << " - " << song.title << ":" << endl << song.completeSong();
        return os;
    }


};

void addVerses(Song &song){
    int n;
    cin >> n;
    cin.ignore();
    for (int i = 0; i < n; ++i) {
        string verse;
        getline(cin, verse);
        song.addVerse(verse);
    }
}

int main(){
    int testCase;
    string artist, title;

    //TODO OD OVAJ RED PA SE DO SLEDNIO TODO TREBASE DA SE DOPISA ..
    cin>>artist>>title;
    Song song1(artist, title);
    addVerses(song1);

    cin>>artist>>title;
    Song song2(artist, title);
    addVerses(song2);
    //TODO DO OVAJ TODO TREBASE OVOA DA SE NAPISA U RAMKITE NA DVATA TODO ..

    cin >> testCase;
    switch (testCase) {
        case 1:{
            cout << "Testing numVerses() and addVerse()" << endl;
            string verse;
            cin >> verse;
            song2.addVerse(verse);
            cout << song1.getNumVerses() << " " << song2.getNumVerses();
            break;
        }
        case 2:
            cout << "Testing completeSong() and << operator" << endl;
            cout << song1.completeSong();
            cout << '\n' << song2;
            break;
        case 3: {
            cout << "Testing rhymingVerses()" << endl;
            int x, first, verse1, verse2;
            cin >> x >> first;
            if(first == 0){
                for (int i = 0; i < x; ++i) {
                    cin >> verse1 >> verse2;
                    cout << (song1.rhymingVerses(verse1, verse2) ? "true" : "false") << endl;
                }
            }
            else{
                for (int i = 0; i < x; ++i) {
                    cin >> verse1 >> verse2;
                    cout << (song2.rhymingVerses(verse1, verse2) ? "true" : "false") << endl;
                }
            }
            break;
        }
        default:
            cout << "Testing occurrences()" << endl;
            int x, first;
            string word;
            cin >> x >> first;
            if(first == 0){
                for (int i = 0; i < x; ++i) {
                    cin >> word;
                    cout << song1.occurrences(word) << endl;
                }
            }
            else{
                for (int i = 0; i < x; ++i) {
                    cin >> word;
                    cout << song2.occurrences(word) << endl;
                }
            }
    }
}

