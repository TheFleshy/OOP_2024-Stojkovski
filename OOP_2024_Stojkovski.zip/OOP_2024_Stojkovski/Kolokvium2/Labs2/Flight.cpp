#include <string>
#include <iostream>
#include <cstring>

using namespace std;

class InvalidSeatNumberException {
private:
    string text;
public:
    InvalidSeatNumberException(string text = "") {
        this->text = text;
    }

    void print() {
        cout << text << endl;
    }
};

class Flight {
protected:
    string code;
    string poaganje;
    string pristignuvanje;
    float price;
    float bagazPrice;
public:
    Flight(string code = " ", string poaganje = "", string pristignuvanje = " ", float price = 0,
           float bagazPrice = 0) {
        this->code = code;
        this->poaganje = poaganje;
        this->pristignuvanje = pristignuvanje;
        this->price = price;
        this->bagazPrice = bagazPrice;
    }

    ~Flight() {}

    Flight(const Flight &other) {
        this->code = other.code;
        this->poaganje = other.poaganje;
        this->pristignuvanje = other.pristignuvanje;
        this->price = other.price;
        this->bagazPrice = other.bagazPrice;
    }

    virtual double calculateTotalPrice() {
        return price + bagazPrice;
    }

    virtual void displayInfo() {
        cout << code << " " << poaganje << "-" << pristignuvanje << " " << price << endl;
    };

};

class EconomyFlight : public Flight {
    char seatNumber[4];
    static double LOYALTY_DISCOUNT;
public:
    EconomyFlight(const char *code, const char *poaganje, const char *pristignuvanje, float price, float bagazPrice,
                  const char *seatNumber)
            : Flight(code, poaganje, pristignuvanje, price, bagazPrice) {
        strncpy(this->seatNumber, seatNumber, 4);
    }

    double calculateTotalPrice() {
        double finalPrice = price + bagazPrice - (price * LOYALTY_DISCOUNT / 100);

        if (seatNumber[0] == 'C' || seatNumber[0] == 'F') {
            finalPrice += price * 0.3; // Add 30% to the price for window seat
        }

        if (!(seatNumber[0] >= 'A' && seatNumber[0] <= 'F')) {
            throw InvalidSeatNumberException("Invalid Seat Number Exception");
        }

        return finalPrice;
    }

    static void setLoyaltyDiscount(double discount) {
        LOYALTY_DISCOUNT = discount;
    }

    void displayInfo() override {
        cout << code << " " << poaganje << "-" << pristignuvanje << " " << seatNumber << endl;
        cout << "Total Price: " << "$"<<calculateTotalPrice() << endl;
    }
};

double EconomyFlight::LOYALTY_DISCOUNT = 20;

int main() {
    int testCase;
    cin >> testCase;
    char code[100];
    char from[100];
    char to[100];
    double price;
    double baggagePrice;
    char seatNumber[4];

    if (testCase == 1) {
        cout << "===== Testiranje na klasite ======" << endl;
        int n;
        cin >> n;
        for (int i = 0; i < n; i++) {
            cin >> code >> from >> to >> price >> baggagePrice >> seatNumber;
            Flight f = Flight(code, from, to, price, baggagePrice);
            EconomyFlight ec(code, from, to, price, baggagePrice, seatNumber);
            ec.displayInfo();
        }
    }
    if (testCase == 2) {
        cout << "===== Testiranje na isklucoci ======" << endl;
        int n;
        cin >> n;
        for (int i = 0; i < n; i++) {
            cin >> code >> from >> to >> price >> baggagePrice >> seatNumber;
            Flight f = Flight(code, from, to, price, baggagePrice);
            try {
                EconomyFlight ec(code, from, to, price, baggagePrice, seatNumber);
                ec.displayInfo();
            }catch (InvalidSeatNumberException & e){
                e.print();
            }
//            ec.displayInfo();
        }
    }
    if (testCase == 3) {
        cout << "===== Testiranje na static clenovi ======" << endl;
        cin >> code >> from >> to >> price >> baggagePrice >> seatNumber;
        Flight f = Flight(code, from, to, price, baggagePrice);
        EconomyFlight ec(code, from, to, price, baggagePrice, seatNumber);
        ec.displayInfo();
        EconomyFlight::setLoyaltyDiscount(50);
        ec.displayInfo();
    }

    return 0;
}
