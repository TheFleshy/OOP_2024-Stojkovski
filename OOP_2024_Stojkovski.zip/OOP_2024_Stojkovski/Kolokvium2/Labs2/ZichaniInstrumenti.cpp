#include <iostream>
#include <string>
using namespace std;

class ZicanInstrument {
protected:
    string name;
    int brZici;
    double price;
public:
    ZicanInstrument(string name = " ", int brZici = 0, double price = 100){
        this->name = name;
        this->brZici =brZici;
        this->price = price;
    }

    ~ZicanInstrument(){}

    ZicanInstrument(const ZicanInstrument & other){
        this->name = other.name;
        this->brZici = other.brZici;
        this->price = other.price;
    }

    friend ostream &operator<<(ostream &os, const ZicanInstrument &instrument) {
        os<<instrument.price<<endl;
        return os;
    }

    bool operator==(const ZicanInstrument &rhs){
        return (this->brZici == rhs.brZici);
    }

};

class Mandolina : public ZicanInstrument {
private:
    string form;
public:
    Mandolina (string name = " ", int brZici = 0, double price = 100, string form = ""): ZicanInstrument(name, brZici, price){
        this->form = form;
        cena();
    }

    ~Mandolina(){}

    Mandolina(const ZicanInstrument & other, string form) : ZicanInstrument(other){
        this->form = form;
    }

    double cena() {
        if (form == "Neapolitan") {
            price *= 1.15;
        }
        return price;
    }
};

class Violina : public ZicanInstrument {
private:
    float golemina;
public:
    Violina(string name = " ", int brZici = 0, double price = 100, float golemina = 0) : ZicanInstrument(name, brZici, price){
        this->golemina = golemina;
        cena();
    }
    ~Violina(){}

    Violina(const ZicanInstrument & o, float golemina = 1000) : ZicanInstrument(o){
        this->golemina = golemina;
    }

    double cena() {
        if (golemina == 0.25) {
            price *= 1.1;
        } else if (golemina == 1) {
            price *= 1.2;
        }
        return price;
    }

};

void pecatiInstrumenti (ZicanInstrument &zi, ZicanInstrument **i, int n){  //TODO CUDNO NAPISANA
    for (int j=0; j<n; j++){
        if (zi == *i[j]){
            cout<<*i[j];
        }
    }
}


int main() {
    char ime[20];
    int brojZici;
    float cena;
    char forma[20];
    cin >> ime >> brojZici >> cena >> forma;
    Mandolina m(ime, brojZici, cena, forma);
    int n;
    cin >> n;
    ZicanInstrument **zi = new ZicanInstrument*[2 * n];
    for(int i = 0; i < n; ++i) {
        cin >> ime >> brojZici >> cena >> forma;
        zi[i] = new Mandolina(ime, brojZici, cena, forma);
    }
    for(int i = 0; i < n; ++i) {
        float golemina;
        cin >> ime >> brojZici >> cena >> golemina;
        zi[n + i] = new Violina(ime, brojZici, cena, golemina);
    }
    pecatiInstrumenti(m, zi, 2 * n);
    for(int i = 0; i < 2 * n; ++i) {
        delete zi[i];
    }
    delete [] zi;
    return 0;
}