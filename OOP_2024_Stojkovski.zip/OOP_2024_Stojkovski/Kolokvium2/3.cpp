////TODO ZABEGANI ZADACI KUGA IMAS VEKE DAENI KLASI PA TREBA DA GLEDAS OD DEKA NA DEKA DA ODES
//// TODO PA DA GLEDAS PO TEKSTO SO TI FALE...
//
//
//#include<iostream>
//#include <string>
//#include <cstring>
//using namespace std;
//
//
//class Kurs{
//private:
//    char ime[20];
//    int krediti;
//public:
//    Kurs (char *ime,int krediti){
//        strcpy(this->ime,ime);
//        this->krediti=krediti;
//    }
//    Kurs (){
//        strcpy(this->ime,"");
//        krediti=0;
//    }
//    bool operator==(const char *ime) const{
//        return strcmp(this->ime,ime)==0;
//    }
//    char const * getIme()const{
//        return ime;
//    }
//    void pecati ()const{
//        cout<<ime<<" "<<krediti<<"ECTS";
//    }
//};
//
//class Student{
//private:
//    int *ocenki;
//    int brojOcenki;
//
//protected:
//    int indeks;
//
//public:
//    Student(int indeks,int *ocenki, int brojOcenki){
//        this->indeks=indeks;
//        this->brojOcenki=brojOcenki;
//        this->ocenki=new int[brojOcenki];
//        for (int i=0;i<brojOcenki;i++) this->ocenki[i]=ocenki[i];
//    }
//    Student(const Student &k){
//        this->indeks=k.indeks;
//        this->brojOcenki=k.brojOcenki;
//        this->ocenki=new int[k.brojOcenki];
//        for (int i=0;i<k.brojOcenki;i++) this->ocenki[i]=k.ocenki[i];
//    }
//    Student operator=(const Student &k){
//        if (&k==this) return *this;
//        this->indeks=k.indeks;
//        this->brojOcenki=k.brojOcenki;
//        delete [] ocenki;
//        this->ocenki=new int[k.brojOcenki];
//        for (int i=0;i<k.brojOcenki;i++) this->ocenki[i]=k.ocenki[i];
//        return *this;
//    }
//
//    ~Student(){delete [] ocenki;}
//
//    //dopolni ja klasata
//
//};
//
//class Predavach{
//private:
//    Kurs kursevi[10];
//    int brojKursevi;
//
//protected:
//    char *imeIPrezime;
//
//public:
//    Predavach(char *imeIPrezime,Kurs *kursevi,int brojKursevi){
//        this->brojKursevi=brojKursevi;
//        for (int i=0;i<brojKursevi;i++) this->kursevi[i]=kursevi[i];
//        this->imeIPrezime=new char[strlen(imeIPrezime)+1];
//        strcpy(this->imeIPrezime,imeIPrezime);
//    }
//    Predavach(const Predavach &p){
//        this->brojKursevi=p.brojKursevi;
//        for (int i=0;i<p.brojKursevi;i++) this->kursevi[i]=p.kursevi[i];
//        this->imeIPrezime=new char[strlen(p.imeIPrezime)+1];
//        strcpy(this->imeIPrezime,p.imeIPrezime);
//    }
//    Predavach operator=(const Predavach &p){
//        if (this==&p) return *this;
//        this->brojKursevi=p.brojKursevi;
//        for (int i=0;i<p.brojKursevi;i++) this->kursevi[i]=p.kursevi[i];
//        this->imeIPrezime=new char[strlen(p.imeIPrezime)+1];
//        delete [] imeIPrezime;
//        strcpy(this->imeIPrezime,p.imeIPrezime);
//        return *this;
//    }
//    ~Predavach(){delete [] imeIPrezime;}
//
//    int getBrojKursevi()const {return brojKursevi;}
//
//    char * const getImeIPrezime()const {return imeIPrezime;}
//
//    Kurs operator[](int i) const {
//        if (i<brojKursevi&&i>=0)
//            return kursevi[i];
//        else return Kurs();
//    }
//
//    void pecati() const  {
//        cout<<imeIPrezime<<" (";
//        for (int i=0;i<brojKursevi;i++){
//            kursevi[i].pecati();
//            if (i<brojKursevi-1) cout<<", ";  else cout<<")";
//        }
//    }
//};
//
//
//class Demonstrator : public Kurs{
//private:
//    int index;
//    int ocenki [21];
//    int brOcenki;
//    string imePrezime;
//    Kurs * kursevi;
//    int brKursevi;
//    int brCasovi;
//public:
//    Demonstrator(int index = 0, int ocenki[0] =0 , int brOcenki = 0, string imePrezime = " ", Kurs * kursevi = 0,int brKursevi = 0, int brCasovi = 0 ){
//        this->index = index;
//        for (int i=0; i<brOcenki; i++){
//            this->ocenki[i] = ocenki[i];
//        }
//        this->brOcenki = brOcenki;
//        this->imePrezime = imePrezime;
//        this->kursevi = new Kurs[0];
//        this->brKursevi = brKursevi;
//        this->brCasovi = brCasovi;
//    }
//
//    Demonstrator(const Demonstrator & other){
//        this->index = other.index;
//        for (int i=0; i<brOcenki; i++){
//            this->ocenki[i] = other.ocenki[i];
//        }
//        this->brOcenki = other.brOcenki;
//        this->imePrezime = other.imePrezime;
//        this->kursevi = new Kurs[other.brKursevi];
//        for (int i=0; i<brKursevi; i++){
//            this->kursevi[i] = other.kursevi[i];
//        }
//        this->brKursevi = other.brKursevi;
//        this->brCasovi = other.brCasovi;
//    }
//
//    Demonstrator &operator = (const Demonstrator & d){
//        if (this!=&d){
//            delete [] kursevi;
//            this->index = d.index;
//            for (int i=0; i<brOcenki; i++){
//                this->ocenki[i] = d.ocenki[i];
//            }
//            this->brOcenki = d.brOcenki;
//            this->imePrezime = d.imePrezime;
//            this->kursevi = new Kurs[d.brKursevi];
//            for (int i=0; i<brKursevi; i++){
//                this->kursevi[i] = d.kursevi[i];
//            }
//            this->brKursevi = d.brKursevi;
//            this->brCasovi = d.brCasovi;
//        }
//        return * this;
//    }
//
//
//};
//
//
//
//
//
//
//
//int main(){
//
//    Kurs kursevi[10];
//    int indeks,brojKursevi, ocenki[20],ocenka,brojOcenki,tip,brojCasovi,krediti;
//    char ime[20],imeIPrezime[50];
//
//    cin>>tip;
//
//    if (tip==1) //test class Demonstrator
//    {
//        cout<<"-----TEST Demonstrator-----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//        cin>>imeIPrezime>>brojKursevi;
//        for (int i=0;i<brojKursevi;i++){
//            cin>>ime>>krediti;
//            kursevi[i]=Kurs(ime,krediti);
//        }
//        cin>>brojCasovi;
//
//        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//        cout<<"Objekt od klasata Demonstrator e kreiran";
//
//    } else if (tip==2) //funkcija pecati vo Student
//    {
//        cout<<"-----TEST pecati-----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//
//        Student s(indeks,ocenki,brojOcenki);
//        s.pecati();
//
//    } else if (tip==3) //funkcija getVkupnaOcenka vo Student
//    {
//        cout<<"-----TEST getVkupnaOcenka-----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//        Student s(indeks,ocenki,brojOcenki);
//        cout<<"Broj na bodovi: "<<s.getBodovi()<<endl;
//
//    } else if (tip==4) //funkcija getVkupnaOcenka vo Demonstrator
//    {
//        cout<<"-----TEST getVkupnaOcenka-----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//        cin>>imeIPrezime>>brojKursevi;
//        for (int i=0;i<brojKursevi;i++){
//            cin>>ime>>krediti;
//            kursevi[i]=Kurs(ime,krediti);
//        }
//        cin>>brojCasovi;
//
//        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//        cout<<"Broj na bodovi: "<<d.getBodovi()<<endl;
//
//    } else if (tip==5) //funkcija pecati vo Demonstrator
//    {
//        cout<<"-----TEST pecati -----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//        cin>>imeIPrezime>>brojKursevi;
//        for (int i=0;i<brojKursevi;i++){
//            cin>>ime>>krediti;
//            kursevi[i]=Kurs(ime,krediti);
//        }
//        cin>>brojCasovi;
//
//        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//        d.pecati();
//
//    } else if (tip==6) //site klasi
//    {
//        cout<<"-----TEST Student i Demonstrator-----"<<endl;
//        cin>>indeks>>brojOcenki;
//        for (int i=0;i<brojOcenki;i++){
//            cin>>ocenka;
//            ocenki[i]=ocenka;
//        }
//        cin>>imeIPrezime>>brojKursevi;
//        for (int i=0;i<brojKursevi;i++){
//            cin>>ime>>krediti;
//            kursevi[i]=Kurs(ime,krediti);
//        }
//        cin>>brojCasovi;
//
//        Student *s=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//        s->pecati();
//        cout<<"\nBroj na bodovi: "<<s->getBodovi()<<endl;
//        delete s;
//
//
//    } else if (tip==7) //funkcija vratiNajdobroRangiran
//    {
//        cout<<"-----TEST vratiNajdobroRangiran-----"<<endl;
//        int k, opt;
//        cin>>k;
//        Student **studenti=new Student*[k];
//        for (int j=0;j<k;j++){
//            cin>>opt; //1 Student 2 Demonstrator
//            cin>>indeks>>brojOcenki;
//            for (int i=0;i<brojOcenki;i++)
//            {
//                cin>>ocenka;
//                ocenki[i]=ocenka;
//            }
//            if (opt==1){
//                studenti[j]=new Student(indeks,ocenki,brojOcenki);
//            }else{
//                cin>>imeIPrezime>>brojKursevi;
//                for (int i=0;i<brojKursevi;i++){
//                    cin>>ime>>krediti;
//                    kursevi[i]=Kurs(ime,krediti);
//                }
//                cin>>brojCasovi;
//                studenti[j]=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//            }
//        }
//        Student& najdobar=vratiNajdobroRangiran(studenti,k);
//        cout<<"Maksimalniot broj na bodovi e:"<<najdobar.getBodovi();
//        cout<<"\nNajdobro rangiran:";
//        najdobar.pecati();
//
//        for (int j=0;j<k;j++) delete studenti[j];
//        delete [] studenti;
//    } else if (tip==8) //funkcija pecatiDemonstratoriKurs
//    {
//        cout<<"-----TEST pecatiDemonstratoriKurs-----"<<endl;
//        int k, opt;
//        cin>>k;
//        Student **studenti=new Student*[k];
//        for (int j=0;j<k;j++){
//            cin>>opt; //1 Student 2 Demonstrator
//            cin>>indeks>>brojOcenki;
//            for (int i=0;i<brojOcenki;i++)
//            {
//                cin>>ocenka;
//                ocenki[i]=ocenka;
//            }
//            if (opt==1){
//                studenti[j]=new Student(indeks,ocenki,brojOcenki);
//            }else{
//                cin>>imeIPrezime>>brojKursevi;
//                for (int i=0;i<brojKursevi;i++)
//                {
//                    cin>>ime>>krediti;
//                    kursevi[i]=Kurs(ime,krediti);
//                }
//                cin>>brojCasovi;
//                studenti[j]=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
//            }
//        }
//        char kurs[20];
//        cin>>kurs;
//        cout<<"Demonstratori na "<<kurs<<" se:"<<endl;
//        pecatiDemonstratoriKurs (kurs,studenti,k);
//        for (int j=0;j<k;j++) delete studenti[j];
//        delete [] studenti;
//
//    }
//
//
//    return 0;
//}
//

#include<iostream>
#include<string.h>
using namespace std;

class NoCourseException{
    int index;
public:
    NoCourseException(int idx){
        this->index=idx;
    }
    void pecatiPoraka(){
        cout<<"Demonstratorot so indeks "<<index<<" ne drzi laboratoriski vezbi"<<endl;
    }
//    Demonstratorot so indeks XXXX ne drzi laboratoriski vezbi
};

class Kurs{
private:
    char ime[20];
    int krediti;
public:
    Kurs (char *ime,int krediti){
        strcpy(this->ime,ime);
        this->krediti=krediti;
    }
    Kurs (){
        strcpy(this->ime,"");
        krediti=0;
    }
    bool operator==(const char *ime) const{ // ova se koristi vo pecatiDemonstratoriKurs()
        return strcmp(this->ime,ime)==0;
    }
    char const * getIme()const{
        return ime;
    }
    void pecati ()const{cout<<ime<<" "<<krediti<<"ECTS";}
};

class Student{
private:
    int *ocenki;
    int brojOcenki;

protected:
    int indeks;

public:
    Student(int indeks,int *ocenki, int brojOcenki){
        this->indeks=indeks;
        this->brojOcenki=brojOcenki;
        this->ocenki=new int[brojOcenki];
        for (int i=0;i<brojOcenki;i++) this->ocenki[i]=ocenki[i];
    }
    Student(const Student &k){
        this->indeks=k.indeks;
        this->brojOcenki=k.brojOcenki;
        this->ocenki=new int[k.brojOcenki];
        for (int i=0;i<k.brojOcenki;i++) this->ocenki[i]=k.ocenki[i];
    }
    Student operator=(const Student &k){
        if (&k==this) return *this;
        this->indeks=k.indeks;
        this->brojOcenki=k.brojOcenki;
        delete [] ocenki;
        this->ocenki=new int[k.brojOcenki];
        for (int i=0;i<k.brojOcenki;i++) this->ocenki[i]=k.ocenki[i];
        return *this;
    }

    ~Student(){delete [] ocenki;}

    virtual int getBodovi(){
        int counter=0;
        for(int i=0; i<brojOcenki; i++){
            if(ocenki[i]>5) counter++;
        }
        return int((double)counter/brojOcenki * 100);
    }
    virtual void pecati(){
        cout<<indeks<<endl;
    }

    int getIndeks() const {
        return indeks;
    }
    //dopolni ja klasata


};

class Predavach{
private:
    Kurs kursevi[10];
    int brojKursevi;

protected:
    char *imeIPrezime;

public:
    Predavach(char *imeIPrezime,Kurs *kursevi,int brojKursevi){
        this->brojKursevi=brojKursevi;
        for (int i=0;i<brojKursevi;i++) this->kursevi[i]=kursevi[i];
        this->imeIPrezime=new char[strlen(imeIPrezime)+1];
        strcpy(this->imeIPrezime,imeIPrezime);
    }
    Predavach(const Predavach &p){
        this->brojKursevi=p.brojKursevi;
        for (int i=0;i<p.brojKursevi;i++) this->kursevi[i]=p.kursevi[i];
        this->imeIPrezime=new char[strlen(p.imeIPrezime)+1];
        strcpy(this->imeIPrezime,p.imeIPrezime);
    }
    Predavach operator=(const Predavach &p){
        if (this==&p) return *this;
        this->brojKursevi=p.brojKursevi;
        for (int i=0;i<p.brojKursevi;i++) this->kursevi[i]=p.kursevi[i];
        this->imeIPrezime=new char[strlen(p.imeIPrezime)+1];
        delete [] imeIPrezime;
        strcpy(this->imeIPrezime,p.imeIPrezime);
        return *this;
    }
    ~Predavach(){delete [] imeIPrezime;}

    int getBrojKursevi()const {return brojKursevi;}

    char * const getImeIPrezime()const {return imeIPrezime;}

    Kurs operator[](int i) const {
        if (i<brojKursevi&&i>=0)
            return kursevi[i];
        else return Kurs();
    }

    const Kurs *getKursevi() const {
        return kursevi;
    }

    void pecati() const  {
        cout<<imeIPrezime<<" (";
        for (int i=0;i<brojKursevi;i++){
            kursevi[i].pecati();
            if (i<brojKursevi-1) cout<<", ";  else cout<<")";
        }
    }
};

class Demonstrator : public Student, public Predavach{
    int brojCasovi;
public:
    Demonstrator(int indeks, int *ocenki, int brojOcenki, char *imeIPrezime, Kurs *kursevi, int brojKursevi,int brojCasovi)
            : Student(indeks, ocenki, brojOcenki), Predavach(imeIPrezime, kursevi, brojKursevi){
        this->brojCasovi=brojCasovi;
    }
    int getBodovi(){
        // so try{} treba za exception tuka ili vo mainot
        if(this->getBrojKursevi()==0){
            throw NoCourseException(indeks);   // dali e vo red?
        }
        int bodovi = Student::getBodovi();
        bodovi += (20*brojCasovi)/getBrojKursevi();
        return bodovi;
    }
    void pecati(){
        cout<<indeks<<": "<<imeIPrezime<< " (";
        getKursevi()[0].pecati();
        cout<<", ";
        for(int i=1; i<getBrojKursevi()-1; i++){
            getKursevi()[i].pecati();
            cout<<", ";
        }
        getKursevi()[getBrojKursevi()-1].pecati();
        cout<<")";
    }
    ~Demonstrator(){}
};

Student& vratiNajdobroRangiran(Student ** studenti, int n ){
    Student *najdobar = studenti[0];
    for(int i=0; i<n; i++){
        // TUKA PROBAJ TRY{} : ako studenti[i]->getBodovi() == 0, throw error, endl, catch(err) err.pecati()
        try{
            if(studenti[i]->getBodovi()==0){
                throw NoCourseException(studenti[i]->getIndeks());
            }
            if(najdobar->getBodovi() < studenti[i]->getBodovi()){
                najdobar=studenti[i];
            }
        }
        catch(NoCourseException n){
            n.pecatiPoraka();
        }
    }
    return *najdobar;
    // DALI E DOVOLNO?
}

void pecatiDemonstratoriKurs (char* kurs, Student** studenti, int n){
    for(int i=0; i<n; i++){
        Demonstrator * d = dynamic_cast<Demonstrator*>(studenti[i]);
        if(d){
            for(int j=0; j<d->getBrojKursevi(); j++){
                if(d->getKursevi()[i]==kurs){
                    d->pecati();
                    cout<<endl;
                    break;
                }
            }
        }
    }
}

int main(){

    Kurs kursevi[10];
    int indeks,brojKursevi, ocenki[20],ocenka,brojOcenki,tip,brojCasovi,krediti;
    char ime[20],imeIPrezime[50];

    cin>>tip;

    if (tip==1) //test class Demonstrator
    {
        cout<<"-----TEST Demonstrator-----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }
        cin>>imeIPrezime>>brojKursevi;
        for (int i=0;i<brojKursevi;i++){
            cin>>ime>>krediti;
            kursevi[i]=Kurs(ime,krediti);
        }
        cin>>brojCasovi;

        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
        cout<<"Objekt od klasata Demonstrator e kreiran";

    } else if (tip==2) //funkcija pecati vo Student
    {
        cout<<"-----TEST pecati-----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }

        Student s(indeks,ocenki,brojOcenki);
        s.pecati();

    } else if (tip==3) //funkcija getVkupnaOcenka vo Student
    {
        cout<<"-----TEST getVkupnaOcenka-----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }
        Student s(indeks,ocenki,brojOcenki);
        cout<<"Broj na bodovi: "<<s.getBodovi()<<endl;

    } else if (tip==4) //funkcija getVkupnaOcenka vo Demonstrator
    {
        cout<<"-----TEST getVkupnaOcenka-----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }
        cin>>imeIPrezime>>brojKursevi;
        for (int i=0;i<brojKursevi;i++){
            cin>>ime>>krediti;
            kursevi[i]=Kurs(ime,krediti);
        }
        cin>>brojCasovi;
        // mozda try?
        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
        cout<<"Broj na bodovi: "<<d.getBodovi()<<endl;

    } else if (tip==5) //funkcija pecati vo Demonstrator
    {
        cout<<"-----TEST pecati -----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }
        cin>>imeIPrezime>>brojKursevi;
        for (int i=0;i<brojKursevi;i++){
            cin>>ime>>krediti;
            kursevi[i]=Kurs(ime,krediti);
        }
        cin>>brojCasovi;

        Demonstrator d(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
        d.pecati();

    } else if (tip==6) //site klasi
    {
        cout<<"-----TEST Student i Demonstrator-----"<<endl;
        cin>>indeks>>brojOcenki;
        for (int i=0;i<brojOcenki;i++){
            cin>>ocenka;
            ocenki[i]=ocenka;
        }
        cin>>imeIPrezime>>brojKursevi;
        for (int i=0;i<brojKursevi;i++){
            cin>>ime>>krediti;
            kursevi[i]=Kurs(ime,krediti);
        }
        cin>>brojCasovi;

        Student *s=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
        s->pecati();
        cout<<"\nBroj na bodovi: "<<s->getBodovi()<<endl;
        delete s;


    } else if (tip==7) //funkcija vratiNajdobroRangiran
    {
        cout<<"-----TEST vratiNajdobroRangiran-----"<<endl;
        int k, opt;
        cin>>k;
        Student **studenti=new Student*[k];
        for (int j=0;j<k;j++){
            cin>>opt; //1 Student 2 Demonstrator
            cin>>indeks>>brojOcenki;
            for (int i=0;i<brojOcenki;i++)
            {
                cin>>ocenka;
                ocenki[i]=ocenka;
            }
            if (opt==1){
                studenti[j]=new Student(indeks,ocenki,brojOcenki);
            }else{
                cin>>imeIPrezime>>brojKursevi;
                for (int i=0;i<brojKursevi;i++){
                    cin>>ime>>krediti;
                    kursevi[i]=Kurs(ime,krediti);
                }
                cin>>brojCasovi;
                studenti[j]=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
            }
        }
        Student& najdobar=vratiNajdobroRangiran(studenti,k);
        cout<<"Maksimalniot broj na bodovi e:"<<najdobar.getBodovi();
        cout<<"\nNajdobro rangiran:";
        najdobar.pecati();

        for (int j=0;j<k;j++) delete studenti[j];
        delete [] studenti;
    } else if (tip==8) //funkcija pecatiDemonstratoriKurs
    {
        cout<<"-----TEST pecatiDemonstratoriKurs-----"<<endl;
        int k, opt;
        cin>>k;
        Student **studenti=new Student*[k];
        for (int j=0;j<k;j++){
            cin>>opt; //1 Student 2 Demonstrator
            cin>>indeks>>brojOcenki;
            for (int i=0;i<brojOcenki;i++)
            {
                cin>>ocenka;
                ocenki[i]=ocenka;
            }
            if (opt==1){
                studenti[j]=new Student(indeks,ocenki,brojOcenki);
            }else{
                cin>>imeIPrezime>>brojKursevi;
                for (int i=0;i<brojKursevi;i++)
                {
                    cin>>ime>>krediti;
                    kursevi[i]=Kurs(ime,krediti);
                }
                cin>>brojCasovi;
                studenti[j]=new Demonstrator(indeks,ocenki,brojOcenki,imeIPrezime,kursevi,brojKursevi,brojCasovi);
            }
        }
        char kurs[20];
        cin>>kurs;
        cout<<"Demonstratori na "<<kurs<<" se:"<<endl;
        pecatiDemonstratoriKurs (kurs,studenti,k);
        for (int j=0;j<k;j++) delete studenti[j];
        delete [] studenti;

    }


    return 0;
}