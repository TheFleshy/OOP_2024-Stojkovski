#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void wtd() {
    ofstream fout("input.txt");

    string fname, lname;
    int points;
    string line;

    while (getline(std::cin, line)) {
        if (line == "----") {
            break;
        }
        fout << line << endl;
    }
}

void rff1() {
    ifstream fin("output1.txt");
    string line;
    while (getline(fin, line)) {
        cout << line << endl;
    }
}

void rff2() {
    ifstream fin("output2.txt");
    string line;
    while (getline(fin, line)) {
        cout << line << endl;
    }
}

class Book {
private:
    string title;
    string author;
    int year;
public:
    Book(const string &title = "", const string &author = "", int year = 0) : title(title), author(author), year(year) {
    }

    friend ostream &operator<<(ostream &os, const Book &book) {
        os << book.title << " " << book.author << " " << book.year << endl;
        return os;
    }

    bool operator==(const Book &rhs) const {
        return title == rhs.title &&
               author == rhs.author &&
               year == rhs.year;
    }

    const string &getTitle() const {
        return title;
    }

    const string &getAuthor() const {
        return author;
    }

    int getYear() const {
        return year;
    }


};

class BookAlreadyExistsException {
private:
    Book b;
public:
    BookAlreadyExistsException(const Book &b) {
        this->b = b;
    }

    void print() {
        cout << "Book \"" << b << "\" already exists in the library" << endl;
    }
};

class Library {
private:
    string name;
    Book *books;
    int n;
public:
    Library(string name = "") {
        this->name = name;
        books = new Book[n];
        this->n = 0;
    }

    Library &operator+=(const Book &o) {
        for (int i = 0; i < n; i++) {
            if (books[i] == o) {
                throw BookAlreadyExistsException(o);
            }
        }


        Book *tmp = new Book[n + 1];
        for (int i = 0; i < n; i++) {
            tmp[i] = books[i];
        }
        tmp[n] = o;
        n++;
        delete[] books;
        books = tmp;

        return *this;
    }

    friend ostream &operator<<(ostream &out, const Library &l) {
        out << l.name << endl;
        for (int i = 0; i < l.n; i++) {
            out << l.books[i];
        }
        return out;
    }

    Book *getBooksByAuthor(string &author, int &numberFound) {
        numberFound = 0;
        for (int i = 0; i < n; i++) {
            if (books[i].getAuthor() == author) {
                ++numberFound;
            }
        }

        Book *result = new Book[numberFound];
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (books[i].getAuthor() == author) {
                result[j++] = books[i];
            }
        }
        if (numberFound == 0) {
            return nullptr;
        } else {
            return result;
        }
    }
};

int main() {

    //TODO POSLE SEKOJ IFS>>INTEGER(PRIMER), MORA DA STAEME CIN.IGNORE() , ZATOA SO KE GO PRERIPA ENTERO I KE GO RACUNA KAKO TOA POSLE NEGO I TAKA POSLE KE PADNE ZADACATA

    wtd();

    //code
    ifstream ifs("input.txt");

    string LibraryName;
    getline(ifs, LibraryName);

    Library library(LibraryName);

    int n;
    ifs >> n;
    ifs.ignore();

    string title;
    string a;
    int year;
    for (int i = 0; i < n; i++) {
        getline(ifs, title);
        getline(ifs, a);
        ifs >> year;
        ifs.ignore();

//        cout<< title<<" "<<a<<" "<<year<<endl; // TODO TUKA ODMA DA SI NAPRAEME PROVERKA DALI DOBRO CITAME OD DATOTEKATA

        Book b(title, a, year);
        try {
            library += b;
        }
        catch (BookAlreadyExistsException &e) {
            e.print();
        }

    }

    ifs.close();

    ofstream ofs1("output1.txt");
    ofs1 << library;
    ofs1.close();


    // not modify next part

    string author;
    getline(std::cin, author);

    // do not modify the part above, continue after this comment

    //TODO print books written by author in file output2.txt

    ofstream ofs2("output2.txt");

    Book *result = library.getBooksByAuthor(author, n);
    if (result == nullptr) {
        ofs2 << "None";
    } else {
        for (int i = 0; i < n; i++) {
            ofs2 << result[i] << endl;
        }
    }

    ofs2.close();

    rff1();
    cout << "Books written by " << author << " are: " << endl;


    return 0;
}

#include <iostream>
#include <cstring>
#include <fstream>


using namespace std;

void wtf() {
    ofstream fout("input.txt");

    string fname, lname;
    int points;
    string line;

    while (getline(std::cin, line)) {
        if (line == "----") {
            break;
        }
        fout << line << endl;
    }
}

void rff1() {
    ifstream fin("output1.txt");
    string line;
    while (getline(fin, line)) {
        cout << line << endl;
    }
}

void rff2() {
    ifstream fin("output2.txt");
    string line;
    while (getline(fin, line)) {
        cout << line << endl;
    }
}

class Book {
private:
    string title;
    string author;
    int year;

public:
    Book(const string &title = "", const string &author = "", int year = 1900) : title(title), author(author),
                                                                                 year(year) {}

    bool operator==(const Book &rhs) const {
        return title == rhs.title &&
               author == rhs.author &&
               year == rhs.year;
    }

    bool operator!=(const Book &rhs) const {
        return !(rhs == *this);
    }

    string &getAuthor() {
        return author;
    }
};

class BookAlreadyExistsException {
private:
    Book b;
public:
    BookAlreadyExistsException(const Book &b) {
        this->b = b;
    }

public:
    void message() {
        //Book "[BOOK INFO]" already exists in the library

        cout << "Book \"" << b << "\" already exists in the library" << endl;
    }
};

class Library {
private:
    string name;
    Book *books;
    int n;
public:
    Library(const string &name = "") {
        this->name = name;
        n = 0;
        books = new Book[n];
    }

    Library &operator+=(const Book &b) {
        for (int i = 0; i < n; i++) {
            if (books[i] == b) {
                throw BookAlreadyExistsException(b);
            }
        }


        Book *tmp = new Book[n + 1];
        for (int i = 0; i < n; i++) {
            tmp[i] = books[i];
        }
        tmp[n] = b;
        n++;
        delete[] books;
        books = tmp;

        return *this;
    }

    friend ostream &operator<<(ostream &out, const Library &l) {
        out << l.name << endl;
        for (int i = 0; i < l.n; i++) {
            out << l.books[i] << endl;
        }
        return out;
    }

    Book *getBooksByAuthor(string &author, int &numberFound) {

        numberFound = 0;
        for (int i = 0; i < n; i++) {
            if (books[i].getAuthor() == author) {
                ++numberFound;
            }
        }

        Book *result = new Book[numberFound];
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (books[i].getAuthor() == author) {
                result[j++] = books[i];
            }
        }

        if (numberFound == 0) {
            return nullptr;
        } else {
            return result;
        }
    }
};


int main() {


    wtf(); //ja kreira datotekata input.txt


    //YOUR CODE STARTS HERE

    /*      Bojan : Daden ti e test case i od nego gledas sho treba da uneses i kakvi objekti da kreiras
     *  FINKI Library               Ovoa e ime na library kreiras  i go unasas na linija 177 (treba da kreiras objekt od klasa Library (linija 179))
        5                              Ovoa e n (broj na knigi so ke gi uneses u library) zacuvuvas gi u promenlivata n u 182 linija
        To Kill a Mockingbird       Te tuka gledas deka pocnuvat da se citat podatoci za knigite ovoa e imeto na knigata
        Harper Lee                  ovoa e avtoro
        1960                        ovoa e godinata
        1984                        Tuka veke gleas deka ima ciklus odnosno ke se vrtat istite raboti i taka odes za 5 knigi
        George Orwell
        1949
        The Great Gatsby
        F. Scott Fitzgerald
        1925
        Pride and Prejudice
        Jane Austen
        1813
        Moby Dick
        Herman Melville
        1851
     * */

    ifstream ifs("input.txt");  // kreiras go fajlo od koj so citas - vika se ifs

    string libraryName;             // kreiras promenliva string libraryName za u nea da go zacuvas imeto procitano od input.txt
    getline(ifs, libraryName);  // citas so getline oti sakas cela linija da zemes i ovoa e sintaksata

    Library library(libraryName);   // kreiras objekt so ime library od klasa Library i preku konstruktoro mu go stavas imeto libraryName na objekto library

    int n;          // broj na knigi sho ke probas da gi uneses u library
    ifs >> n;

    ifs.ignore();   // ovoa znaes posle int ko unasas string mora .ignore()

    for (int i = 0; i < n; i++) {   // ovaj ciklus ni sluzhe za od input.txt da gi procitas site podatoci, da kreiras objekti od klasa Book i da gi dodaes u library
        string t, a;    // sega gledas od test case deka treba da uneses ime na avtor, naslov i godina pa tia mora da gi zacuvas nekade i zatoa 187 i 188 linija ti sluzat
        int year;
        getline(ifs, t);    // citas imeto na naslovo od input.txt
        getline(ifs, a);    // citas avtoro
        ifs >> year;    // citas godinata
        ifs.ignore();

//        cout << t << " " << a << " " << year << endl;

        Book b(t, a, year); // e sega tuka kreiras objekt b od klasata Book i mu gi davas t,a,year kako argumenti on so konstruktoro ke kreira objekt so tia atributi
        try {
            library += b;   // tuka probavas da dodaes knigata u library i ako ima error so catcho sfana go toa
        }
        catch (BookAlreadyExistsException &e) {
            e.message();
        }
    }

    ifs.close();

//    ofstream ofs1("output1.txt"); // ovoa vaka ne go uceme tuku pravo gledaj na linija 211
//    ofs1 << library;
//    ofs1.close();

    cout<<library;  // ispecates ja bibliotekata library i toa go praes tuka vaka oti imas operator za << u Library klasa ako nemas << u Library ke padne zadacata
    //DO NOT MODIFY THE NEXT PART

    string author;      // ovoa e ime na avtor i go unasas za u linija 221 da go praes kako argument avtoro
    getline(std::cin, author);

    //DO NOT MODIFY THE PART ABOVE, CONTINUE AFTER THIS COMMENT

//    ofstream ofs2("output2.txt"); // ovoa isto ne ti treba

    Book *result = library.getBooksByAuthor(author, n); // sea ovoa se traze u ovaa zadaca znaci da se najdat site knigi na nekoj avtor i da se ispecatat mos u druga zadaca drugo da se traze

    if (result == nullptr) {
        cout << "None";
    } else {
        for (int i = 0; i < n; i++) {
            cout << result[i] << endl;
        }
    }
    // do tuka gledaj


//    ofs2.close();

    //YOUR CODE ENDS HERE
    rff1();
    cout << "Books written by " << author << " are: " << endl;
    rff2();

    return 0;
}