#include <iostream>
#include <string>

using namespace std;

class Post {
protected:
    string username;
    string content;
    bool hasPhoto;
    int likes;
public:
    virtual double popularity() const = 0;

    virtual void print() = 0;

    Post(const string &username = "", const string &content = "", bool hasPhoto = false, int likes = 0) {
        this->username = username;
        this->content = content;
        this->hasPhoto = hasPhoto;
        this->likes = likes;
    }

    bool operator<(const Post &rhs) const {
        return popularity() < rhs.popularity();
    }

    bool operator>(const Post &rhs) const {
        return rhs < *this;
    }

    bool operator<=(const Post &rhs) const {
        return !(rhs < *this);
    }

    bool operator>=(const Post &rhs) const {
        return !(*this < rhs);
    }

    bool isHasPhoto() const {
        return hasPhoto;
    }

};

class FacebookPost : public Post {
private:
    int shares;
public:
    FacebookPost(const string &username = "", const string &content = "", bool hasPhoto = false, int likes = 0,
                 int shares = 0) : Post(username, content, hasPhoto, likes) {
        this->shares = shares;
    }

    double popularity() const override {
        double result = likes * shares;
        if (hasPhoto) {
            return result * 1.20;
        }
        return result;
    }

    void print() const {
        /* Facebook post
         * Username: JohnDoe
         * Content: This is a Facebook post.
         *          Whit photo
         * Likes: 100 Shares: 50
         * Popularity: 6000*/
        cout << "Facebook post" << endl;
        cout << "Username: " << username << endl;
        cout << "Content: " << content << endl;
        if (hasPhoto) {
            cout << "Whit photo" << endl;
        } else {
            cout << "Whitout photo" << endl;
        }
        cout << "Likes: " << likes << " " << "Shares: " << shares << endl;
        cout << "Popularity: " << popularity() << endl;
    }
};

class TwitterPost : public Post {
private:
    int retweets;
    int replies;
public:
    TwitterPost(const string &username = "", const string &content = "", bool hasPhoto = false, int likes = 0,
                int retweets = 0, int replies = 0) : Post(username, content, hasPhoto, likes) {
        this->retweets = retweets;
        this->replies = replies;
    }

    double popularity() const override {
        double result = likes * retweets * replies;
        if (hasPhoto) {
            return result * 1.10;
        }
        if (content ==
            "#crypto") {  // TODO (content.find("crypto")!=-1 {return result * 1.20;} // andonov vaka ja napravi a dali e tocna kaj men
            return result * 1.20;
        }
        return result;
    }

    void print() override {
        cout << "Twitter post" << endl;
        cout << "Username: " << username << endl;
        cout << "Content: " << content << endl;
        if (hasPhoto) {
            cout << "Whit photo" << endl;
        } else {
            cout << "Whitout photo" << endl;
        }
        cout << "Likes: " << likes << " " << "Retweets: " << retweets << " Replies: " << replies << endl;
        cout << "Popularity: " << popularity() << endl;
    }
};

double mostPopularPostWithPhoto(Post **posts, int n) {
    double max = -1;
    for (int i = 0; i < n; i++) {
        if (posts[i]->isHasPhoto() && posts[i]->popularity() > max) {
            max = posts[i]->popularity();
        }
    }
    return max;
}

Post * leastPopularTwitterPost(Post **posts, int n) {
    Post *leastPopular = nullptr;
    for (int i = 0; i < n; i++) {
        if (dynamic_cast <TwitterPost *> (posts[i])) {
            if (leastPopular == nullptr) {
                leastPopular = posts[i];
            } else if (posts[i]->popularity() < leastPopular->popularity()) {
                leastPopular = posts[i];
            }
        }
    }
    return leastPopular;
}

int main() {


    //TODO neam go maino, ne e praten a da go pisam jok

    return 0;
}