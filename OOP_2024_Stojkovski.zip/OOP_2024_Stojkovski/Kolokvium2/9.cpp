#include <iostream>
#include <string>
#include <cstring>
using namespace std;

class Exception{
private:
    string text;
public:
    Exception(string text = ""){
        this->text = text;
    }

    void print (){
        cout<<text<<endl;
    }
};

class Trud{
    char vid ;
    int godinaIzdavanje;
public:
    Trud(char vid = 'C', int godinaIzdavanje = 0){
        this->vid = vid;
        this->godinaIzdavanje = godinaIzdavanje;
    }

    ~Trud(){}

    Trud(const Trud & other){
        this->vid=other.vid;
        this->godinaIzdavanje = other.godinaIzdavanje;
    }

    char getVid() const {
        return vid;
    }

    int getGodinaIzdavanje() const {
        return godinaIzdavanje;
    }


};

class Student {
protected:
    string name;
    int index;
    int godinaUpis;
    int oceni [50];
    int n;
public:
    Student(string name = "", int index = 0, int godinaUpis = 0, int niza [] = nullptr, int n = 0){
        this->name = name;
        this->index = index;
        this->godinaUpis = godinaUpis;
        this->n = n;
        for (int i=0; i<n ;i++){
            this->oceni[i] = oceni[i];
        }
    }

    Student(const Student & o){
        this->name = o.name;
        this->index = o.index;
        this->godinaUpis = o.godinaUpis;
        this->n = o.n;
//        this->oceni = new int[o.n]; // Алоцирајте меморија за оцените
        for (int i = 0; i < n; i++){
            this->oceni[i] = o.oceni[i]; // Копирајте ги оцените
        }
    }

    ~Student(){}

    virtual double rang(){
        double vkupno = 0;
        for (int i=0; i<n; i++){
            vkupno+=oceni[i];
        }
        return vkupno/n;
    }

    friend ostream& operator<<(ostream& out, Student p) {
        p.print(out);
        return out;
    }
    virtual void print(ostream& out) {
      cout<<index<<" "<<name<<" "<<godinaUpis<<" "<<rang()<<endl;
    }

    int getIndex() {
        return 0;
    }
};

class PhDStudent : public Student{
private:
    Trud * trudovi;
    int nTrudovi;
public:
    PhDStudent(string name = "", int index = 0, int godinaUpis = 0, int niza [] = nullptr, int n = 0, Trud * trudovi = nullptr, int nTrudovi =0) : Student(name, index, godinaUpis, niza, n){
        this->trudovi = new Trud[nTrudovi];
        this->nTrudovi = nTrudovi;
        for (int i=0; i<n; i++){
            this->trudovi[i] = trudovi[i];
        }
    }

    PhDStudent(const PhDStudent & other){
        this->trudovi = new Trud[other.nTrudovi]; // Алоцирајте меморија за trudovi
        this->nTrudovi = other.nTrudovi;
        for (int i = 0; i < nTrudovi; i++){
            this->trudovi[i] = other.trudovi[i]; // Копирајте ги trudovite
        }
    }

    ~PhDStudent(){
        delete [] trudovi;
    }

//    double rang() override{
//        double vkupno =0;
//        for(int i=0; i<n; i++){
//            vkupno+=oceni[i];
//        }
//        for (int i = 0; i < nTrudovi; i++) {
//            if (trudovi[i].getVid() == 'C') {
//                vkupno += 1;
//            } else if (trudovi[i].getVid() == 'J') {
//                vkupno += 3;
//            }
//        }
//        return vkupno / (n + nTrudovi);
//    }

    double rang() override{
        double vkupno = Student::rang(); // Пресметајте го просекот на предметите
        for (int i = 0; i < nTrudovi; i++) {
            if (trudovi[i].getVid() == 'C') {
                vkupno += 1;
            } else if (trudovi[i].getVid() == 'J') {
                vkupno += 3;
            }
        }
        return vkupno / (n + nTrudovi); // Вратете просекот
    }

    PhDStudent &operator += (const Trud & other){

        if (other.getGodinaIzdavanje() < godinaUpis){
            throw Exception("Ne moze da se vnese dadeniot trud");
        }

        Trud * tmp = new Trud[nTrudovi+1];
        for (int i = 0; i < nTrudovi; i++){
            tmp[i] = trudovi[i];
        }
        tmp[nTrudovi++] = other;
        delete [] trudovi; // Ослободете ја старата низа
        trudovi = tmp;
        return * this;
    }

    friend istream& operator>>(istream& in, Trud& t) {
        char vid;
        int godinaIzdavanje;
        in >> vid >> godinaIzdavanje;
        t = Trud(vid, godinaIzdavanje);
        return in;
    }

};

int main(){
    int testCase;
    cin >> testCase;

    int god, indeks, n, god_tr, m, n_tr;
    int izbor; //0 za Student, 1 za PhDStudent
    char ime[30];
    int oceni[50];
    char tip;
    Trud trud[50];

    if (testCase == 1){
        cout << "===== Testiranje na klasite ======" << endl;
        cin >> ime;
        cin >> indeks;
        cin >> god;
        cin >> n;
        for (int j = 0; j < n; j++)
            cin >> oceni[j];
        Student s(ime, indeks, god, oceni, n);
        cout << s;

        cin >> ime;
        cin >> indeks;
        cin >> god;
        cin >> n;
        for (int j = 0; j < n; j++)
            cin >> oceni[j];
        cin >> n_tr;
        for (int j = 0; j < n_tr; j++){
            cin >> tip;
            cin >> god_tr;
            Trud t(tip, god_tr);
            trud[j] = t;
        }
        PhDStudent phd(ime, indeks, god, oceni, n, trud, n_tr);
        cout << phd;
    }
    if (testCase == 2){
        cout << "===== Testiranje na operatorot += ======" << endl;
        Student **niza;
        cin >> m;
        niza = new Student *[m];
        for (int i = 0; i<m; i++){
            cin >> izbor;
            cin >> ime;
            cin >> indeks;
            cin >> god;
            cin >> n;
            for (int j = 0; j < n; j++)
                cin >> oceni[j];

            if (izbor == 0){
                niza[i] = new Student(ime, indeks, god, oceni, n);
            }
            else{
                cin >> n_tr;
                for (int j = 0; j < n_tr; j++){
                    cin >> tip;
                    cin >> god_tr;
                    Trud t(tip, god_tr);
                    trud[j] = t;
                }
                niza[i] = new PhDStudent(ime, indeks, god, oceni, n, trud, n_tr);
            }
        }
        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];

        // dodavanje nov trud za PhD student spored indeks
        Trud t;
        cin >> indeks ;
//        cin >> t;

        for (int i = 0; i < m; i++) {
            if (niza[i]->getIndex() == indeks && dynamic_cast<PhDStudent*>(niza[i]) != nullptr) {
                try {
                    *dynamic_cast<PhDStudent*>(niza[i]) += t;
                } catch (Exception& e) {
                    e.print();
                }
            }
        }

        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];
    }
    if (testCase == 3){
        cout << "===== Testiranje na operatorot += ======" << endl;
        Student **niza;
        cin >> m;
        niza = new Student *[m];
        for (int i = 0; i<m; i++){
            cin >> izbor;
            cin >> ime;
            cin >> indeks;
            cin >> god;
            cin >> n;
            for (int j = 0; j < n; j++)
                cin >> oceni[j];

            if (izbor == 0){
                niza[i] = new Student(ime, indeks, god, oceni, n);
            }
            else{
                cin >> n_tr;
                for (int j = 0; j < n_tr; j++){
                    cin >> tip;
                    cin >> god_tr;
                    Trud t(tip, god_tr);
                    trud[j] = t;
                }
                niza[i] = new PhDStudent(ime, indeks, god, oceni, n, trud, n_tr);
            }
        }
        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];

        // dodavanje nov trud za PhD student spored indeks
        Trud t;
        cin >> indeks;
//        cin >> t;

        // vmetnete go kodot za dodavanje nov trud so pomos na operatorot += od Testcase 2
        for (int i = 0; i < m; i++) {
            if (niza[i]->getIndex() == indeks && dynamic_cast<PhDStudent*>(niza[i]) != nullptr) {
                try {
                    *dynamic_cast<PhDStudent*>(niza[i]) += t;
                } catch (Exception& e) {
                    e.print();
                }
            }
        }


        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];
    }
    if (testCase == 4){
        cout << "===== Testiranje na isklucoci ======" << endl;
        cin >> ime;
        cin >> indeks;
        cin >> god;
        cin >> n;
        for (int j = 0; j < n; j++)
            cin >> oceni[j];
        cin >> n_tr;
        for (int j = 0; j < n_tr; j++){
            cin >> tip;
            cin >> god_tr;
            Trud t(tip, god_tr);
            trud[j] = t;
        }
        PhDStudent phd(ime, indeks, god, oceni, n, trud, n_tr);
        cout << phd;
    }
    if (testCase == 5){
        cout << "===== Testiranje na isklucoci ======" << endl;
        Student **niza;
        cin >> m;
        niza = new Student *[m];
        for (int i = 0; i<m; i++){
            cin >> izbor;
            cin >> ime;
            cin >> indeks;
            cin >> god;
            cin >> n;
            for (int j = 0; j < n; j++)
                cin >> oceni[j];

            if (izbor == 0){
                niza[i] = new Student(ime, indeks, god, oceni, n);
            }
            else{
                cin >> n_tr;
                for (int j = 0; j < n_tr; j++){
                    cin >> tip;
                    cin >> god_tr;
                    Trud t(tip, god_tr);
                    trud[j] = t;
                }
                niza[i] = new PhDStudent(ime, indeks, god, oceni, n, trud, n_tr);
            }
        }
        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];

        // dodavanje nov trud za PhD student spored indeks
        Trud t;
        cin >> indeks;
//        cin >> t;

        // vmetnete go kodot za dodavanje nov trud so pomos na operatorot += i spravete se so isklucokot
        for (int i = 0; i < m; i++) {
            if (niza[i]->getIndex() == indeks && dynamic_cast<PhDStudent*>(niza[i]) != nullptr) {
                try {
                    *dynamic_cast<PhDStudent*>(niza[i]) += t;
                } catch (Exception& e) {
                    e.print();
                }
            }
        }

        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];
    }
    if (testCase == 6){
        cout << "===== Testiranje na static clenovi ======" << endl;
        Student **niza;
        cin >> m;
        niza = new Student *[m];
        for (int i = 0; i<m; i++){
            cin >> izbor;
            cin >> ime;
            cin >> indeks;
            cin >> god;
            cin >> n;
            for (int j = 0; j < n; j++)
                cin >> oceni[j];

            if (izbor == 0){
                niza[i] = new Student(ime, indeks, god, oceni, n);
            }
            else{
                cin >> n_tr;
                for (int j = 0; j < n_tr; j++){
                    cin >> tip;
                    cin >> god_tr;
                    Trud t(tip, god_tr);
                    trud[j] = t;
                }
                niza[i] = new PhDStudent(ime, indeks, god, oceni, n, trud, n_tr);
            }
        }
        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];

        int conf, journal;
        cin >> conf;
        cin >> journal;

        //postavete gi soodvetnite vrednosti za statickite promenlivi

        // pecatenje na site studenti
        cout << "\nLista na site studenti:\n";
        for (int i = 0; i < m; i++)
            cout << *niza[i];
    }

    return 0;
}