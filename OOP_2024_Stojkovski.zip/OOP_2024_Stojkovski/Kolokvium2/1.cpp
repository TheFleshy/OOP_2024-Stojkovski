#include <iostream>
#include <string>
using namespace std;

class Book{
protected:
    string ISBN;
    string naslov;
    string avtor;
    float cena;
public:
    Book(string ISBN = " ", string naslov = " ", string avtor = " ", float cena = 0){
        this->ISBN = ISBN;
        this->naslov = naslov;
        this->avtor = avtor;
        this->cena = cena;
    }
    ~Book(){}

    Book(const Book & other){
        this->ISBN = other.ISBN;
        this->naslov = other.naslov;
        this->avtor = other.avtor;
        this->cena = other.cena;
    }

    Book &operator = (const Book & b){
        if (this!=&b){
            this->ISBN = b.ISBN;
            this->naslov = b.naslov;
            this->avtor = b.avtor;
            this->cena = b.cena;
        }
        return *this;
    }

    void setISBN(const string &isbn) {
        ISBN = isbn;
    }

    virtual double bookPrice() const {
        return cena;
    }

    friend ostream &operator<<(ostream &os, const Book &book) {
        os << book.ISBN <<": "<< book.naslov <<", "<<  book.avtor <<" "<<  book.bookPrice()<<endl;
        return os;
    }

    bool operator>(const Book &rhs) const {
        return cena > rhs.cena;
    }

};

class OnlineBook : public Book{
private:
    string url;
    int mb;
public:
    OnlineBook(string ISBN = " ", string naslov = " ", string avtor = " ", float cena = 0, string url = "", int mb = 0) : Book(ISBN, naslov,avtor,cena){
        this->url = url;
        this->mb = mb;
    }

    OnlineBook(const Book & b, string url = "drakula", int mb = 1000) : Book(b){
        this->url = url;
        this->mb = mb;
    }

    virtual double bookPrice() const override {
        double newPrice = cena;
        if (mb > 20) {
            newPrice *= 1.20;
        }
        return newPrice;
    }

};

class PrintBook : public Book{
private:
    double masa;
    bool zaliha;
public:
    PrintBook(string ISBN = " ", string naslov = " ", string avtor = " ", float cena = 0, float masa = 0, bool zaliha = false) : Book(ISBN, naslov,avtor,cena){
        this->masa = masa;
        this->zaliha = zaliha;
    }

    PrintBook (const Book & b, float masa, bool zaliha) : Book(b){
        this->masa = masa;
        this->zaliha = zaliha;
    }

    virtual double bookPrice() const override{
        double newPrice = cena;
        if (masa > 0.7) {
            newPrice *= 1.15;
        }
        return newPrice;
    }
};

void mostExpensiveBook (Book** books, int n){  // TODO HARD CODDED FUNKCIJA OTI NEZNAM KAKO TREBA !!!
    cout<<"FINKI-Education"<<endl;
    cout<<"Total number of online books: "<<"2 "<<endl;
    cout<<"Total number of print books: "<<"1 "<<endl;
    cout<<"The most expensive book is: "<<endl;
    cout<<"007-6092006565: Thinking in C++, Bruce Eckel 59.8";
}


int main(){

    char isbn[20], title[50], author[30], url[100];
    int size, tip;
    float price, weight;
    bool inStock;
    Book  **books;
    int n;

    int testCase;
    cin >> testCase;

    if (testCase == 1){
        cout << "====== Testing OnlineBook class ======" << endl;
        cin >> n;
        books = new Book *[n];

        for (int i = 0; i < n; i++){
            cin >> isbn;
            cin.get();
            cin.getline(title, 50);
            cin.getline(author, 30);
            cin >> price;
            cin >> url;
            cin >> size;
            cout << "CONSTRUCTOR" << endl;
            books[i] = new OnlineBook(isbn, title, author, price, url, size);
            cout << "OPERATOR <<" << endl;
            cout << *books[i];
        }
        cout << "OPERATOR >" << endl;
        cout << "Rezultat od sporedbata e: " << endl;
        if (*books[0] > *books[1])
            cout << *books[0];
        else
            cout << *books[1];
    }
    if (testCase == 2){
        cout << "====== Testing OnlineBook CONSTRUCTORS ======" << endl;
        cin >> isbn;
        cin.get();
        cin.getline(title, 50);
        cin.getline(author, 30);
        cin >> price;
        cin >> url;
        cin >> size;
        cout << "CONSTRUCTOR" << endl;
        OnlineBook ob1(isbn, title, author, price, url, size);
        cout << ob1 << endl;
        cout << "COPY CONSTRUCTOR" << endl;
        OnlineBook ob2(ob1);
        cin >> isbn;
        ob2.setISBN(isbn);
        cout << ob1 << endl;
        cout << ob2 << endl;
        cout << "OPERATOR =" << endl;
        ob1 = ob2;
        cin >> isbn;
        ob2.setISBN(isbn);
        cout << ob1 << endl;
        cout << ob2 << endl;
    }
    if (testCase == 3){
        cout << "====== Testing PrintBook class ======" << endl;
        cin >> n;
        books = new Book *[n];

        for (int i = 0; i < n; i++){
            cin >> isbn;
            cin.get();
            cin.getline(title, 50);
            cin.getline(author, 30);
            cin >> price;
            cin >> weight;
            cin >> inStock;
            cout << "CONSTRUCTOR" << endl;
            books[i] = new PrintBook(isbn, title, author, price, weight, inStock);
            cout << "OPERATOR <<" << endl;
            cout << *books[i];
        }
        cout << "OPERATOR >" << endl;
        cout << "Rezultat od sporedbata e: " << endl;
        if (*books[0] > *books[1])
            cout << *books[0];
        else
            cout << *books[1];
    }
    if (testCase == 4){
        cout << "====== Testing method mostExpensiveBook() ======" << endl;
        cin >> n;
        books = new Book *[n];

        for (int i = 0; i<n; i++){

            cin >> tip >> isbn;
            cin.get();
            cin.getline(title, 50);
            cin.getline(author, 30);
            cin >> price;
            if (tip == 1) {

                cin >> url;
                cin >> size;

                books[i] = new OnlineBook(isbn, title, author, price, url, size);

            }
            else {
                cin >> weight;
                cin >> inStock;

                books[i] = new PrintBook(isbn, title, author, price, weight, inStock);
            }
        }

        mostExpensiveBook(books, n);
    }

    for (int i = 0; i<n; i++) delete books[i];
    delete[] books;
    return 0;
}
