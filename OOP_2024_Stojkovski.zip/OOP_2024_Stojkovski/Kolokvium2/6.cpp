// TODO ZADACITE SA KATASTROFA PRAENI ZA SO USTE NE SE I SVASTA IMA U NIH HAOS SA
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

class ExistingGame {
private:
    char msg[256];

public:
    ExistingGame(char msg_txt[]) {
        strncpy(this->msg, msg_txt, 255);
        this->msg[255] = '\0';
    }

    void message() {
        std::cout << this->msg << std::endl;
    }
};

class Game {
protected:
    string name;
    float cena;
    bool daliKupenaRasprodazba;
public:
    Game(string name = "", float cena = 0, bool daliKupenaRasprodazba = false) {
        this->name = name;
        this->cena = cena;
        this->daliKupenaRasprodazba = daliKupenaRasprodazba;
    }

    Game(const Game &other) {
        this->name = other.name;
        this->cena = other.cena;
        this->daliKupenaRasprodazba = other.daliKupenaRasprodazba;
    }

    friend ostream &operator<<(ostream &os, const Game &game) {
        os << "Game: " << game.name << ", regular price: $" << game.cena;
        if (game.daliKupenaRasprodazba) {
            cout << ", bought on sale";
        }
        return os;
    }

    friend istream &operator>>(istream &is, Game &game) {
        is >> game.name;
        is >> game.cena;
        is >> game.daliKupenaRasprodazba;
        return is;
    }

    bool operator==(const Game &rhs) const {
        return name == rhs.name;
    }

};

class SubscriptionGame : public Game {
private:
    float nadomestok;
    int mesec, godina;
public:
    SubscriptionGame(string name = "", float cena = 0, bool daliKupenaRasprodazba = false, float nadomestok = 0,
                     int mesec = 0, int godina = 0) : Game(name, cena, daliKupenaRasprodazba) {
        this->nadomestok = nadomestok;
        this->mesec = mesec;
        this->godina = godina;
    }

    SubscriptionGame(const Game &g, float nadomestok, int mesec, int godina) : Game(g) {
        this->nadomestok = nadomestok;
        this->mesec = mesec;
        this->godina = godina;
    }

    friend istream &operator>>(istream &i, SubscriptionGame &g) {
        i >> g.name;
        i >> g.cena >> g.daliKupenaRasprodazba;
        i >> g.nadomestok >> g.mesec >> g.godina;
        return i;
    }

    friend ostream &operator<<(ostream &os, const SubscriptionGame &game) {
        os << "Game: " << game.name << ", regular price: $" << game.cena;
        if (game.daliKupenaRasprodazba) {
            cout << ", bought on sale, ";
        }
        os << "monthly fee: $" << game.nadomestok << ", purchased: " << game.mesec << "-" << game.godina;
    }
};

class User {
private:
    string username;
    Game **games;
    int n;
public:
    User(string username = " ") {
        this->username = username;
        games = 0;
        n = 0;
    }

    ~User() {
        delete[] games;
    }

    User(const User &other) {
        this->username = other.username;
        this->games = new Game *[n];
        for (int i = 0; i < n; i++) {
            this->games[i] = new Game(*(other.games[i]));
        }
    }

    User& operator+=(Game&g){

        Game ** new_games = new Game*[this->n+1];

        for (int i=0; i < (this->n); ++i) {
            if ( (*(this->games[i])) == g){
                throw ExistingGame("The game is already in the collection");
            }

            new_games[i] = games[i];
        }

        for (int i=0; i < (this->n); ++i) {
            new_games[i] = games[i];
        }

        SubscriptionGame * sg = dynamic_cast< SubscriptionGame* >(&g);

        if(sg){

            new_games[n] = new SubscriptionGame(*sg);
        }
        else {
            //cout<<"Game"<<endl;
            new_games[n] = new Game(g);
        }

        delete [] this->games;
        this->games = new_games;
        this->n++;

        //cout<<"User: "<< this->username<<endl;

//    for (int i=0; i<this->n;++i){
//        cout<< *(this->games[i]);
//    }

        return *this;
    }
};

int main() {
    int test_case_num;

    cin >> test_case_num;

    // for Game
    char game_name[100];
    float game_price;
    bool game_on_sale;

    // for SubscritionGame
    float sub_game_monthly_fee;
    int sub_game_month, sub_game_year;

    // for User
    char username[100];
    int num_user_games;

    if (test_case_num == 1) {
        cout << "Testing class Game and operator<< for Game" << std::endl;
        cin.get();
        cin.getline(game_name, 100);
        //cin.get();
        cin >> game_price >> game_on_sale;

        Game g(game_name, game_price, game_on_sale);

        cout << g;
    } else if (test_case_num == 2) {
        cout << "Testing class SubscriptionGame and operator<< for SubscritionGame" << std::endl;
        cin.get();
        cin.getline(game_name, 100);

        cin >> game_price >> game_on_sale;

        cin >> sub_game_monthly_fee;
        cin >> sub_game_month >> sub_game_year;

        SubscriptionGame sg(game_name, game_price, game_on_sale, sub_game_monthly_fee, sub_game_month, sub_game_year);
        cout << sg;
    } else if (test_case_num == 3) {
        cout << "Testing operator>> for Game" << std::endl;
        Game g;

        cin >> g;

        cout << g;
    } else if (test_case_num == 4) {
        cout << "Testing operator>> for SubscriptionGame" << std::endl;
        SubscriptionGame sg;

        cin >> sg;

        cout << sg;
    } else if (test_case_num == 5) {
        cout << "Testing class User and operator+= for User" << std::endl;
        cin.get();
        cin.getline(username, 100);
        User u(username);

        int num_user_games;
        int game_type;
        cin >> num_user_games;

        try {

            for (int i = 0; i < num_user_games; ++i) {

                cin >> game_type;

                Game *g;
                // 1 - Game, 2 - SubscriptionGame
                if (game_type == 1) {
                    cin.get();
                    cin.getline(game_name, 100);

                    cin >> game_price >> game_on_sale;
                    g = new Game(game_name, game_price, game_on_sale);
                } else if (game_type == 2) {
                    cin.get();
                    cin.getline(game_name, 100);

                    cin >> game_price >> game_on_sale;

                    cin >> sub_game_monthly_fee;
                    cin >> sub_game_month >> sub_game_year;
                    g = new SubscriptionGame(game_name, game_price, game_on_sale, sub_game_monthly_fee, sub_game_month,
                                             sub_game_year);
                }

                //cout<<(*g);


                u += (*g);
            }
        } catch (ExistingGame &ex) {
            ex.message();
        }

        cout << u;

//    cout<<"\nUser: "<<u.get_username()<<"\n";

//    for (int i=0; i < u.get_games_number(); ++i){
//        Game * g;
//        SubscriptionGame * sg;
//        g = &(u.get_game(i));

//        sg = dynamic_cast<SubscriptionGame *> (g);

//        if (sg){
//          cout<<"- "<<(*sg);
//        }
//        else {
//          cout<<"- "<<(*g);
//        }
//        cout<<"\n";
//    }

    } else if (test_case_num == 6) {
        cout << "Testing exception ExistingGame for User" << std::endl;
        cin.get();
        cin.getline(username, 100);
        User u(username);

        int num_user_games;
        int game_type;
        cin >> num_user_games;

        for (int i = 0; i < num_user_games; ++i) {

            cin >> game_type;

            Game *g;
            // 1 - Game, 2 - SubscriptionGame
            if (game_type == 1) {
                cin.get();
                cin.getline(game_name, 100);

                cin >> game_price >> game_on_sale;
                g = new Game(game_name, game_price, game_on_sale);
            } else if (game_type == 2) {
                cin.get();
                cin.getline(game_name, 100);

                cin >> game_price >> game_on_sale;

                cin >> sub_game_monthly_fee;
                cin >> sub_game_month >> sub_game_year;
                g = new SubscriptionGame(game_name, game_price, game_on_sale, sub_game_monthly_fee, sub_game_month,
                                         sub_game_year);
            }

            //cout<<(*g);

            try {
                u += (*g);
            }
            catch (ExistingGame &ex) {
                ex.message();
            }
        }

        cout << u;

//      for (int i=0; i < u.get_games_number(); ++i){
//          Game * g;
//          SubscriptionGame * sg;
//          g = &(u.get_game(i));

//          sg = dynamic_cast<SubscriptionGame *> (g);

//          if (sg){
//            cout<<"- "<<(*sg);
//          }
//          else {
//            cout<<"- "<<(*g);
//          }
//          cout<<"\n";
//      }
    } else if (test_case_num == 7) {
        cout << "Testing total_spent method() for User" << std::endl;
        cin.get();
        cin.getline(username, 100);
        User u(username);

        int num_user_games;
        int game_type;
        cin >> num_user_games;

        for (int i = 0; i < num_user_games; ++i) {

            cin >> game_type;

            Game *g;
            // 1 - Game, 2 - SubscriptionGame
            if (game_type == 1) {
                cin.get();
                cin.getline(game_name, 100);

                cin >> game_price >> game_on_sale;
                g = new Game(game_name, game_price, game_on_sale);
            } else if (game_type == 2) {
                cin.get();
                cin.getline(game_name, 100);

                cin >> game_price >> game_on_sale;

                cin >> sub_game_monthly_fee;
                cin >> sub_game_month >> sub_game_year;
                g = new SubscriptionGame(game_name, game_price, game_on_sale, sub_game_monthly_fee, sub_game_month,
                                         sub_game_year);
            }

            //cout<<(*g);


            u += (*g);
        }

        cout << u;

        cout << "Total money spent: $" << u.total_spent() << endl;
    }
}
