class Country{
private:
    char name[100];
    char capital[100];
    double area;
    double population;
public:
    Country() : area(0.0), population(0.0){
        strcpy(this->name,"");
        strcpy(this->capital,"");
    }   // Default Constructor

    Country(char *name, char *capital, double area, double population) : area(area),population(population) {
        strcpy(this->name, name);
        strcpy(this->capital, capital);
    }   // Constructor

    ~Country() {

    }   // Destructor

    // seteri i geteri, iako ne ni trebaat
    const char *getName() const {
        return name;
    }

    const char *getCapital() const {
        return capital;
    }

    double getArea() const {
        return area;
    }

    void setArea(double area) {
        Country::area = area;
    }

    double getPopulation() const {
        return population;
    }

    void setPopulation(double population) {
        this->population = population;
    }

    void read(){
        cin>>name>>capital>>area>>population;
    }

    void display(){
        cout<<"Country: "<<this->name<<endl<<"Capital: "<<this->capital<<endl<<"Area: "<<this->area<<endl<<"Population: "<<this->population<<endl;
    }

    static void sortCountries(Country *countries, int n);   // koga treba nekoja funkcija ili promenliva da se definira nadvor od klasata koristi static
    void setName(const char* name) {
        strcpy(this->name, name);
    }
    void setCapital(const char* capital) {
        strcpy(this->capital, capital);
    }
};

void swap(Country &c1, Country &c2){
    Country t=c1;
    c1=c2;
    c2=t;
}

void Country::sortCountries(Country *countries, int n) {
    Country sortedCountries[100];
    for(int i=0; i<n; i++){
        for(int j=0; j<n-1; j++){
            if(countries[i].area<countries[j].area){
                swap(countries[i],countries[j]);
            }
        }
    }
    for(int i=0; i<n; i++){
        countries[i].display();
    }
}