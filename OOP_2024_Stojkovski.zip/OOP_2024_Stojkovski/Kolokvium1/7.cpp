#include <iostream>
using namespace std;

struct Vozenje {
    char ime[100];
    int traenje;
    double cena;
    int daliPopust;      // 1 - da , 0 - ne
};

struct ZabavenPark {
    char ime[100];
    char lokacija[100];
    Vozenje niza [100];
    int n;
};

void pecati (ZabavenPark * niza, int n){
    for (int i=0; i<n; i++){
        cout<<niza[i].ime <<" "<< niza[i].lokacija<<endl;
        for (int j=0; j<niza[i].n; j++){
            printf("%s %d %.2f\n",niza[i].niza[j].ime,niza[i].niza[j].traenje,niza[i].niza[j].cena);
        }
    }
}

void najdobar_park (ZabavenPark * niza, int n){
    int maxI = 0; int maxV = 0; int maxVremetranje = 0;
    for (int i=0; i<n; i++){
        int brojac = 0;
        int vreme = 0;
        for (int j=0; j<niza[i].n; j++){
            if (niza[i].niza[j].daliPopust == 1){
                brojac++;
            }
                vreme += niza[i].niza[j].traenje;
        }
        if (brojac > maxV){
            maxV = brojac;
            maxI = i;
            maxVremetranje = vreme;
        }else if (brojac == maxV && vreme > maxVremetranje){
            maxI = i;
            maxVremetranje = vreme;
        }
    }
    cout << "Najdobar park: " << niza[maxI].ime << " " << niza[maxI].lokacija << endl;
}

int main()
{
    int i, j, n, broj;
    //kreiraj niza od maksimum 100 zabavni parkovi
    ZabavenPark ff[100];
    cin>>n;
    //citanje na podatocite
    for (i = 0; i < n; i++){
        cin >> ff[i].ime >> ff[i].lokacija >> ff[i].n;

        for (j = 0; j < ff[i].n; j++){
            cin >> ff[i].niza[j].ime >> ff[i].niza[j].traenje >> ff[i].niza[j].cena >> ff[i].niza[j].daliPopust;
        }
    }
    pecati(ff,n);
    najdobar_park(ff,n);

    return 0;
}
