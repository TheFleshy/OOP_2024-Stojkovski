#include <iostream>
#include <cstring>
using namespace std;

enum Tip {
    LINUX, UNIX, WINDOWS
};

class OperativenSistem {
private:
    char * name;
    float version;
    Tip tip;
    float capacity;
public:

    OperativenSistem(){
        name = new char[2];
        strcpy(this->name, "");
        this->version = 0;
        this->tip = WINDOWS;
        this->capacity = 0;
    }

    OperativenSistem(char * name  , float version , Tip tip , float capacity){
        this->name = new char [strlen(name) + 1];
        strcpy(this->name, name);
        this->version = version;
        this->tip = tip;
        this->capacity = capacity;
    }

    OperativenSistem(const OperativenSistem & other){
        this->name = new char [strlen(other.name) + 1];
        strcpy(this->name, other.name);
        this->version = other.version;
        this->tip = other.tip;
        this->capacity = other.capacity;
    }

    ~OperativenSistem(){
        delete [] name;
    }

    void pecati(){
        cout<<"Ime: "<<name<<" Verzija: "<<version<<" Tip: "<<tip<<" Golemina:"<<capacity<<"GB"<<endl;
    }

    bool ednakviSe(const OperativenSistem &os){
        return (strcmp(this->name, os.name) == 0
        && this->version == os.version && this->tip == os.tip && this->capacity == os.capacity);
    }

    OperativenSistem & operator =(const OperativenSistem & other){
        if (this != &other) {
            delete[] this->name;
            this->name = new char[strlen(other.name) + 1];
            strcpy(name, other.name);
            this->version = other.version;
            this->tip = other.tip;
            this->capacity = other.capacity;
        }

        return *this;
    }

    int sporediVerzija(const OperativenSistem &os){
        if (this->version == os.version){
            return 0;
        }
        else if (this->version > os.version){
            return -1;
        }
        else {
            return 1;
        }
    }

    bool istaFamilija(const OperativenSistem &sporedba) {
        if (strcmp(this->name, sporedba.name) == 0 && this->tip == sporedba.tip){
            return true;
        }else{
            return false;
        }
    }

    char *getName() const {
        return name;
    }

};

class Repozitorium{
private:
    char name[21];
    OperativenSistem *niza;
    int n;
public:
    Repozitorium(const char *name){
        strcpy(this->name, name);
        this->n = 0;
    }

    ~Repozitorium(){
        delete [] niza;
    }

    void pecatiOperativniSistemi(){
        cout<<"Repozitorium: "<<name<<endl;
        for (int i=0; i<n; i++){
            niza[i].pecati();
        }
    }

    void izbrishi(const OperativenSistem &operativenSistem){
        for (int i = 0; i < n; i++) {
            if (niza[i].ednakviSe(operativenSistem)) {
                int counter = 0;
                OperativenSistem * tmp = new OperativenSistem[n-1];
                for (int j = 0; j < n; j++) {
                    if (i==j) continue;
                    else {
                        tmp[counter++]=niza[j];
                    }
                }
                delete [] niza;
                niza = tmp;
                n--;
            }
        }
    }

    void dodadi(const OperativenSistem &nov){
        if(n==0){
            this->niza = new OperativenSistem[1];
            this->n=1;
            niza[0] = nov;
        }else{
            bool pass = false;
            for(int i=0; i<n; i++){
                if(niza[i].istaFamilija(nov)){
                    if(niza[i].sporediVerzija(nov)==1){
                        niza[i]=nov;
                        pass=true;
                    }
                }
            }
            if (pass == false){
                OperativenSistem *tmp;
                tmp = new OperativenSistem[n+1];
                for(int j=0; j<n; j++){
                    tmp[j] = niza[j];
                }
                tmp[n] = nov;
                n++;
                delete [] niza;
                niza = tmp;
            }
        }
    }

//    friend class OperativenSistem;

};

int main() {
    char repoName[20];
    cin>>repoName;
    Repozitorium repozitorium=Repozitorium(repoName);
    int brojOperativniSistemi = 0;
    cin>>brojOperativniSistemi;
    char ime[20];
    float verzija;
    int tip;
    float golemina;
    for (int i = 0; i<brojOperativniSistemi; i++){
        cin>>ime;
        cin>>verzija;
        cin>>tip;
        cin>>golemina;
        OperativenSistem os = OperativenSistem(ime, verzija, (Tip)tip, golemina);
        repozitorium.dodadi(os);
    }

    repozitorium.pecatiOperativniSistemi();
    cin>>ime;
    cin>>verzija;
    cin>>tip;
    cin>>golemina;
    OperativenSistem os = OperativenSistem(ime, verzija, (Tip)tip, golemina);
    cout<<"=====Brishenje na operativen sistem====="<<endl;
    repozitorium.izbrishi(os);
    repozitorium.pecatiOperativniSistemi();
    return 0;
}