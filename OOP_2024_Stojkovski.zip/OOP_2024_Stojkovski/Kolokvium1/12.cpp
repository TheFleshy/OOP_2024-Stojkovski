#include <iostream>
#include <cstring>
using namespace std;

class Pica{
private:
    char name[16];
    int cena;
    char * sostojki;
    int namaluvanjeCena;
public:
    Pica(char * name = "", int cena = 0, char * sostojki = "", int namaluvanjeCena=0){
        strcpy(this->name, name);
        this->cena = cena;
        this->sostojki = new char [strlen(sostojki)+1];
        strcpy(this->sostojki, sostojki);
        this->namaluvanjeCena = namaluvanjeCena;
    }

    Pica(const Pica & other){
        strcpy(this->name, other.name);
        this->cena = other.cena;
        this->sostojki = new char [strlen(other.sostojki)+1];
        strcpy(this->sostojki, other.sostojki);
        this->namaluvanjeCena = other.namaluvanjeCena;
    }

    ~Pica(){
        delete [] sostojki;
    }

    Pica &operator = (const Pica & other){
        if (this != &other){
            delete [] sostojki;
            strcpy(this->name, other.name);
            this->cena = other.cena;
            this->sostojki = new char [strlen(other.sostojki)+1];
            strcpy(this->sostojki, other.sostojki);
            this->namaluvanjeCena = other.namaluvanjeCena;

        }
        return *this;
    }

    void pecati(){
        cout<<name<<" - "<<sostojki<<", "<<cena;
    }

    bool istiSe(Pica p){
        return (strcmp(this->sostojki, p.sostojki)==0);
    }

    int getNamaluvanjeCena() const {
        return namaluvanjeCena;
    }

    int getCena() const {
        return cena;
    }

};

class Picerija{
private:
    char name [16];
    Pica * niza;
    int brPici;
public:
    Picerija(const char * name = ""){
        strcpy(this->name, name);
        this->brPici = 0;
        this->niza = new Pica[0];
    }

    Picerija(const Picerija & other){
        strcpy(this->name, other.name);
        this->niza = new Pica[other.brPici];
        for (int i=0; i<other.brPici; i++){
            niza[i] = other.niza[i];
        }
    }

    ~Picerija(){
        delete [] niza;
    }

    Picerija &operator = (const Picerija & other){
        if (this != &other){
            delete [] niza;
            strcpy(this->name, other.name);
            this->niza = new Pica[other.brPici];
            for (int i=0; i<other.brPici; i++){
                niza[i] = other.niza[i];
            }
        }
        return *this;
    }

    Picerija &operator += (const Pica & other){
        Pica * tmp = new Pica[brPici+1];
        for (int i=0; i<brPici; i++){
            tmp[i] = niza[i];
        }
        tmp[brPici++] = other;
        delete [] niza;
        niza = tmp;
        return *this;
    }

    const char *getIme() const {
        return name;
    }

    void setIme(const char * name){
        strcpy(this->name, name);
        this->name[16] = 0;
    }

    void piciNaPromocija(){
        for (int i=0; i<brPici;i++){
            if (niza[i].getNamaluvanjeCena()!=0){
                niza[i].pecati();
                cout << " " << niza[i].getCena() * (1 - niza[i].getNamaluvanjeCena() / 100.0) << endl;
            }
        }
    }
};

int main() {

    int n;
    char ime[15];
    cin >> ime;
    cin >> n;

    Picerija p1(ime);
    for (int i = 0; i < n; i++){
        char imp[100];
        cin.get();
        cin.getline(imp, 100);
        int cena;
        cin >> cena;
        char sostojki[100];
        cin.get();
        cin.getline(sostojki, 100);
        int popust;
        cin >> popust;
        Pica p(imp, cena, sostojki, popust);
        p1+=p;
    }

    Picerija p2 = p1;
    cin >> ime;
    p2.setIme(ime);
    char imp[100];
    cin.get();
    cin.getline(imp, 100);
    int cena;
    cin >> cena;
    char sostojki[100];
    cin.get();
    cin.getline(sostojki, 100);
    int popust;
    cin >> popust;
    Pica p(imp, cena, sostojki, popust);
    p2+=p;

    cout << p1.getIme() << endl;
    cout << "Pici na promocija:" << endl;
    p1.piciNaPromocija();

    cout << p2.getIme() << endl;
    cout << "Pici na promocija:" << endl;
    p2.piciNaPromocija();

    return 0;
}
