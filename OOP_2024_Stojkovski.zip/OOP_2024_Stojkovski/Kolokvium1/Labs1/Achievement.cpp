#include <iostream>
#include <cstring>
using namespace std;

class UserProfile;

class Achievement{
private:
    char name[30];
    char description[100];
    static int totalUserAchievements;
public:
    Achievement(char *name = "", char *description="") {
        strcpy(this->name, name);
        strcpy(this->description, description);
    }
    Achievement(const Achievement & other){
        strcpy(this->name, other.name);
        strcpy(this->description, other.description);
    }

    ~Achievement(){}

    void print(){
        cout<<name<<endl;
        cout<<description<<endl;
    }

    static void incrementTotalUserAchievements(){
        totalUserAchievements++;
    };

    friend void showAchievementsProgress(UserProfile profiles[], int n, Achievement achievements [], int m);


};

int Achievement::totalUserAchievements = 0;

class UserProfile{
private:
    char name[30];
    Achievement achievements[50];
    int n;
public:

    UserProfile(char *name = " ", int n = 0){
        strcpy(this->name, name);
        this->n = n;
    }

    UserProfile (const UserProfile & other){
        strcpy(this->name, other.name);
        this->n = other.n;
    }

    void print() {
        cout<<this->name<<endl;
        for (int i=0; i<n; i++){
            achievements[i].print();
        }
    }

    void addAchievement (const Achievement & achievement){
        achievements[n++] = achievement;
        Achievement::incrementTotalUserAchievements();
    }

    friend class Achievement;
    friend void showAchievementsProgress(UserProfile profiles[], int n, Achievement achievements [], int m);

};

void showAchievementsProgress (UserProfile profiles[], int n, Achievement achievements [], int m){
    for (int i=0; i<m; i++){
        int profilesThatHaveAnAchivement = 0;
        achievements[i].print();
        for (int j=0; j<n; j++){
            if (strcmp(profiles[j].achievements[i].name, achievements[i].name)==0){
                profilesThatHaveAnAchivement++;
            }
        }
        double percentage = profilesThatHaveAnAchivement/n*100.0;
        cout<<percentage<<"%\n";
    }
}

int main(){
        char testcase[100];
        cin.getline(testcase, 100);

        int n;
        cin >> n;
        cin.ignore();

        char ignore[100];
        cin.getline(ignore, 100);
        UserProfile users[100];
        for (int i = 0; i < n; ++i) {
            char name[100];
            cin >> name;
            users[i] = UserProfile(name);
        }

        int m;
        cin >> m;
        cin.ignore();

        cin.getline(ignore, 100);
        Achievement achievements[100];
        for (int i = 0; i < m; ++i) {
            char name[100], description[100];
            cin.getline(name, 100);
            cin.getline(description, 100);
            achievements[i] = Achievement(name, description);
        }

        int k;
        cin >> k;
        cin.ignore();

        cin.getline(ignore, 100);
        for (int i = 0; i < k; ++i) {
            int numUser, numAchievement;
            cin >> numUser >> numAchievement;
            numUser -= 1;
            numAchievement -= 1;
            users[numUser].addAchievement(achievements[numAchievement]);
        }

        if (testcase[8] == 'A') {  // Testing Achievement methods.
            for (int i = 0; i < m; ++i) {
                achievements[i].print();
            }
            Achievement::incrementTotalUserAchievements();
        } else if (testcase[8] == 'U') {  // Testing UserProfile methods.
            for (int i = 0; i < n; ++i) {
                users[i].print();
            }
        } else {  // Testing showAchievementsProgress function.
            showAchievementsProgress(users, n, achievements, m);
        }
        return 0;
}