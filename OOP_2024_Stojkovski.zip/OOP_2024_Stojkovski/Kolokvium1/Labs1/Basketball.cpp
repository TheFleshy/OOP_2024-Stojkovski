#include <iostream>
#include <cstring>
using namespace std;

class BasketballPlayer {
private:
    char imeKosarkar[20];
    char prezimeKosarkar[20];
    int brojDres;
    int poeniPrv;
    int poeniVtor;
    int poeniTret;
public:
    BasketballPlayer(char * _imeKosarkar, char * _prezimeKosarkar, int _brojDres, int _poeniPrv, int _poeniVtor, int _poeniTret){
        strcpy(imeKosarkar, _imeKosarkar);
        strcpy(prezimeKosarkar, _prezimeKosarkar);
        brojDres = _brojDres;
        poeniPrv = _poeniPrv;
        poeniVtor = _poeniVtor;
        poeniTret = _poeniTret;
    }

    BasketballPlayer() : brojDres(0),poeniPrv(0),poeniVtor(0),poeniTret(0){
        strcpy(this->imeKosarkar,"");
        strcpy(this->prezimeKosarkar,"");
    }

    void read(){
        cin>>imeKosarkar>>prezimeKosarkar>>brojDres>>poeniPrv>>poeniVtor>>poeniTret;
    }

    void print (){
        double srednaVrednost = ((double)(poeniPrv+poeniVtor+poeniTret)/3);
        cout<<"Player: "<<imeKosarkar<<" "<<prezimeKosarkar<<" with number: "<<brojDres<<" has "<<(float)srednaVrednost<<" points on average"<<endl;
    }

};

int main (){

    char imeKosarkar[20];
    char prezimeKosarkar[20];
    int brojDres;
    int poeniPrv;
    int poeniVtor;
    int poeniTret;

    BasketballPlayer bp (imeKosarkar, prezimeKosarkar, brojDres, poeniPrv, poeniVtor, poeniTret);
    bp.read();
    bp.print();

    return 0;
}