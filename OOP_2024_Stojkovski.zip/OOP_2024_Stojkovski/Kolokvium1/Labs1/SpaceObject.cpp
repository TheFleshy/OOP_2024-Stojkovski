#include <iostream>
#include <cstring>
using namespace std;

class SpaceObject {
private:
    char imeObjekt [100];
    char tipObjekt [100];
    int dalecinaZemja;
public:
    void print (){
        cout<<imeObjekt<<" ("<<tipObjekt<<") - distance: "<<dalecinaZemja<<" lights years away from Earth"<<endl;
    }

    SpaceObject (char * _imeObjekt, char * _tipObjekt, int _dalecinaZemja){
        strcpy(imeObjekt, _imeObjekt);
        strcpy(tipObjekt, _tipObjekt);
        dalecinaZemja = _dalecinaZemja;
    }

    SpaceObject () : dalecinaZemja(0){
        strcpy(imeObjekt, " ");
        strcpy(tipObjekt, " ");
    }

//    void read (){
//        cin>>imeObjekt>>tipObjekt>>dalecinaZemja;
//    }

    const char *getImeObjekt() const {
        return imeObjekt;
    }

    int getDalecinaZemja() const {
        return dalecinaZemja;
    }

};

class Alien {
private:
    char ime[100];
    int godinki;
    char planeticka [100];
    int omileni;
    SpaceObject objektii[100];
public:
    Alien(char * _ime, int _godiniki, char * _planeticka, int _omileni, SpaceObject * _objekti){
        strcpy(ime, _ime);
        godinki = _godiniki;
        strcpy(planeticka, _planeticka);
        omileni = _omileni;
        for (int i=0; i<omileni; i++){
            objektii[i] = _objekti[i];
        }
    }

    Alien (){
        strcpy(ime, "Vladimir");
        godinki = 0;
        strcpy(planeticka, "Rusija");
        omileni = 0;
        SpaceObject objektii[100];
    }

    ~Alien(){}

    SpaceObject getObjectClosesToEarth(){
        SpaceObject najbliskuu = objektii[0];

        for (int i=0; i<omileni; i++){
            if (objektii[i].getDalecinaZemja()<najbliskuu.getDalecinaZemja()){
                najbliskuu = objektii[i];
            }
        }
        return najbliskuu;
    }

    void print(){
        SpaceObject najbliskaa = getObjectClosesToEarth();

        cout<<"Alien name: "<<ime<<endl;
        cout<<"Alien age: "<<godinki<<endl;
        cout<<"Alien home planet: "<<planeticka<<endl;
        cout<<"Favourite space object closest to earth: ";
        najbliskaa.print();
        cout<<endl;
    }

};

int main()
{
    char name[100], homePlanet[100];
    int age, numObj;
    cin>>name>>age>>homePlanet>>numObj;
    //Testing default constructor for SpaceObject
    SpaceObject spaceObjects[numObj];
    for(int i=0; i<numObj; i++)
    {
        char spaceObjectName[100], spaceObjectType[100];
        int distanceFromEarth;
        cin>>spaceObjectName>>spaceObjectType>>distanceFromEarth;
        //Testing constructor with arguments for SpaceObject
        spaceObjects[i]=SpaceObject(spaceObjectName, spaceObjectType, distanceFromEarth);
    }
    //Testing default constructor for Alien
    Alien alien;
    //Testing constructor with arguments for Alien and copy constructor for Alien
    alien=Alien(name, age, homePlanet, numObj, spaceObjects);
    Alien alien2 = Alien(alien);

    alien2.print();
    return 0;
}
