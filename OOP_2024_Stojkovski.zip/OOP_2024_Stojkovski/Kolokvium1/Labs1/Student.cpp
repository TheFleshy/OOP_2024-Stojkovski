#include <iostream>
#include <cstring>
using namespace std;

struct Student {

    char imeSutdent[100];
    int indexStudent;
    int brojKursovi;
    char kodoviSlusa[100];
};

struct Course {

    char imeKurs[100];
    int kodKurs;
    int brojStudenti;
};

int get_most_popular_course(struct Course courses[], int num_courses){
    // ke vraka kodot na najpopularniot kurs..
    int index = 0; int najmnoguStudenti = 0;
    for (int i=0; i<num_courses; i++){
        if (courses[i].brojStudenti > najmnoguStudenti){
            najmnoguStudenti = courses[i].brojStudenti;
            index = i;
        }
    }
    return index;
}

int main (){

    int brStudenti, brKursevi;
    cin>>brStudenti>>brKursevi;

    Course kursevi[brKursevi];

    for (int i=0; i<brKursevi; i++){
        char imeKurs[100];
        int kodNaKurs;
        cin>>imeKurs;
        cin>>kodNaKurs;
        kursevi[i].brojStudenti = 0;
        kursevi[i].kodKurs = kodNaKurs;
        strcpy(kursevi[i].imeKurs, imeKurs);
    }

    Student studenti[brStudenti];
    for (int i=0; i<brStudenti; i++){
        char ime[50];
        int brIndex, brKurseviStoGiSlusa;
        cin>>ime>>brIndex>>brKurseviStoGiSlusa;
        for (int j=0; j<brKurseviStoGiSlusa; j++){
            int kodNaKurs;
            cin>>kodNaKurs;
            studenti[j].kodoviSlusa[j] = kodNaKurs;
            for (int k=0; k<brKursevi; k++){
                if (kursevi[k].kodKurs == kodNaKurs){
                    kursevi[k].brojStudenti++;
                    break;
                }
            }
        }
        strcpy(studenti[i].imeSutdent, ime);
        studenti[i].brojKursovi = brKurseviStoGiSlusa;
    }

    int najpopularenKurs = get_most_popular_course(kursevi, brKursevi);
    cout<<"Najpopularen kurs e: "<<kursevi[najpopularenKurs].imeKurs<<endl;


    return 0;
}