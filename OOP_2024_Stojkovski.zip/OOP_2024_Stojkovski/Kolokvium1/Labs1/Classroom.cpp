//#include <iostream>
//#include <cstring>
//using namespace std;
//
//class Student{
//private:
//    char * name;
//    int age;
//    char * major;
//public:
//    Student (char * name = " ", int age = 0, char * major = ""){
//        this->age = age;
//        this->name = new char [strlen(name)+1];
//        strcpy(this->name, name);
//        this->major = new char [strlen(major)+1];
//        strcpy(this->major, major);
//    }
//
//    Student(const Student & other){
//        this->age = other.age;
//        this->name = new char [strlen(other.name)+1];
//        strcpy(this->name, other.name);
//        this->major = new char [strlen(other.major)+1];
//        strcpy(this->major, other.major);
//    }
//
//    ~Student(){
//        delete [] name;
//        delete [] major;
//    }
//
//    void printStudent(){
//        cout<<name<<" ("<<age<<", "<<major<<")\n";
//    }
//
//    char *getName() const {
//        return name;
//    }
//
//    int getAge() const {
//        return age;
//    }
//};
//
//class Classroom {
//private:
//    Student * students;
//    int numStudents;
//    int capacity;
//public:
//
//    Classroom(){
//        students = new Student[0];
//        numStudents = 0;
//        capacity = 0;
//    }
//
//    Classroom(Student * students , int numStudents , int capacity ){
//        this->students = new Student [numStudents];
//        for (int i=0; i<numStudents;i++){
//            this->students[i] = students[i];
//        }
//        this->numStudents = numStudents;
//        this->capacity = capacity;
//    }
//
//    ~Classroom(){
//        delete [] students;
//    }
//
//    void printStudents(){
//        for(int i=0; i<numStudents; i++){
//            students[i].printStudent();
//        }
//    }
//
//    void add (Student s){
//        Student * tmp = new Student [this->numStudents+1];
//        for (int i=0; i<numStudents; i++){
//            tmp[i] = students[i];
//        }
//        tmp[numStudents++] = s;
//        delete [] students;
//        students = tmp;
//    }
//
//    void remove(char * name){
//        int countStudents = 0;
//        for (int i=0; i<numStudents; i++){
//            if (strcmp(this->students[i].getName(), name) != 0){
//                countStudents++;
//            }
//        }
//        Student * tmp = new Student[countStudents];
//        for (int i=0; i<numStudents; i++){
//            for (int j=0; j<numStudents; j++){
//                tmp[j++] = students[i];
//            }
//        }
//        delete [] students;
//        students = tmp;
//        numStudents = countStudents;
//    }
//
//    Student *getStudents() const {
//        return students;
//    }
//
//    int getNumStudents() const {
//        return numStudents;
//    }
//
//    int getCapacity() const {
//        return capacity;
//    }
//};
//
//void swap(Student &a, Student &b){
//    Student tmp = a;
//    a=b;
//    b=tmp;
//}
//void sort(Classroom & cr){
//    for(int i=0; i<cr.getNumStudents()-1; i++){
//        for(int j=i+1; j<cr.getNumStudents(); j++){
//            if(cr.getStudents()[i].getAge() > cr.getStudents()[j].getAge()){
//                swap(cr.getStudents()[i],cr.getStudents()[j]);
//            }
//        }
//    }
//}
//
//double findMedianAge(Classroom & cr){
//    sort(cr);
//    double median = 0;
//    // Ako brojot na studenti e neparen
//    if(cr.getNumStudents() % 2){
//        median = cr.getStudents()[cr.getNumStudents()/2].getAge();
//    } else{
//        int lev = cr.getStudents()[cr.getNumStudents()/2-1].getAge();
//        int desen = cr.getStudents()[cr.getNumStudents()/2].getAge();
//        median = (double)(lev+desen)/2;
//    }
//    return (double)median;
//}
//
////DO NOT CHANGE
//int main() {
//    int numClassrooms, numStudents;
//    cin >> numClassrooms;
//    Classroom classrooms[100];
//    Student students[100];
//
//    // Testing add method
//    for (int i = 0; i < numClassrooms; i++) {
//        cin >> numStudents;
//        for (int j = 0; j < numStudents; j++) {
//            char name[100], major[100];
//            int age;
//            cin >> name >> age >> major;
//            Student student(name, age, major);
//            classrooms[i].add(student);
//            students[i*numStudents + j] = student;
//        }
//        cout<<"Classroom "<<i<<endl;
//        classrooms[i].printStudents();
//    }
//
//
//    // Testing findMedianAge method
//    int targetClassroom;
//    cin >> targetClassroom;
//    double medianAge = findMedianAge(classrooms[targetClassroom]);    // neznam ovaa treba da ja mozgam
//    cout << "The median age in classroom " << targetClassroom << " is: " << medianAge << endl;
//    cout<<"After removing the elements:"<<endl; // Added
//    // Testing remove method
//    cin >> numStudents;
//    for (int j = 0; j < numStudents; j++) {
//        char name[100];
//        cin >> name;
//        for (int i = 0; i < numClassrooms; i++) {
//            classrooms[i].remove(name);
//        }
//    }
//    for (int i = 0; i < numClassrooms; i++) {
//        cout<<"Classroom "<<i<<endl;
//        classrooms[i].printStudents();
//    }
//
//    return 0;
//}


#include <iostream>
#include <cstring>
using namespace std;

class Student{
    char * name;
    int age;
    char * major;
    void copy(const Student & s){
        this->name = new char [strlen(s.name)+1];
        strcpy(this->name,s.name);
        this->age = s.age;
        this->major = new char [strlen(s.major)+1];
        strcpy(this->major,s.major);
    }
public:
    Student(){
        this->name = new char [20];
        this->age = 0;
        this->major = new char [20];
    }

    Student(char *name, int age, char *major) {
        this->name = new char [strlen(name)+1];
        strcpy(this->name,name);
        this->age = age;
        this->major = new char [strlen(major)+1];
        strcpy(this->major,major);
    }

    virtual ~Student() {
        delete [] name;
        delete [] major;
    }

    Student(const Student & s){
        copy(s);
    }

    Student & operator = (const Student & s){
        if(this!=&s){
            delete [] name;
            delete [] major;
            copy(s);
        }
        return *this;
    }

    char *getName() const {
        return name;
    }

    int getAge() const {
        return age;
    }
    void printStudent(){
        cout<<name<<" ("<<age<<", "<<major<<")\n";
    }
};

class Classroom{
    Student *students;
    int numStudents;
    int capacity;
public:
    Classroom(){
        students = new Student[0];
        numStudents = 0;
        capacity = 0;
    }

    Classroom(Student *students, int numStudents, int capacity) {
        this->students = new Student [numStudents];
        for(int i=0; i<numStudents; i++){
            this->students[i] = students[i];
        }
        this->numStudents = numStudents;
        this->capacity = capacity;
    }

    virtual ~Classroom() {
        delete [] students;
    }
    void add(Student s){    // dali treba void?
        Student * tmp = new Student[this->numStudents+1];
        for(int i=0; i<numStudents; i++){
            tmp[i] = students[i];
        }
        tmp[numStudents++] = s;
        delete [] students;
        students = tmp;
        // DO TUKA
    }
    void remove(char * name){   // dali treba void
        int countStudents = 0;
        for(int i=0; i<numStudents; i++){
            if(strcmp(this->students[i].getName(),name)!=0){
                countStudents++;
            }
        }
        Student * tmp = new Student [countStudents];
        for(int i=0,j=0; i<numStudents; i++){
            if(strcmp(this->students[i].getName(),name)!=0){
                tmp[j++] = students[i];
            }
        }
        delete[]students;
        students = tmp;
        numStudents = countStudents;
    }

    Student *getStudents() const {
        return students;
    }

    int getNumStudents() const {
        return numStudents;
    }
    void printStudents(){
        for(int i=0; i<numStudents; i++){
            students[i].printStudent();
        }
        cout<<endl;
    }
};

void swap(Student &a, Student &b);
void sort(Classroom & cr);
double findMedianAge(Classroom & cr);

int main() {
    int numClassrooms, numStudents;
    cin >> numClassrooms;
    Classroom classrooms[100];
    Student students[100];

    // Testing add method
    for (int i = 0; i < numClassrooms; i++) {
        cin >> numStudents;
        for (int j = 0; j < numStudents; j++) {
            char name[100], major[100];
            int age;
            cin >> name >> age >> major;
            Student student(name, age, major);
            classrooms[i].add(student);
            students[i*numStudents + j] = student;
        }
        cout<<"Classroom "<<i<<endl;
        classrooms[i].printStudents();
    }


    // Testing findMedianAge method
    int targetClassroom;
    cin >> targetClassroom;
    double medianAge = findMedianAge(classrooms[targetClassroom]);
    cout << "The median age in classroom " << targetClassroom << " is: " << medianAge << endl;
    cout<<"After removing the elements:"<<endl; // Added
    // Testing remove method
    cin >> numStudents;
    for (int j = 0; j < numStudents; j++) {
        char name[100];
        cin >> name;
        for (int i = 0; i < numClassrooms; i++) {
            classrooms[i].remove(name);
        }
    }
    for (int i = 0; i < numClassrooms; i++) {
        cout<<"Classroom "<<i<<endl;
        classrooms[i].printStudents();
    }

    return 0;
}

void swap(Student &a, Student &b){
    Student tmp = a;
    a=b;
    b=tmp;
}

void sort(Classroom & cr){
    for(int i=0; i<cr.getNumStudents()-1; i++){
        for(int j=i+1; j<cr.getNumStudents(); j++){
            if(cr.getStudents()[i].getAge() > cr.getStudents()[j].getAge()){
                swap(cr.getStudents()[i],cr.getStudents()[j]);
            }
        }
    }
}

double findMedianAge(Classroom & cr){
    sort(cr);
    double median = 0;
    // Ako brojot na studenti e neparen
    if(cr.getNumStudents() % 2){
        median = cr.getStudents()[cr.getNumStudents()/2].getAge();
    } else{
        int lev = cr.getStudents()[cr.getNumStudents()/2-1].getAge();
        int desen = cr.getStudents()[cr.getNumStudents()/2].getAge();
        median = (double)(lev+desen)/2;
    }
    return (double)median;
}