#include <iostream>
#include <cstring>

using namespace std;

class Country {
private:
    char nameCountry[100];
    char capitalName[100];
    float area;
    float population;
public:
    Country() : area(0.0), population(0.0) {
        strcpy(this->nameCountry, "");
        strcpy(this->capitalName, "");
    }
    Country(char *_nameCountry, char *_capitalName, float _area, float _population) {
        strcpy(nameCountry, _nameCountry);
        strcpy(capitalName, _capitalName);
        area = _area;
        population = _population;
    }
    void display() {
        cout << "Country: " << nameCountry << endl;
        cout << "Capital: " << capitalName << endl;
        cout << "Area: " << area << endl;
        cout << "Population: " << population << endl;
    }

    void setArea(float area) {
        Country::area = area;
    }

    void setPopulation(float population) {
        Country::population = population;
    }

    void setName(char *_nameCountry) {
        strcpy(nameCountry, _nameCountry);
    }

    void setCapital(char *_capitalName) {
        strcpy(capitalName, _capitalName);

    }
    float getArea() const {
        return area;
    }
};

void sortCountries(Country *countries, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - 1; j++)
            if (countries[i].getArea() < countries[j].getArea()) {
                swap(countries[i], countries[j]);
            }
    }
    for (int i=0; i<n; i++){
        countries[i].display();
    }
}

int main() {
    int n;
    cin >> n;
    Country countries[100];

    char name[100];
    char capital[100];
    double area;
    double population;

    for (int i = 0; i < n - 1; i++) {
         cin >> name;
         cin >> capital;
         cin >> area;
         cin >> population;

         // testing constructor with arguments
         countries[i] = Country(name, capital, area, population);
    }


        // testing set methods and display for last element
    cin >> name;
    cin >> capital;
    cin >> area;
    cin >> population;
    countries[n - 1].setName(name);
    countries[n - 1].setCapital(capital);
    countries[n - 1].setArea(area);
    countries[n - 1].setPopulation(population);

    cout << "-->Testing set methods and display()" << endl;
    countries[n - 1].display();
    cout << endl;

    cout << "-->Testing sortCountries()" << endl;
    sortCountries(countries, n);
    return 0;
}

/*
5
Brazil Brasilia 8515 213.3
Chile Santiago 756 19.1
Cyprus Nicosia 9 1.2
Gambia Banjul 11 2.3
Greece Athens 131957 10.7
 */