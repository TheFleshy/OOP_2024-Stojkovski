#include <iostream>
using namespace std;

struct Transaction {
    int identifikaciskiBroj;
    int platenaSuma;
    int provizija;
    int platenoSo; // 0 - debitna, 1- kreditna

    void readTransaction(){
        cin>>identifikaciskiBroj>>platenaSuma>>provizija>>platenoSo;
    }

    void printTransaction (){
            int vkupnaProvizija = platenaSuma + provizija;
            cout<<identifikaciskiBroj<<" "<<vkupnaProvizija<<endl;
    }

};


int main (){

    int n;
    cin>>n;

    Transaction transakcija[100];

    for (int i=0; i<n; i++){
        transakcija[i].readTransaction();
    }

    int flag = 1;
    for (int i=0; i<n; i++){
        if (transakcija[i].platenoSo == 1) {
            flag = 0;
            transakcija[i].printTransaction();
        }
    }
    if (flag == 1){
        cout<<"No credit card transaction";
    }

    return 0;
}