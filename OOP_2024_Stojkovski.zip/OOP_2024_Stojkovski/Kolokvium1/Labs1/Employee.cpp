#include <iostream>
#include <cstring>
using namespace std;

class Employee {
private:
    char name[100];
    char surname[100];
    int salary;
public:
    Employee(char *name = "noname", char *surname = "nosurname", int salary = 0){
        strcpy(this->name, name);
        strcpy(this->surname, surname);
        this->salary = salary;
    }

    Employee(const Employee & other){
        strcpy(this->name, other.name);
        strcpy(this->surname, other.surname);
        this->salary = other.salary;
    }

    ~Employee(){}
    void printEmployee (){
        cout<<"Employee name: "<<this->name<<endl;
        cout<<"Employee surname: "<<this->surname<<endl;
        cout<<"Employee salary: "<<this->salary<<endl;
    }

    int getSalary() const {
        return salary;
    }
};

class TechCompany {
private:
    char name[100];
    Employee * employees;
    int numOfEmployees;
    void copy(const TechCompany & other){
        strcpy(this->name, other.name);
        this->numOfEmployees = other.numOfEmployees;
        this->employees = new Employee [other.numOfEmployees];
        for(int i=0; i < numOfEmployees; i++){
            this->employees[i] = other.employees[i];
        }
    }
public:
    TechCompany(){
        strcpy(this->name, name);
        this->numOfEmployees = 0;
        employees = new Employee[100];
    }
    TechCompany(char *name) {
        strcpy(this->name, name);
        this->numOfEmployees = 0;
        employees = new Employee[100];
    }

    TechCompany(const TechCompany & other){
        copy(other);
    }

    ~TechCompany(){}

    void addEmployee(Employee e){
        this->employees[this->numOfEmployees++] = e;
    }

    const char *getName() const {
        return name;
    }
    void setName(char * name){
        strcpy(this->name,name);
    }
    int getNumEmployees() const {
        return numOfEmployees;
    }

        Employee getEmployee(int i) const {
            return employees[i];
        }

        double getAverageOfEmployeeSalary(){
            double average = 0;
            for (int i=0; i<this->numOfEmployees; i++){
                average += this->employees[i].getSalary();
            }
        return (double)average/this->numOfEmployees;
    }
};

TechCompany printCompanyWithHighestAverageSalary (TechCompany companies[], int numCompanies){
    TechCompany c1 (companies[0]);
    for (int i=0; i<numCompanies; i++){
        if (companies[i].getAverageOfEmployeeSalary() > c1.getAverageOfEmployeeSalary()){
            c1 = companies[i];
        }
    }
    return c1;
}

TechCompany printCompanyWithHighestStdSalary (TechCompany companies[], int numCompanies){
    // neznajal brato demek ne bila objasnena dobro, a ono formulite sa kurcina pa zatoa
}

bool isSameCompany(TechCompany company1, TechCompany company2){
    return strcmp(company1.getName(), company2.getName()) == 0;
}

int main() {
    const int MAX_COMPANIES = 10;
    const int MAX_EMPLOYEES = 20;

    TechCompany companies[MAX_COMPANIES];

    int n;
    std::cin >> n;

    for (int i = 0; i < n; i++) {
        char name[100];
        std::cin >> name;

        TechCompany company(name);

        int m;
        std::cin >> m;

        for (int j = 0; j < m; j++) {
            char name[100];
            char surname[100];
            int salary;

            std::cin >> name;

            std::cin >> surname;

            std::cin >> salary;

            Employee employee(name, surname, salary);

            company.addEmployee(employee);
        }

        companies[i] = company;
    }

    TechCompany copy = companies[0];

    std::cout<<"-->Testing get and set methods for one object and copy constructor"<<std::endl;
    copy.setName("copy");
    std::cout << copy.getName() << std::endl;


    std::cout<<"-->Testing addEmployee function"<<std::endl;
    Employee newEmployee("John", "Doe", 5000);
    copy.addEmployee(newEmployee);
    std::cout << "Number of employees in copy: " << copy.getNumEmployees() << std::endl;


    std::cout<<"-->Testing copy of first employee"<<std::endl;
    Employee firstEmployee = copy.getEmployee(0);
    firstEmployee.printEmployee();


    std::cout<<"-->Testing methods"<<std::endl;
    TechCompany t = printCompanyWithHighestAverageSalary(companies, n);
    TechCompany t1 = printCompanyWithHighestStdSalary(companies, n);

    std::cout << "Tech company with the highest average salary: " << t.getName() << std::endl;
    std::cout << "Tech company with the highest standard deviation for salaries: " <<t1.getName() << std::endl;

    if (isSameCompany(t, t1)){
        std::cout<<"The tech company: "<<t.getName()<<" has the highest standard deviation and highest average salary"<<std::endl;
    }
    return 0;
}

