#include <iostream>
#include <cstring>
using namespace std;

class Chocolate {
private:
    char name[100];
    int price;
public:
    Chocolate(char * name = " ", int price = 0){
        strcpy(this->name, name);
        this->price = price;
    }

    friend ostream &operator<<(ostream &out, const Chocolate &c) {
        out << c.name<<": "<<"$"<<c.price;
        return out;
    }

    const char *getName() const {
        return name;
    }

    int getPrice() const {
        return price;
    }



};

class ChocolateFactory{
private:
    Chocolate * product;
    int * weeklyProduction;
    int numProducts;
public:
    ~ChocolateFactory(){
        delete [] product;
        delete [] weeklyProduction;
    }

    ChocolateFactory(Chocolate *product, int * weeklyProduction, int numProducts){
        this->numProducts = numProducts;
        this->product = new Chocolate[numProducts];
        this->weeklyProduction = new int[numProducts];
        for (int i=0; i<numProducts; i++){
            this->product[i] = product[i];
            this->weeklyProduction[i] = weeklyProduction[i];
        }
    }

    int weeklyIncome() const{
        int income = 0;
        for (int i=0; i<numProducts; i++){
            income += product[i].getPrice() * weeklyProduction[i];
        }
        return income;
    }

    friend ostream &operator<<(ostream &out, const ChocolateFactory &f) {
        for (int i=0; i<f.numProducts; i++){
            out<<f.product[i].getName()<<": "<<"$"<<f.product[i].getPrice()<<" x "<<f.weeklyProduction[i]<<endl;
        }
        out<<"$"<<f.weeklyIncome()<<"/wk\n";
        return out;
    }

    Chocolate *getProduct() const {
        return product;
    }

    int *getWeeklyProduction() const {
        return weeklyProduction;
    }

    int getNumProducts() const {
        return numProducts;
    }


};

bool operator<(const ChocolateFactory & first, const ChocolateFactory & second){
    return (first.weeklyIncome() < second.weeklyIncome());
}

bool operator>(const ChocolateFactory & first, const ChocolateFactory & second) {     // generirani neznam dali sa tocni
    return (first.weeklyIncome() > second.weeklyIncome());
}

ChocolateFactory operator+(const ChocolateFactory &first, const ChocolateFactory &second) {
    int totalProducts = first.getNumProducts() + second.getNumProducts();
    Chocolate *combinedProducts = new Chocolate[totalProducts];
    int *combinedWeeklyProduction = new int[totalProducts];

    for (int i = 0; i < first.getNumProducts(); i++) {
        combinedProducts[i] = first.getProduct()[i];
        combinedWeeklyProduction[i] = first.getWeeklyProduction()[i];
    }

    for (int i = 0; i < second.getNumProducts(); i++) {
        combinedProducts[first.getNumProducts() + i] = second.getProduct()[i];
        combinedWeeklyProduction[first.getNumProducts() + i] = second.getWeeklyProduction()[i];
    }

    ChocolateFactory combinedFactory(combinedProducts, combinedWeeklyProduction, totalProducts);
    return combinedFactory;
}

int main() {
    int testCase;
    char name[100];
    int price;

    Chocolate products[100];
    int weeklyProduction[100];

    cin >> testCase;
    if (testCase == 0) {
        cout<<"Testing Chocolate print operator:"<<endl;
        for (int i = 0; i < 10; ++i) {
            cin>>name>>price;
            cout<<Chocolate(name,price)<<endl;
        }
    }
    else if (testCase == 1) {
        cout<<"Testing ChocolateFactory print operator:"<<endl;

        for (int i = 0; i < 10; ++i) {
            cin>>name>>price;
            products[i] = Chocolate(name, price);
            cin>>weeklyProduction[i];
        }

        ChocolateFactory cf(products,weeklyProduction,10);
        cout<<cf<<endl;
    }
    else if (testCase == 2) {
        cout<<"Testing ChocolateFactory comparison operators:"<<endl;

        for (int i = 0; i < 3; ++i) {
            cin>>name>>price>>weeklyProduction[i];
            products[i] = Chocolate(name,price);
        }
        ChocolateFactory cf1 = ChocolateFactory(products,weeklyProduction,3);

        for (int i = 0; i < 4; ++i) {
            cin>>name>>price>>weeklyProduction[i];
            products[i] = Chocolate(name,price);
        }
        ChocolateFactory cf2 = ChocolateFactory(products,weeklyProduction,4);

        cout<<cf1<<cf2;

        cout<<"< operator: "<< (cf1<cf2 ? "PASS" : "FAIL") <<endl;
        cout<<"> operator: "<< (cf2>cf1 ? "PASS" : "FAIL") <<endl;
    }
    else if (testCase == 3) {
        cout<<"Testing ChocolateFactory sum operator:"<<endl;

        for (int i = 0; i < 5; ++i) {
            cin>>name>>price>>weeklyProduction[i];
            products[i] = Chocolate(name,price);
        }
        ChocolateFactory cf1 = ChocolateFactory(products,weeklyProduction,5);
        for (int i = 0; i < 5; ++i) {
            cin>>name>>price>>weeklyProduction[i];
            products[i] = Chocolate(name,price);
        }
        ChocolateFactory cf2 = ChocolateFactory(products,weeklyProduction,5);

        cout<<cf1+cf2;
    }
}


// sea za sea ne rabote samo + oti ne sam go napravil ama ke videme


