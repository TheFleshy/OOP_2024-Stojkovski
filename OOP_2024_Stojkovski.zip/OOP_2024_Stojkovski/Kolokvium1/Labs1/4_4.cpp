#include <iostream>
#include <cstring>
using namespace std;

class Patnik{
private:
    char ime[100];
    int klasa;
    bool velosiped;
    void copy(const Patnik &other){
        strcpy(this->ime,other.ime);
        this->klasa=other.klasa;
        this->velosiped=other.velosiped;
    }
public:
    Patnik(const char *ime=" ",const int klasa=1,const bool velosiped=false){
        strcpy(this->ime,ime);
        this->klasa=klasa;
        this->velosiped=velosiped;
        //2u1
    }
    Patnik(const Patnik &kopija){
        copy(kopija);
    }
    Patnik &operator =(const Patnik &p){
        if(this!=&p){
            copy(p);
        }
        return *this;
    }
    friend ostream& operator <<(ostream &out,const Patnik &p){
        out<<p.ime<<endl;
        out<<p.klasa<<endl;
        out<<p.velosiped<<endl;
        return out;
    }
    bool getvelosiped()const{
        return velosiped;
    }
    int getklasa()const{
        return klasa;
    }
};

class Voz{
private:
    char destinacija[100];
    Patnik *patnici;
    int brojelemnti;
    int brojdozvolenivelosipedi;
    void copy(const Voz &other){
        strcpy(this->destinacija,other.destinacija);
        this->brojelemnti=other.brojelemnti;
        this->brojdozvolenivelosipedi=other.brojdozvolenivelosipedi;
        this->patnici=new Patnik[other.brojelemnti];
        for(int i=0;i<brojelemnti;i++){
            this->patnici[i]=other.patnici[i];
        }
    }
public:
    Voz(char *destinacija=" ",int maxv=0){
        strcpy(this->destinacija,destinacija);
        this->brojdozvolenivelosipedi=maxv;
        this->brojelemnti=0;
        this->patnici=new Patnik[brojelemnti];
    }
    Voz operator +=(const Patnik &p){
        int brojvelosipedi=0;
        for(int i=0;i<brojelemnti;i++){
            if(patnici[i].getvelosiped()==true){
                brojvelosipedi++;
            }
        }
        if (!(p.getvelosiped() && brojdozvolenivelosipedi==0)){
            Patnik *tmp=new Patnik[brojelemnti+1];
            for (int i = 0; i < brojelemnti; ++i) {
                tmp[i]=patnici[i];
            }
            tmp[brojelemnti++]=p;
            delete[]patnici;
            patnici=tmp;
        }
        return *this;
    }
    friend ostream& operator <<(ostream &out,const Voz &v){
        out<<v.destinacija<<endl;
        if(v.brojdozvolenivelosipedi>0) {
            for (int i = 0; i < v.brojelemnti; i++) {
                out << v.patnici[i] << endl;
            }
        }
        if(v.brojdozvolenivelosipedi==0){
            for(int i=0;i<v.brojelemnti;i++){
                if(v.patnici[i].getvelosiped()==0){
                    out<<v.patnici[i]<<endl;
                }
            }
        }
        return out;
    }
    void patniciNemaMesto(){
        int brojvelosipediprva=0;
        int nedozvoleniprva=0;
        int brvtora=0;
        int nedvtora=0;
        int razlika=0;
        for(int i=0;i<brojelemnti;i++){
            if(patnici[i].getklasa()==1 && patnici[i].getvelosiped()==true) {
                brojvelosipediprva++;
            }
        }
        if(brojvelosipediprva-this->brojdozvolenivelosipedi>0){
            nedozvoleniprva=brojvelosipediprva-this->brojdozvolenivelosipedi;
        }
        else{
            nedozvoleniprva=0;
        }
        for(int i=0;i<brojelemnti;i++){
            if(patnici[i].getklasa()==2 && patnici[i].getvelosiped()==true) {
                brvtora++;
            }
        }
        razlika= (this->brojdozvolenivelosipedi-brojvelosipediprva);
        if(brvtora-razlika>=0){
            nedvtora=brvtora-razlika;
        }
        else{
            nedvtora=0;
        }
        cout<<"Brojot na patnici od 1-va klasa koi ostanale bez mesto e: "<<nedozvoleniprva<<endl;
        cout<<"Brojot na patnici od 2-ra klasa koi ostanale bez mesto e: "<<nedvtora<<endl;
    }
};

int main()
{
    Patnik p;
    char ime[100], destinacija[100];
    int n;
    bool velosiped;
    int klasa;
    int maxv;
    cin >> destinacija >> maxv;
    cin >> n;
    Voz v(destinacija, maxv);
    cout<<v<<endl;
    for (int i = 0; i < n; i++){
        cin >> ime >> klasa >> velosiped;
        Patnik p(ime, klasa, velosiped);
        cout<<p<<endl;
        v += p;
    }
    cout << v;
    v.patniciNemaMesto();

    return 0;
}
