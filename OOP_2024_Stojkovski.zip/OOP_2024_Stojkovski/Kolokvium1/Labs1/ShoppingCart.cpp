#include <iostream>
using namespace std;

struct Item{
    char imeProizvod[50];
    int cenaProizvod;
};

struct ShoppingCart{
    int id;
    int brItems;
    Item items[100];
};

int findLowestPrice(ShoppingCart kosnicka){
    int price = kosnicka.items[0].cenaProizvod;
    for (int i=1; i<kosnicka.brItems; i++){
        if (kosnicka.items[i].cenaProizvod < price){
            price = kosnicka.items[i].cenaProizvod;
        }
    }
    return price;
}

void printAveragePriceOfLowestItems(ShoppingCart s[], int n){
    double suma = 0;
    for (int i=0; i<n;i++){
        suma += findLowestPrice(s[i]);
    }
    cout.precision(2);
    cout<<fixed<<"Average: "<<(double)suma/n<<endl;
}

void printHighestPriceItem (ShoppingCart kosnicki[], int n){
    Item max = kosnicki[0].items[0];
    int id = 0; int highestPriced = 0;
    for (int i=0; i<n; i++){
        for (int j=0; j<kosnicki[i].brItems; j++){
            if (kosnicki[i].items[j].cenaProizvod > highestPriced){
                highestPriced = kosnicki[i].items[j].cenaProizvod;
                id = kosnicki[i].id;
                max = kosnicki[i].items[j];
            }
        }
    }
    cout<<"Shopping cart id: "<<id<<endl;
    cout<<"Product: "<<max.imeProizvod<<endl;
}



int main (){

    int n;
    cin>>n;

    ShoppingCart kosnicki[100];
    for (int i=0; i<n; i++){
        cin>>kosnicki[i].id>>kosnicki[i].brItems;
        for (int j=0; j<kosnicki[i].brItems; j++){
            cin>>kosnicki[i].items[j].imeProizvod;
            cin>>kosnicki[i].items[j].cenaProizvod;
        }
    }

    printAveragePriceOfLowestItems(kosnicki, n);
    printHighestPriceItem(kosnicki, n);


    return 0;
}
