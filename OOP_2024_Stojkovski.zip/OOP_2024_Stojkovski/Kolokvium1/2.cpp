#include <iostream>
#include <cstring>
using namespace std;

class List {
private:
    int * broevi;
    int n;
public:
    List(){
        broevi = new int[0];
        this->n = 0;
    }
    List(int * broevi, int n){
        for (int i=0; i<n; i++){
            this->broevi[i] = broevi[i];
        }
        this->n = n;
    }
    List (const List & other){
        for (int i=0; i<n; i++){
            this->broevi[i] = other.broevi[i];
        }
        this->n = other.n;
    }

    ~List (){
        delete [] broevi;
    }

    void print(){
        for (int i=0; i<n; i++){
            cout << i+1 << ": " << broevi[i] << " ";
        }
        cout << "sum: " << sum() << " average: " << average() << endl;
    }

    int sum(){
        int suma = 0;
        for (int i=0; i<n; i++){
            suma += broevi[i];
        }
        return suma;
    }

    double average(){
        if (n == 0) return 0;
        return (double) sum()/n;
    }

};

class ListContainer {
private:
    List * niza;
    int brElementi;
    int brObidi = 0;
public:
    ListContainer(){
        this->brElementi = 0;
        this->brObidi = 0;
        this->niza = new List[0];
    }
    ListContainer(const ListContainer & other){
        this->brElementi = other.brElementi;
        this->brObidi = other.brObidi;
        this->niza = new List[other.brElementi];
        for (int i = 0; i < brElementi; ++i) {
            this->niza[i] = other.niza[i];
        }
    }

    ~ListContainer(){
        delete [] niza;
    }

    ListContainer & operator = (const ListContainer & other){
        if (this != & other){
            this->brElementi = other.brElementi;
            this->brObidi = other.brObidi;
            this->niza = new List[other.brElementi];
            for (int i = 0; i < brElementi; ++i) {
                this->niza[i] = other.niza[i];
            }
        }
        return * this;
    }

    void print(){
        if (brElementi == 0) {
            cout << "The list is empty." << endl;
            return;
        }
        for (int i = 0; i < brElementi; i++) {
            cout << "List number: " << i + 1 << " ";
            niza[i].print();
        }
        cout << "Sum: " << sum() << " Average: " << average() << endl;
    }

    int sum() {
        int total = 0;
        for (int i = 0; i < brElementi; i++) {
            total += niza[i].sum();
        }
        return total;
    }

    double average() {
        if (brElementi == 0) return 0;
        return (double)sum() / brElementi;
    }



};

int main() {

    ListContainer lc;
    int N;
    cin>>N;

    for (int i=0;i<N;i++) {
        int n;
        int niza[100];

        cin>>n;

        for (int j=0;j<n;j++){
            cin>>niza[j];

        }

        List l=List(niza,n);

//        lc.addNewList(l);
    }


    int testCase;
    cin>>testCase;

    if (testCase==1) {
        cout<<"Test case for operator ="<<endl;
        ListContainer lc1;
        lc1.print();
        cout<<lc1.sum()<<" "<<lc.sum()<<endl;
        lc1=lc;
        lc1.print();
        cout<<lc1.sum()<<" "<<lc.sum()<<endl;
        lc1.sum();
        lc1.average();

    }
    else {
        lc.print();
    }
}