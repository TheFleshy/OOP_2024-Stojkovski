#include<iostream>
#include <cstring>
using namespace std;

class Pacient {
private:
    char namesurname[100];
    bool osiguran;
    int brojPregledi;
public:
    Pacient(char *namesurname, bool osiguran, int brojPregledi){
        strcpy(this->namesurname, namesurname);
        this->osiguran = osiguran;
        this->brojPregledi = brojPregledi;
    }

    Pacient(const Pacient & other){
        strcpy(this->namesurname, other.namesurname);
        this->osiguran = other.osiguran;
        this->brojPregledi = other.brojPregledi;
    }

    ~Pacient(){}



};

class MaticenDoktor {
private:
    char name [100];
    int brojPacienti;
    Pacient * niza;
    float cenaPregled;
public:
    MaticenDoktor(char *name, int brojPacienti, Pacient *niza, float cenaPregled){
        strcpy(this->name, name);
        this->brojPacienti = brojPacienti;

    }

};

int main() {
    int i, j, n;
    MaticenDoktor md[200];
    cin >> n;
    for (i = 0; i < n; i++){
        //ime na doktor
        cin >> md[i].ime;
        //broj na pacienti
        cin >> md[i].br_pac;
        //cena na pregled
        cin >> md[i].cena;

        for (j = 0; j < md[i].br_pac; j++){
            cin >> md[i].niza[j].ime;
            cin >> md[i].niza[j].zdrastveno;
            cin >> md[i].niza[j].pregledi;
        }
    }
    najuspesen_doktor(md, n);

    return 0;
}
