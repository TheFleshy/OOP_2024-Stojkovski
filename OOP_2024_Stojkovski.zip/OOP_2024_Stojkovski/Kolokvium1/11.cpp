#include <iostream>
#include <cstring>

using namespace std;

class Ucesnik{
private:
    char *ime;
    int vozrast;
    bool pol;
public:
    Ucesnik(char *ime="",bool pol= true,int vozrast=50){ //2 vo 1 konstruktor
        this->pol=pol;
        this->vozrast=vozrast;
        this->ime=new char [strlen(ime)+1];
        strcpy(this->ime,ime);
    }

    ~Ucesnik(){ //Desktruktor
        delete [] ime;
    }

    Ucesnik(const Ucesnik & other){
        this->vozrast = other.vozrast;
        this->ime = new char [strlen(other.ime)+1];
        strcpy(this->ime, other.ime);
        this->pol = other.pol;
    }

//    bool operator > (const Ucesnik & other){
//        return this->vozrast > other.vozrast;
//    }

    friend ostream &operator<<(ostream &os, const Ucesnik &ucesnik) {
        os << ucesnik.ime<<endl;
        if(ucesnik.pol){
            os<<"mashki"<<endl;
        }else {
            os<<"zhenski"<<endl;
        }
//        os << ucesnik.pol<<endl;
        os << ucesnik.vozrast<<endl;
        return os;
    }

    bool operator==(const Ucesnik &rhs) const {
        return vozrast == rhs.vozrast;
    }

    Ucesnik & operator = (const Ucesnik & s){
        if(this!=&s){
            delete [] ime;
            this->vozrast = s.vozrast;
            this->ime = new char [strlen(s.ime)+1];
            strcpy(this->ime, s.ime);
            this->pol = s.pol;
        }
        return *this;
    }

//TODO operator ednakvo


//TODO da se preoptorvari > za sporedba na dva ucesnika
//TODo da se preoptovari << za pecatenje

    int getAge(){
        return vozrast;
    }

    };

class Maraton{
private:
    char lokacija[100];
    Ucesnik *ucesnici;
    int broj_ucesnici;
public:
    Maraton(char *lokacija =""){
        strcpy(this->lokacija,lokacija);
        this->broj_ucesnici=0;
        this->ucesnici=new Ucesnik[0];
    }

    Maraton(const Maraton &other){
        strcpy(this->lokacija,other.lokacija);
        this->broj_ucesnici=other.broj_ucesnici;
        //TODO
        this->ucesnici=new Ucesnik[other.broj_ucesnici];
        for(int i=0;i<other.broj_ucesnici;i++){
            ucesnici[i]=other.ucesnici[i];
        }

    }

    ~Maraton(){
        delete [] ucesnici;
    }

     Maraton&operator += (const Ucesnik & other){
        Ucesnik * tmp = new Ucesnik[broj_ucesnici+1];
        for (int i=0; i<broj_ucesnici; i++){
            tmp[i] = ucesnici[i];
        }
        tmp[broj_ucesnici++] = other;
        delete [] ucesnici;
        ucesnici = tmp;
        return * this;
    }

    Maraton&operator -= (const Ucesnik & other){
        Ucesnik * tmp = new Ucesnik[broj_ucesnici-1];
        int counter = 0;
        for (int i=0; i<broj_ucesnici; i++){
            if (ucesnici[i] == other) continue;
            tmp[counter++] = ucesnici[i];
        }
        delete [] ucesnici;
        ucesnici = tmp;
        broj_ucesnici--;
        return * this;
    }


    double prosecnoVozrast(){
        //TODO da vrne prosecna vozrast na ucesnicite
        double prosek=0;
        for(int i=0;i<broj_ucesnici;i++){
            prosek+=ucesnici[i].getAge(); //TODO gettrer za age
        }
        return prosek/broj_ucesnici;
    }

    void pecatiPomladi(Ucesnik &uc){
        //TODO da se pecatat site so sa pomladi od prosledenio ucesnik
        for(int i=0; i < broj_ucesnici ;i++){
            if(ucesnici[i].getAge() < uc.getAge()){
                cout<<ucesnici[i]; //TODO moze greska da ima tuka
            }
        }
    }

};



int main (){
    char ime[100];
    bool maski;
    int vozrast, n;
    //Info za ucesnik
    cin >> n;
    char lokacija[100];
    cin >> lokacija;
    Maraton m(lokacija);
    Ucesnik **u = new Ucesnik*[n];
    for(int i = 0; i < n; ++i) {
        cin >> ime >> maski >> vozrast;
        u[i] = new Ucesnik(ime, maski, vozrast);
        m += *u[i];
    }
    m.pecatiPomladi(*u[n - 1]);
    cout << m.prosecnoVozrast() << endl;
    for(int i = 0; i < n; ++i) {
        delete u[i];
    }
    delete [] u;
    return 0;
}