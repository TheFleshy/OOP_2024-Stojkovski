#include <iostream>
#include <cstring>
using namespace std;

class Patnik {
private:
    char name[100];
    int klasaVagon;
    bool velosiped;
public:
    Patnik(char * name = "", int klasaVagon = 0, bool velospied = 0){ //2in1
        strcpy(this->name, name);
        this->klasaVagon = klasaVagon;
        this->velosiped = velospied;
    }

    Patnik(const Patnik & other){
        strcpy(this->name, other.name);
        this->klasaVagon = other.klasaVagon;
        this->velosiped = other.velosiped;
    }

    ~Patnik(){}

    friend ostream &operator<<(ostream &os, const Patnik &patnik) {
        os<<patnik.name<<endl;
        os<<patnik.klasaVagon<<endl;
        os<<patnik.velosiped<<endl;
        return os;
    }

    Patnik &operator =(const Patnik & p){
        if (this!=&p){
            strcpy(this->name, p.name);
            this->klasaVagon = p.klasaVagon;
            this->velosiped = p.velosiped;
        }
        return *this;
    }

    bool isVelosiped() const {
        return velosiped;
    }

    int getKlasaVagon() const {
        return klasaVagon;
    }

};

class Voz{
private:
    char krajnaDestinacija [100];
    Patnik * niza;
    int n;
    int dozvoleniVelosipedi;
public:
    Voz(char * krajnaDestinacija = " ", int dozvoleniVelosipedi = 0){  // 2in1
        strcpy(this->krajnaDestinacija, krajnaDestinacija);
        this->dozvoleniVelosipedi = dozvoleniVelosipedi;
        this->niza = new Patnik[0];
        this->n = 0;
    }

    Voz(const Voz & other){
        strcpy(this->krajnaDestinacija, other.krajnaDestinacija);
        this->dozvoleniVelosipedi = other.dozvoleniVelosipedi;
        this->n = other.n;
        this->niza = new Patnik[other.n];
        for (int i=0; i<n; i++){
            this->niza[i] = other.niza[i];
        }
    }

    Voz &operator =(const Voz & v){
        if (this != &v){
            delete [] niza;
            strcpy(this->krajnaDestinacija, v.krajnaDestinacija);
            this->dozvoleniVelosipedi = v.dozvoleniVelosipedi;
            this->niza = new Patnik[n];
            for (int i=0; i<n; i++){
                this->niza[i] = v.niza[i];
            }
        }
        return * this;
    }

    Voz &operator += (const Patnik & other){
        Patnik * tmp = new Patnik[n+1];
        for (int i=0; i<n; i++){
            tmp[i] = niza[i];
        }
        tmp[n++] = other;
        delete [] niza;
        niza = tmp;
        return *this;
    }

    friend ostream &operator<<(ostream &os, const Voz &voz) {
        os<<voz.krajnaDestinacija<<endl;
        if (voz.dozvoleniVelosipedi >0){
            for (int i=0; i<voz.n; i++){
                os<<voz.niza[i]<<endl;
            }
        }
        if (voz.dozvoleniVelosipedi == 0){
            for (int i=0; i<voz.n; i++){
                if(voz.niza[i].isVelosiped() == 0){
                    os<<voz.niza[i]<<endl;
                }
            }
        }
        return os;
    }

    void patniciNemaMesto(){
        int brojvelosipediprva=0;
        int nedozvoleniprva;
        int brvtora=0;
        int nedvtora;
        int razlika;
        for(int i=0;i<n;i++){
            if(niza[i].getKlasaVagon()==1 && niza[i].isVelosiped()==true) {
                brojvelosipediprva++;
            }
        }
        if(brojvelosipediprva-this->dozvoleniVelosipedi>0){
            nedozvoleniprva=brojvelosipediprva-this->dozvoleniVelosipedi;
        }
        else{
            nedozvoleniprva=0;
        }
        for(int i=0;i<n;i++){
            if(niza[i].getKlasaVagon()==2 && niza[i].isVelosiped()==true) {
                brvtora++;
            }
        }
        razlika= (this->dozvoleniVelosipedi-brojvelosipediprva);
        if(brvtora-razlika>=0){
            nedvtora=brvtora-razlika;
        }
        else{
            nedvtora=0;
        }
        cout<<"Brojot na patnici od 1-va klasa koi ostanale bez mesto e: "<<nedozvoleniprva<<endl;
        cout<<"Brojot na patnici od 2-ra klasa koi ostanale bez mesto e: "<<nedvtora<<endl;
    }

};

int main()
{
    Patnik p;
    char ime[100], destinacija[100];
    int n;
    bool velosiped;
    int klasa;
    int maxv;
    cin >> destinacija >> maxv;
    cin >> n;
    Voz v(destinacija, maxv);
    cout<<v<<endl;
    for (int i = 0; i < n; i++){
        cin >> ime >> klasa >> velosiped;
        Patnik p(ime, klasa, velosiped);
        cout<<p<<endl;
        v += p;
    }
    cout << v;
    v.patniciNemaMesto();

    return 0;
}
