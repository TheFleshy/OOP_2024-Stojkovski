#include <iostream>
#include <cstring>
using namespace std;

enum tip {POP, RAP, ROCK};

class Pesna {
private:
    char * name;
    int vremetraenje;
    tip tipPesna;
public:
    Pesna(char *name = " ", int vremetraenje = 0, tip tipPesna = ROCK){
        this->name = new char [strlen(name)+1];
        strcpy(this->name, name);
        this->vremetraenje = vremetraenje;
        this->tipPesna = tipPesna;
    }
    Pesna(const Pesna & other){
        this->name = new char [strlen(other.name)+1];
        strcpy(this->name, other.name);
        this->vremetraenje = other.vremetraenje;
        this->tipPesna = other.tipPesna;
    }

    Pesna & operator = (const Pesna & other){
        if (this != &other) return *this;

        delete [] name;
        this->name = new char [strlen(other.name)+1];
        strcpy(this->name, other.name);
        this->vremetraenje = other.vremetraenje;
        this->tipPesna = other.tipPesna;

        return *this;
    }

    ~Pesna(){
        delete [] name;
    }

    void pecati(){
        cout<<"\""<<name<<"\"-"<<vremetraenje<<"min"<<endl;
    }

    int getVremetraenje() const {
        return vremetraenje;
    }

    tip getTipPesna() const {
        return tipPesna;
    }
};

class CD {
private:
    Pesna * niza;
    int brojPesni;
    int vremetraenje;
public:
    CD(int vremetraenje = 0){
        this->brojPesni = 0;
        this->vremetraenje = vremetraenje;
    }

    CD(const CD & other){
        this->brojPesni = other.brojPesni;
        this->vremetraenje = other.vremetraenje;
        this->niza = new Pesna [other.brojPesni];
        for (int i=0; i<brojPesni; i++){
            this->niza[i] = other.niza[i];
        }
    }

    CD &operator =(const CD & other){
        if (this == & other) return *this;
        this->brojPesni = other.brojPesni;
        this->vremetraenje = other.vremetraenje;
        this->niza = new Pesna [other.brojPesni];
        for (int i=0; i<brojPesni; i++){
            this->niza[i] = other.niza[i];
        }
    }

    ~CD (){
        delete [] niza;
    }

    void dodadiPesna (Pesna p){
        int sum = 0;
        for (int i=0; i<brojPesni; i++){
            sum += niza[i].getVremetraenje();
        }
        if (sum + p.getVremetraenje() <= vremetraenje && brojPesni<10) {
            Pesna *tmp = new Pesna[brojPesni + 1];
            for (int i = 0; i < brojPesni; i++) {
                tmp[i] = niza[i];
            }
            tmp[brojPesni++] = p;
//        delete [] niza;
            niza = tmp;
        }
//        return *this;
    }

    int getBroj() const {
        return brojPesni;
    }

    Pesna *getPesni(int i) const {
        return &niza[i];
    }

    void pecatiPesniPoTip(tip t) {
        for (int i=0; i<brojPesni; i++){
            if (niza[i].getTipPesna() == t){
                niza[i].pecati();
            }
        }
    }
};

int main() {
    // se testira zadacata modularno
    int testCase;
    cin >> testCase;

    int n, minuti, kojtip;
    char ime[50];

    if(testCase == 1) {
        cout << "===== Testiranje na klasata Pesna ======" << endl;
        cin >> ime;
        cin >> minuti;
        cin >> kojtip; //se vnesuva 0 za POP,1 za RAP i 2 za ROK
        Pesna p(ime,minuti,(tip)kojtip);
        p.pecati();
    } else if(testCase == 2) {
        cout << "===== Testiranje na klasata CD ======" << endl;
        CD omileno(20);
        cin>>n;
        for (int i=0;i<n;i++){
            cin >> ime;
            cin >> minuti;
            cin >> kojtip; //se vnesuva 0 za POP,1 za RAP i 2 za ROK
            Pesna p(ime,minuti,(tip)kojtip);
            omileno.dodadiPesna(p);
        }
        for (int i=0; i<n; i++)
            (omileno.getPesni(i))->pecati();
    }
    else if(testCase == 3) {
        cout << "===== Testiranje na metodot dodadiPesna() od klasata CD ======" << endl;
        CD omileno(20);
        cin>>n;
        for (int i=0;i<n;i++){
            cin >> ime;
            cin >> minuti;
            cin >> kojtip; //se vnesuva 0 za POP,1 za RAP i 2 za ROK
            Pesna p(ime,minuti,(tip)kojtip);
            omileno.dodadiPesna(p);
        }
        for (int i=0; i<omileno.getBroj(); i++)
            (omileno.getPesni(i))->pecati();
    }
    else if(testCase == 4) {
        cout << "===== Testiranje na metodot pecatiPesniPoTip() od klasata CD ======" << endl;
        CD omileno(20);
        cin>>n;
        for (int i=0;i<n;i++){
            cin >> ime;
            cin >> minuti;
            cin >> kojtip; //se vnesuva 0 za POP,1 za RAP i 2 za ROK
            Pesna p(ime,minuti,(tip)kojtip);
            omileno.dodadiPesna(p);
        }
        cin>>kojtip;
        omileno.pecatiPesniPoTip((tip)kojtip);

    }
    else if(testCase == 5) {
        cout << "===== Testiranje na metodot pecatiPesniPoTip() od klasata CD ======" << endl;
        CD omileno(20);
        cin>>n;
        for (int i=0;i<n;i++){
            cin >> ime;
            cin >> minuti;
            cin >> kojtip; //se vnesuva 0 za POP,1 za RAP i 2 za ROK
            Pesna p(ime,minuti,(tip)kojtip);
            omileno.dodadiPesna(p);
        }
        cin>>kojtip;
        omileno.pecatiPesniPoTip((tip)kojtip);

    }

    return 0;
}